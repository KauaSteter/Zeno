<?php

namespace App\Http\Controllers;

use App\Models\CategoriaProduto;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CategoriaProdutoController extends Controller
{
    public function index(Request $request): View
    {
        $categorias = CategoriaProduto::query()
            ->when($request->filled('busca'), function ($query) use ($request) {
                $termo = trim($request->string('busca')->toString());
                $query->where('nome', 'like', "%{$termo}%");
            })
            ->when($request->filled('status'), fn ($query) => $query->where('ativo', $request->boolean('status')))
            ->orderBy('nome')
            ->paginate(15)
            ->withQueryString();

        return view('categorias-produto.index', compact('categorias'));
    }

    public function create(): View
    {
        return view('categorias-produto.create', ['categoria' => new CategoriaProduto(['ativo' => true])]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'nome' => ['required', 'string', 'max:100'],
            'descricao' => ['nullable', 'string'],
            'ativo' => ['sometimes', 'boolean'],
        ]);

        CategoriaProduto::create($data);

        return redirect()->route('categorias-produto.index')
            ->with('success', 'Categoria cadastrada com sucesso.');
    }

    public function edit(CategoriaProduto $categoria): View
    {
        return view('categorias-produto.edit', compact('categoria'));
    }

    public function update(Request $request, CategoriaProduto $categoria): RedirectResponse
    {
        $data = $request->validate([
            'nome' => ['required', 'string', 'max:100'],
            'descricao' => ['nullable', 'string'],
            'ativo' => ['sometimes', 'boolean'],
        ]);

        $categoria->update($data);

        return redirect()->route('categorias-produto.index')
            ->with('success', 'Categoria atualizada com sucesso.');
    }

    public function destroy(CategoriaProduto $categoria): RedirectResponse
    {
        if ($categoria->produtos()->exists()) {
            return redirect()->route('categorias-produto.index')
                ->with('error', 'Não é possível excluir uma categoria que está sendo usada por produtos.');
        }

        $categoria->update(['ativo' => false]);

        return redirect()->route('categorias-produto.index')
            ->with('success', 'Categoria desativada com sucesso.');
    }
}