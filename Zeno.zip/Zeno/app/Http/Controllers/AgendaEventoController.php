<?php

namespace App\Http\Controllers;

use App\Models\AgendaEvento;
use App\Models\Cliente;
use App\Models\Compra;
use App\Models\Fornecedor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class AgendaEventoController extends Controller
{
    public function index(Request $request)
    {
        $query = AgendaEvento::query();

        // Filtrar por data
        if ($request->filled('data_inicio')) {
            $query->where('data_evento', '>=', $request->input('data_inicio'));
        }

        if ($request->filled('data_fim')) {
            $query->where('data_evento', '<=', $request->input('data_fim'));
        }

        // Filtrar por categoria
        if ($request->filled('categoria')) {
            $query->where('categoria', $request->input('categoria'));
        }

        // Filtrar por status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        // Filtrar por prioridade
        if ($request->filled('prioridade')) {
            $query->where('prioridade', $request->input('prioridade'));
        }

        // Usuário vendedor vê só os seus (a menos que seja admin)
        $user = auth()->user();
        if (!$user->isAdmin() && !$user->hasRole(['gerente', 'financeiro'])) {
            $query->where(function ($q) use ($user) {
                $q->where('usuario_id', $user->id)
                  ->orWhere('created_by', $user->id);
            });
        }

        $eventos = $query->orderBy('data_evento')
            ->orderBy('prioridade')
            ->paginate(20)
            ->withQueryString();

        return view('agenda.index', compact('eventos'));
    }

    public function calendario(Request $request)
    {
        $mes = $request->input('mes', now()->format('Y-m'));
        $inicioMes = Carbon::createFromFormat('!Y-m', $mes);
        if ($inicioMes === false || $inicioMes->format('Y-m') !== $mes) {
            abort(422, 'Formato de mês inválido. Use AAAA-MM.');
        }
        $inicioMes->startOfMonth();

        $anos = collect(range(2024, 2030))->map(fn($y) => $y)->toArray();
        $meses = [
            '01' => 'Janeiro', '02' => 'Fevereiro', '03' => 'Março',
            '04' => 'Abril', '05' => 'Maio', '06' => 'Junho',
            '07' => 'Julho', '08' => 'Agosto', '09' => 'Setembro',
            '10' => 'Outubro', '11' => 'Novembro', '12' => 'Dezembro'
        ];

        $query = AgendaEvento::query()
            ->where('data_inicio', '>=', $inicioMes->toDateTimeString())
            ->where('data_inicio', '<', $inicioMes->copy()->addMonth()->toDateTimeString());

        if (auth()->user()->hasRole(['gerente', 'financeiro'])) {
            // Eles veem todos
        } else {
            $query->where(function ($q) {
                $userId = auth()->id();
                $q->where('usuario_id', $userId)
                  ->orWhere('created_by', $userId);
            });
        }

        $eventos = $query->get()->map(fn($e) => [
            'id' => $e->id,
            'title' => $e->titulo . ($e->prioridade === AgendaEvento::PRIORIDADE_ALTA ? ' ⚠' : ''),
            'start' => Carbon::parse($e->data_inicio)->toIso8601String(),
            'className' => $e->status === AgendaEvento::STATUS_CONCLUIDO ? 'evento-concluido' : "evento-{$e->categoria}",
        ]);

        return view('agenda.calendario', compact('eventos', 'mes', 'meses', 'anos'));
    }

    public function create(Request $request)
    {
        $categorias = AgendaEvento:: getCategorias();
        $clientes = Cliente::orderBy('nome')->take(100)->get();
        $fornecedores = Fornecedor::orderBy('razao_social')->take(100)->get();
        $compras = Compra::where('status', 'aberta')->get();
        $usuarios = User::where('ativo', true)->get();

        return view('agenda.create', compact('categorias', 'clientes', 'fornecedores', 'compras', 'usuarios'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'titulo' => 'required|string|max:255',
            'descricao' => 'nullable|string',
            'data_evento' => 'required|date|after_or_equal:today',
            'hora' => 'nullable|date_format:H:i',
            'prioridade' => 'required|in:alta,normal,baixa',
            'categoria' => 'required|in:crm,compras,financeiro,estoque,outro',
            'cliente_id' => 'nullable|exists:clientes,id',
            'fornecedor_id' => 'nullable|exists:fornecedores,id',
            'compra_id' => 'nullable|exists:compras,id',
            'usuario_id' => 'nullable|exists:users,id',
            'recorrencia' => 'nullable|in:nunca,diario,semanal,quinzenal,mensal',
            'data_fim_recorrencia' => 'nullable|date|after:data_evento',
        ]);

        $validated['created_by'] = auth()->id();

        // Se for CRM, vincular ao usuário logado como responsável
        if ($validated['categoria'] === AgendaEvento::CATEGORIA_CRM) {
            $validated['usuario_id'] = $validated['usuario_id'] ?? auth()->id();
        }

        AgendaEvento::create($validated);

        return redirect()->route('agenda.index')
            ->with('success', 'Evento criado com sucesso!');
    }

    public function show(AgendaEvento $agendaEvento)
    {
        // Verificar permissão
        $user = auth()->user();
        if (!$user->isAdmin() && !$user->hasRole(['gerente', 'financeiro'])) {
            if ($agendaEvento->usuario_id !== $user->id && $agendaEvento->created_by !== $user->id) {
                abort(403, 'Acesso negado');
            }
        }

        return view('agenda.show', compact('agendaEvento'));
    }

    public function edit(AgendaEvento $agendaEvento)
    {
        $user = auth()->user();
        if (!$user->isAdmin() && !$user->hasRole(['gerente', 'financeiro'])) {
            if ($agendaEvento->usuario_id !== $user->id && $agendaEvento->created_by !== $user->id) {
                abort(403, 'Acesso negado');
            }
        }

        $categorias = AgendaEvento::getCategorias();
        $clientes = Cliente::orderBy('nome')->take(100)->get();
        $fornecedores = Fornecedor::orderBy('razao_social')->take(100)->get();
        $compras = Compra::where('status', 'aberta')->get();
        $usuarios = User::where('ativo', true)->get();

        return view('agenda.edit', compact('agendaEvento', 'categorias', 'clientes', 'fornecedores', 'compras', 'usuarios'));
    }

    public function update(Request $request, AgendaEvento $agendaEvento)
    {
        $validated = $request->validate([
            'titulo' => 'required|string|max:255',
            'descricao' => 'nullable|string',
            'data_evento' => 'required|date',
            'hora' => 'nullable|date_format:H:i',
            'prioridade' => 'required|in:alta,normal,baixa',
            'categoria' => 'required|in:crm,compras,financeiro,estoque,outro',
            'cliente_id' => 'nullable|exists:clientes,id',
            'fornecedor_id' => 'nullable|exists:fornecedores,id',
            'compra_id' => 'nullable|exists:compras,id',
            'usuario_id' => 'nullable|exists:users,id',
            'recorrencia' => 'nullable|in:nunca,diario,semanal,quinzenal,mensal',
            'data_fim_recorrencia' => 'nullable|date|after:data_evento',
        ]);

        $agendaEvento->update($validated);

        return redirect()->route('agenda.index')
            ->with('success', 'Evento atualizado com sucesso!');
    }

    public function destroy(AgendaEvento $agendaEvento)
    {
        $agendaEvento->delete();

        return redirect()->route('agenda.index')
            ->with('success', 'Evento excluído com sucesso!');
    }

    public function marcarConcluido(AgendaEvento $agendaEvento)
    {
        $agendaEvento->update(['status' => AgendaEvento::STATUS_CONCLUIDO]);

        return back()->with('success', 'Evento marcado como concluído!');
    }

    // === MÉTODOS DE AUTOMAÇÃO ===

    public function criarEventoProspeccao(Cliente $cliente, \DateTime $dataRetorno)
    {
        return AgendaEvento::create([
            'titulo' => "Retorno de contato: {$cliente->nome}",
            'descricao' => 'Follow-up da prospecção CRM',
            'data_evento' => $dataRetorno,
            'categoria' => AgendaEvento::CATEGORIA_CRM,
            'cliente_id' => $cliente->id,
            'usuario_id' => auth()->id(),
            'prioridade' => AgendaEvento::PRIORIDADE_NORMAL,
            'created_by' => auth()->id(),
        ]);
    }

    public function verificarItensBaixos()
    {
        $produtos = \App\Models\Produto::whereRaw('estoque_atual <= estoque_minimo')
            ->get();

        foreach ($produtos as $produto) {
            AgendaEvento::create([
                'titulo' => "Repor estoque: {$produto->nome}",
                'descricao' => "Estoque atual: {$produto->estoque_atual} / Mínimo: {$produto->estoque_minimo}",
                'data_evento' => now()->addDay(),
                'categoria' => AgendaEvento::CATEGORIA_ESTOQUE,
                'prioridade' => AgendaEvento::PRIORIDADE_ALTA,
                'created_by' => auth()->id(),
            ]);
        }

        return response()->json(['message' => 'Eventos de reposição criados']);
    }

    public function verificarContasVencendo()
    {
        $contas = \App\Models\ContaPagar::whereBetween('data_vencimento', [
            now(),
            now()->addDays(5)
        ])->where('status', 'pendente')->get();

        foreach ($contas as $conta) {
            AgendaEvento::create([
                'titulo' => "Pagar: {$conta->fornecedor->razao_social}",
                'descricao' => "Valor: R$ " . number_format($conta->valor, 2, ',', '.') . " - Vencimento: {$conta->data_vencimento->format('d/m/Y')}",
                'data_evento' => $conta->data_vencimento,
                'categoria' => AgendaEvento::CATEGORIA_FINANCEIRO,
                'fornecedor_id' => $conta->fornecedor_id,
                'prioridade' => AgendaEvento::PRIORIDADE_ALTA,
                'created_by' => auth()->id(),
            ]);
        }
    }
}