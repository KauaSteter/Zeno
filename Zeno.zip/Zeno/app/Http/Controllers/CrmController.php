<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CrmController extends Controller
{
    public function index(Request $request)
    {
        $vendedorOuGerente = auth()->user()->role === 'vendedor' 
            ? ['vendedor'] 
            : ['gerente', 'admin'];
        
        $query = DB::table('crm_prospeccao as c')
            ->join('clientes as cli', 'c.cliente_id', '=', 'cli.id')
            ->select('c.*', 'cli.nome as cliente_nome', 'cli.cpf_cnpj as cliente_cnpj');
        
        if (in_array(auth()->user()->role, $vendedorOuGerente)) {
            $query->where('c.vendedor_id', auth()->id());
        }

        if ($request->filled('status')) {
            $query->where('c.status', $request->input('status'));
        }

        $prospeccoes = $query->orderBy('c.data_acao')->paginate(20)->withQueryString();

        return view('crm.index', compact('prospeccoes'));
    }

    public function prospeccao()
    {
        // Clientes que ainda não foram prospectados ou têm prospeccao recente
        $clientesComProspeccao = DB::table('crm_prospeccao')
            ->pluck('cliente_id')
            ->toArray();

        $clientes = \App\Models\Cliente::whereNotIn('id', $clientesComProspeccao)
            ->orderBy('nome')
            ->paginate(15);

        return view('crm.prospeccao', compact('clientes'));
    }

    public function prospeccaoStore(Request $request)
    {
        $validated = $request->validate([
            'cliente_id' => 'required|exists:clientes,id',
            'status' => 'required|in:novo,em_contato,qualificado,fechado,recusado',
            'canal_contato' => 'nullable|in:email,telefone,whatsapp,visita',
            'proxima_acao' => 'nullable|string|max:200',
            'data_acao' => 'nullable|date',
            'observacoes' => 'nullable|string',
        ]);

        DB::table('crm_prospeccao')->insert([
            'cliente_id' => $validated['cliente_id'],
            'vendedor_id' => auth()->id(),
            'status' => $validated['status'],
            'canal_contato' => $validated['canal_contato'] ?? null,
            'proxima_acao' => $validated['proxima_acao'] ?? null,
            'data_acao' => $validated['data_acao'] ?? null,
            'observacoes' => $validated['observacoes'] ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->route('crm.index')
            ->with('success', 'Prospecção criada com sucesso!');
    }

    public function contatar($clienteId)
    {
        $cliente = \App\Models\Cliente::findOrFail($clienteId);

        $prospeccaoExistente = DB::table('crm_prospeccao')
            ->where('cliente_id', $clienteId)
            ->where('vendedor_id', auth()->id())
            ->first();

        return view('crm.contatar', compact('cliente', 'prospeccaoExistente'));
    }

    public function prospeccaoUpdate(Request $request, $clienteId)
    {
        $validated = $request->validate([
            'status' => 'required|in:novo,em_contato,qualificado,fechado,recusado',
            'canal_contato' => 'nullable|in:email,telefone,whatsapp,visita',
            'proxima_acao' => 'nullable|string|max:200',
            'data_acao' => 'nullable|date',
            'observacoes' => 'nullable|string',
        ]);

        $existe = DB::table('crm_prospeccao')
            ->where('cliente_id', $clienteId)
            ->where('vendedor_id', auth()->id())
            ->first();

        if ($existe) {
            DB::table('crm_prospeccao')
                ->where('id', $existe->id)
                ->update([
                    'status' => $validated['status'],
                    'canal_contato' => $validated['canal_contato'] ?? null,
                    'proxima_acao' => $validated['proxima_acao'] ?? null,
                    'data_acao' => $validated['data_acao'] ?? null,
                    'observacoes' => $validated['observacoes'] ?? null,
                    'updated_at' => now(),
                ]);
        } else {
            DB::table('crm_prospeccao')->insert([
                'cliente_id' => $clienteId,
                'vendedor_id' => auth()->id(),
                'status' => $validated['status'],
                'canal_contato' => $validated['canal_contato'] ?? null,
                'proxima_acao' => $validated['proxima_acao'] ?? null,
                'data_acao' => $validated['data_acao'] ?? null,
                'observacoes' => $validated['observacoes'] ?? null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return redirect()->route('crm.index')
            ->with('success', 'Prospecção atualizada com sucesso!');
    }
}