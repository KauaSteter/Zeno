<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Cliente;
use App\Models\Produto;
use App\Models\Venda;
use App\Models\VendaItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class VendaController extends Controller
{
    // ----------- Venda de Caixa (PDV) -----------
    public function create()
    {
        $clientes = Cliente::where('ativo', true)->orderBy('nome')->get();
        $produtos = Produto::where('ativo', true)->where('estoque_atual', '>', 0)->orderBy('nome')->get();
        return view('vendas.create', compact('clientes', 'produtos'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'cliente_id' => 'nullable|exists:clientes,id',
            'forma_pagamento' => 'required|string',
            'items' => 'required|array|min:1',
            'items.*.produto_id' => 'required|exists:produtos,id',
            'items.*.quantidade' => 'required|integer|min:1',
        ]);

        $numeroVenda = 'VND-' . now()->format('dmY') . '-' . Str::upper(Str::random(6));

        $venda = DB::transaction(function () use ($validated, $numeroVenda) {
            $venda = Venda::create([
                'numero_venda' => $numeroVenda,
                'cliente_id' => $validated['cliente_id'] ?? null,
                'usuario_id' => auth()->id(),
                'origem' => 'loja',
                'forma_pagamento' => $validated['forma_pagamento'],
                'status_pagamento' => 'pago',
                'data_venda' => now(),
                'subtotal' => 0,
                'desconto' => 0,
                'frete' => 0,
                'total' => 0,
            ]);

            $subtotal = 0;
            foreach ($validated['items'] as $item) {
                $produto = Produto::query()->lockForUpdate()->findOrFail($item['produto_id']);
                if ($produto->estoque_atual < $item['quantidade']) {
                    throw new \Exception('Estoque insuficiente para: ' . $produto->nome);
                }

                $totalItem = round((float) $produto->preco_venda * $item['quantidade'], 2);
                VendaItem::create([
                    'venda_id' => $venda->id,
                    'produto_id' => $produto->id,
                    'quantidade' => $item['quantidade'],
                    'preco_unitario' => $produto->preco_venda,
                    'desconto' => 0,
                    'total' => $totalItem,
                ]);

                $produto->decrement('estoque_atual', $item['quantidade']);
                $subtotal += $totalItem;
            }

            $venda->update(['subtotal' => $subtotal, 'total' => $subtotal]);
            return $venda;
        });

        return redirect()->route('vendas.show', $venda)
            ->with('success', 'Venda finalizada com sucesso!');
    }

    // ----------- pedido de venda (sem finalizar) -----------
    public function createPedido()
    {
        $clientes = Cliente::where('ativo', true)->orderBy('nome')->get();
        $produtos = Produto::where('ativo', true)->where('estoque_atual', '>', 0)->orderBy('nome')->get();
        return view('vendas.pedido', compact('clientes', 'produtos'));
    }

    public function storePedido(Request $request)
    {
        $validated = $request->validate([
            'cliente_id' => 'nullable|exists:clientes,id',
            'forma_pagamento' => 'required|string',
            'items' => 'required|array|min:1',
            'items.*.produto_id' => 'required|exists:produtos,id',
            'items.*.quantidade' => 'required|integer|min:1',
        ]);

        $numeroVenda = 'PED-' . now()->format('dmY') . '-' . Str::upper(Str::random(6));

        $venda = DB::transaction(function () use ($validated, $numeroVenda) {
            $venda = Venda::create([
                'numero_venda' => $numeroVenda,
                'cliente_id' => $validated['cliente_id'] ?? null,
                'usuario_id' => auth()->id(),
                'origem' => 'loja',
                'forma_pagamento' => null,
                'status_pagamento' => 'pendente',
                'data_venda' => now(),
                'subtotal' => 0,
                'desconto' => 0,
                'frete' => 0,
                'total' => 0,
            ]);

            $subtotal = 0;
            foreach ($validated['items'] as $item) {
                $produto = Produto::query()->lockForUpdate()->findOrFail($item['produto_id']);
                if (! $produto->ativo || $produto->estoque_atual < $item['quantidade']) {
                    throw new \RuntimeException('Estoque insuficiente ou produto inativo: ' . $produto->nome);
                }

                $totalItem = round((float) $produto->preco_venda * $item['quantidade'], 2);
                VendaItem::create([
                    'venda_id' => $venda->id,
                    'produto_id' => $produto->id,
                    'quantidade' => $item['quantidade'],
                    'preco_unitario' => $produto->preco_venda,
                    'desconto' => 0,
                    'total' => $totalItem,
                ]);

                $subtotal += $totalItem;
            }

            $venda->update(['subtotal' => $subtotal, 'total' => $subtotal]);
            return $venda;
        });

        return redirect()->route('vendas.show', $venda)
            ->with('success', 'Pedido de venda criado com sucesso!');
    }

    // ---------- originais (mantidos) ----------
    public function index()
    {
        $vendas = Venda::with('cliente')
            ->orderBy('data_venda', 'desc')
            ->paginate(20);
        return view('vendas.index', compact('vendas'));
    }

    public function show(Venda $venda)
    {
        $venda->load('cliente', 'vendedor', 'itens.produto');
        return view('vendas.show', compact('venda'));
    }

    public function finalizar(Venda $venda)
    {
        if ($venda->status_pagamento === 'cancelado') {
            return back()->with('error', 'Venda cancelada');
        }
        if ($venda->status_pagamento === 'pago') {
            return back()->with('error', 'Venda já está paga');
        }

        $venda->update(['status_pagamento' => 'pago']);

        return redirect()->route('vendas.show', $venda)
            ->with('success', 'Venda finalizada com sucesso!');
    }

    public function cancelar(Venda $venda)
    {
        if ($venda->status_pagamento === 'pago' || $venda->status_pagamento === 'cancelado') {
            return back()->with('error', 'Venda já paga ou cancelada');
        }

        DB::transaction(function () use ($venda) {
            $venda->load('itens.produto');
            foreach ($venda->itens as $item) {
                if ($item->produto) {
                    $item->produto->increment('estoque_atual', $item->quantidade);
                }
            }
            $venda->update(['status_pagamento' => 'cancelado']);
        });

        return redirect()->route('vendas.index')
            ->with('success', 'Venda cancelada e estoque restaurado');
    }
}