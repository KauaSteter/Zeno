<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query();

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('nome', 'ilike', "%{$search}%")
                  ->orWhere('email', 'ilike', "%{$search}%")
                  ->orWhere('cpf', 'like', "%{$search}%");
            });
        }

        if ($request->filled('role')) {
            $query->where('role', $request->input('role'));
        }

        if ($request->filled('ativo')) {
            $query->where('ativo', $request->boolean('ativo'));
        }

        $usuarios = $query->orderBy('nome')->paginate(15)->withQueryString();

        return view('usuarios.index', compact('usuarios'));
    }

    public function create()
    {
        return view('usuarios.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nome' => 'required|string|max:150',
            'email' => 'required|string|email|max:150|unique:users,email',
            'cpf' => 'nullable|string|max:14|unique:users,cpf',
            'telefone' => 'nullable|string|max:20',
            'role' => 'required|string|in:admin,gerente,vendedor,financeiro,tecnico',
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'ativo' => 'nullable|boolean',
        ]);

        User::create([
            'nome' => $validated['nome'],
            'email' => $validated['email'],
            'cpf' => $validated['cpf'] ?? null,
            'telefone' => $validated['telefone'] ?? null,
            'role' => $validated['role'],
            'password' => Hash::make($validated['password']),
            'ativo' => $request->has('ativo') ? $request->boolean('ativo') : true,
        ]);

        return redirect()->route('admin.usuarios.index')->with('success', 'Usuário cadastrado com sucesso!');
    }

    public function edit(User $usuario)
    {
        return view('usuarios.edit', compact('usuario'));
    }

    public function update(Request $request, User $usuario)
    {
        $validated = $request->validate([
            'nome' => 'required|string|max:150',
            'email' => ['required', 'string', 'email', 'max:150', Rule::unique('users')->ignore($usuario->id)],
            'cpf' => ['nullable', 'string', 'max:14', Rule::unique('users')->ignore($usuario->id)],
            'telefone' => 'nullable|string|max:20',
            'role' => 'required|string|in:admin,gerente,vendedor,financeiro,tecnico',
            'password' => ['nullable', 'string', 'min:6', 'confirmed'],
            'ativo' => 'nullable|boolean',
        ]);

        // Evita que o usuário admin logado desative seu próprio acesso ou tire seu papel de admin
        if ($usuario->id === auth()->id()) {
            if (!$request->boolean('ativo')) {
                return back()->withErrors(['ativo' => 'Você não pode desativar o seu próprio usuário.'])->withInput();
            }
            if ($validated['role'] !== 'admin' && $usuario->isAdmin()) {
                return back()->withErrors(['role' => 'Você não pode remover o perfil de administrador de si mesmo.'])->withInput();
            }
        }

        $data = [
            'nome' => $validated['nome'],
            'email' => $validated['email'],
            'cpf' => $validated['cpf'] ?? null,
            'telefone' => $validated['telefone'] ?? null,
            'role' => $validated['role'],
            'ativo' => $request->boolean('ativo'),
        ];

        if (!empty($validated['password'])) {
            $data['password'] = $validated['password']; // O cast 'hashed' no Model fará o Hash::make automaticamente
        }

        $usuario->update($data);

        return redirect()->route('admin.usuarios.index')->with('success', 'Usuário atualizado com sucesso!');
    }

    public function toggleAtivo(User $usuario)
    {
        if ($usuario->id === auth()->id()) {
            return back()->withErrors(['error' => 'Você não pode alterar o status do seu próprio usuário.']);
        }

        $usuario->ativo = !$usuario->ativo;
        $usuario->save();

        $status = $usuario->ativo ? 'ativado' : 'desativado';
        return redirect()->route('admin.usuarios.index')->with('success', "Usuário {$status} com sucesso!");
    }
}
