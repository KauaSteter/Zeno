<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\ContaPagar;
use App\Models\Fornecedor;
use App\Models\Compra;
use App\Models\OrdemServico;
use Illuminate\Http\Request;

class ContaPagarController extends Controller
{
    public function index()
    {
        $contas = ContaPagar::with(['fornecedor', 'compra', 'ordemServico'])->orderBy('data_vencimento', 'asc')->paginate(20);
        return view('contas-pagar.index', compact('contas'));
    }

    public function registrarPagamento(Request $request, ContaPagar $conta)
    {
        $validated = $request->validate([
            'forma_pagamento' => 'required|string|in:dinheiro,cartao,pix,cheque',
            'data_pagamento' => 'required|date|after_or_equal:today',
            'observacoes' => 'nullable|string',
        ]);

        $conta->update([
            'forma_pagamento' => $validated['forma_pagamento'],
            'data_pagamento' => $validated['data_pagamento'],
            'status' => 'pago',
            'observacoes' => $validated['observacoes'] ?? $conta->observacoes,
        ]);

        return redirect()->route('contas-pagar.index')->with('success', 'Pagamento registrado!');
    }
}