<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Validation\Rule;

class ClienteController extends Controller
{
    public function index(Request $request): View
    {
        $clientes = Cliente::query()
            ->when($request->filled('busca'), function ($query) use ($request) {
                $termo = trim($request->string('busca')->toString());
                $documento = preg_replace('/\D+/', '', $termo);
                $query->where(function ($query) use ($termo, $documento) {
                    $query->where('nome', 'like', "%{$termo}%")
                        ->orWhere('email', 'like', "%{$termo}%")
                        ->orWhere('cpf_cnpj', 'like', "%{$documento}%");
                });
            })
            ->when($request->filled('status'), fn ($query) => $query->where('ativo', $request->boolean('status')))
            ->orderBy('nome')
            ->paginate(15)
            ->withQueryString();

        return view('clientes.index', compact('clientes'));
    }

    public function create(): View
    {
        return view('clientes.create', ['cliente' => new Cliente()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validatedData($request);
        $data['cpf_cnpj'] = preg_replace('/\D+/', '', $data['cpf_cnpj']);
        $data['ativo'] = true;

        Cliente::create($data);

        return redirect()->route('clientes.index')->with('success', 'Cliente cadastrado.');
    }

    public function edit(Cliente $cliente): View
    {
        return view('clientes.edit', compact('cliente'));
    }

    public function update(Request $request, Cliente $cliente): RedirectResponse
    {
        $data = $this->validatedData($request, $cliente);
        $data['cpf_cnpj'] = preg_replace('/\D+/', '', $data['cpf_cnpj']);
        $data['ativo'] = $request->boolean('ativo');
        $cliente->update($data);

        return redirect()->route('clientes.index')->with('success', 'Cliente atualizado.');
    }

    public function destroy(Cliente $cliente): RedirectResponse
    {
        $cliente->update(['ativo' => false]);

        return redirect()->route('clientes.index')->with('success', 'Cliente desativado.');
    }

    private function validatedData(Request $request, ?Cliente $cliente = null): array
    {
        $type = $request->input('tipo');
        $data = $request->validate([
            'tipo' => ['nullable', Rule::in(['PF', 'PJ'])],
            'cpf_cnpj' => ['required', 'string', 'max:18', Rule::unique('clientes', 'cpf_cnpj')->ignore($cliente?->id), function (string $attribute, mixed $value, \Closure $fail) use ($type) {
                $digits = preg_replace('/\D+/', '', $value);
                $expectedLength = $type === 'PF' ? 11 : 14;
                if (strlen($digits) !== $expectedLength) {
                    $fail($type === 'PF' ? 'O CPF deve conter 11 dígitos.' : 'O CNPJ deve conter 14 dígitos.');
                }
            }],
            'nome' => ['required', 'string', 'max:255'],
            'razao_social' => ['nullable', 'string', 'max:255'],
            'nome_fantasia' => ['nullable', 'string', 'max:255'],
            'ie' => ['nullable', 'string', 'max:20'],
            'inscricao_municipal' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'telefone' => ['nullable', 'string', 'max:20'],
            'celular' => ['nullable', 'string', 'max:20'],
            'cep' => ['nullable', 'string', 'max:9'],
            'endereco' => ['nullable', 'string', 'max:255'],
            'numero' => ['nullable', 'string', 'max:10'],
            'complemento' => ['nullable', 'string', 'max:100'],
            'bairro' => ['nullable', 'string', 'max:100'],
            'cidade' => ['nullable', 'string', 'max:100'],
            'estado' => ['nullable', 'string', 'size:2'],
            'codigo_ibge_municipio' => ['nullable', 'string', 'size:7'],
            'limite_credito' => ['nullable', 'numeric', 'min:0'],
            'credito_utilizado' => ['nullable', 'numeric', 'min:0'],
            'observacoes' => ['nullable', 'string'],
            'ativo' => ['sometimes', 'boolean'],
        ]);

        $data['cpf_cnpj'] = preg_replace('/\D+/', '', $data['cpf_cnpj']);
        $data['tipo'] = $data['tipo'] ?? (strlen($data['cpf_cnpj']) === 11 ? 'PF' : 'PJ');

        return $data;
    }
}
