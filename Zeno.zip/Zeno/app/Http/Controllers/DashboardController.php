<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Compra;
use App\Models\ContaPagar;
use App\Models\ContaReceber;
use App\Models\OrdemServico;
use App\Models\Produto;
use App\Models\Venda;
use App\Models\VendaItem;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    public function index()
    {
        $inicioMes = Carbon::now()->startOfMonth();
        $fimMes = Carbon::now()->endOfMonth();

        // 1. Faturamento do Mês (Vendas + Ordens de Serviço concluídas)
        $faturamentoVendas = 0.0;
        if (Schema::hasTable('vendas')) {
            $faturamentoVendas = (float) Venda::whereBetween('data_venda', [$inicioMes, $fimMes])
                ->where(function ($q) {
                    $q->whereNull('status')->orWhere('status', '!=', 'cancelada');
                })
                ->sum('total');
        }

        $faturamentoOS = 0.0;
        if (Schema::hasTable('ordens_servico')) {
            $faturamentoOS = (float) OrdemServico::whereBetween('data_conclusao', [$inicioMes, $fimMes])
                ->where('status', 'concluida')
                ->sum('total');
        }

        $faturamentoMes = $faturamentoVendas + $faturamentoOS;

        // 2. Custos e Lucro do Mês
        $custoVendas = 0.0;
        if (Schema::hasTable('vendas_itens') && Schema::hasTable('produtos')) {
            $custoVendas = (float) DB::table('vendas_itens')
                ->join('vendas', 'vendas_itens.venda_id', '=', 'vendas.id')
                ->join('produtos', 'vendas_itens.produto_id', '=', 'produtos.id')
                ->whereBetween('vendas.data_venda', [$inicioMes, $fimMes])
                ->where(function ($q) {
                    $q->whereNull('vendas.status')->orWhere('vendas.status', '!=', 'cancelada');
                })
                ->sum(DB::raw('vendas_itens.quantidade * COALESCE(produtos.preco_custo, 0)'));
        }

        // Despesas operacionais do mês pagas (contas a pagar avulsas)
        $despesasExtras = 0.0;
        if (Schema::hasTable('contas_pagar')) {
            $despesasExtras = (float) ContaPagar::whereBetween('data_pagamento', [$inicioMes, $fimMes])
                ->where('status', 'pago')
                ->whereNull('compra_id')
                ->sum('valor_liquido');
        }

        $lucroMes = $faturamentoMes - $custoVendas - $despesasExtras;
        $margemLucro = $faturamentoMes > 0 ? round(($lucroMes / $faturamentoMes) * 100, 1) : 0;

        // Contagem de vendas no mês
        $totalVendasMes = 0;
        if (Schema::hasTable('vendas')) {
            $totalVendasMes = Venda::whereBetween('data_venda', [$inicioMes, $fimMes])
                ->where(function ($q) {
                    $q->whereNull('status')->orWhere('status', '!=', 'cancelada');
                })
                ->count();
        }

        // Produtos e Estoque
        $produtosAtivos = 0;
        $produtosBaixoEstoque = 0;
        $totalEstoqueValor = 0.0;
        if (Schema::hasTable('produtos')) {
            $produtosAtivos = Produto::where('ativo', true)->count();
            $produtosBaixoEstoque = Produto::where('ativo', true)
                ->whereColumn('estoque_atual', '<', 'estoque_minimo')
                ->count();
            $totalEstoqueValor = (float) Produto::where('ativo', true)
                ->sum(DB::raw('COALESCE(preco_venda, 0) * COALESCE(estoque_atual, 0)'));
        }

        // Total de Clientes
        $totalClientes = Schema::hasTable('clientes') ? Cliente::count() : 0;

        return view('dashboard', compact(
            'faturamentoMes',
            'lucroMes',
            'margemLucro',
            'totalVendasMes',
            'custoVendas',
            'produtosAtivos',
            'produtosBaixoEstoque',
            'totalEstoqueValor',
            'totalClientes'
        ));
    }
}
