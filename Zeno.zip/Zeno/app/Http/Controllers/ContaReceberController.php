<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\ContaReceber;
use App\Models\Cliente;
use App\Models\Venda;
use App\Models\OrdemServico;
use Illuminate\Http\Request;

class ContaReceberController extends Controller
{
    public function index()
    {
        $contas = ContaReceber::with(['cliente', 'venda', 'ordemServico'])->orderBy('data_vencimento', 'asc')->paginate(20);
        return view('contas-receber.index', compact('contas'));
    }

    public function registrarPagamento(Request $request, ContaReceber $conta)
    {
        $validated = $request->validate([
            'forma_pagamento' => 'required|string|in:dinheiro,cartao,pix,cheque',
            'data_recebimento' => 'required|date|after_or_equal:today',
            'observacoes' => 'nullable|string',
        ]);

        $conta->update([
            'forma_pagamento' => $validated['forma_pagamento'],
            'data_recebimento' => $validated['data_recebimento'],
            'status' => 'recebido',
            'observacoes' => $validated['observacoes'] ?? $conta->observacoes,
        ]);

        return redirect()->route('contas-receber.index')->with('success', 'Pagamento registrado!');
    }
}
