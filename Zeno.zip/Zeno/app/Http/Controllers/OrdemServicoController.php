<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\OrdemServico;
use App\Models\OrdemServicoItem;
use App\Models\Produto;
use App\Models\Cliente;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class OrdemServicoController extends Controller
{
    public function index()
    {
        $ordens = OrdemServico::with(['cliente', 'tecnico'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        return view('ordens-servico.index', compact('ordens'));
    }

    public function create()
    {
        $clientes = Cliente::where('ativo', true)->get();
        $tecnicos = User::where('role', 'tecnico')->get();

        return view('ordens-servico.create', compact('clientes', 'tecnicos'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'cliente_id' => 'nullable|exists:clientes,id',
            'titulo' => 'nullable|string|max:255',
            'veiculo_marca' => 'nullable|string|max:50',
            'veiculo_modelo' => 'nullable|string|max:50',
            'veiculo_placa' => 'nullable|string|max:10',
            'veiculo_ano' => 'nullable|integer',
            'quilometragem_entrada' => 'nullable|integer',
            'status' => 'nullable|string|in:aberta,em_andamento,aguardando_aprovacao,concluida,cancelada',
            'prioridade' => 'nullable|string|in:normal,urgente,emergencia',
            'sintoma' => 'nullable|string',
            'descricao_problema' => 'nullable|string',
            'descricao_solucao' => 'nullable|string',
            'observacoes' => 'nullable|string',
            'mão_obra' => 'nullable|numeric|min:0',
            'total_desconto' => 'nullable|numeric|min:0',
            'tecnico_id' => 'nullable|exists:users,id',
            'itens' => 'required|array',
            'itens.*.tipo' => 'required|in:peca,servico',
            'itens.*.produto_id' => 'nullable|exists:produtos,id',
            'itens.*.servico_id' => 'nullable|exists:servicos,id',
            'itens.*.nome' => 'nullable|string|max:150',
            'itens.*.quantidade' => 'required|numeric|min:0.01',
            'itens.*.valor_unitario' => 'required|numeric|min:0',
        ]);

        $numeroOs = 'OS-' . now()->format('Ymd') . '-' . Str::upper(Str::random(4));
        
        $totalPecas = 0;
        $totalServicosItens = 0;
        foreach ($validated['itens'] as $item) {
            $subtotal = $item['quantidade'] * $item['valor_unitario'];
            if ($item['tipo'] === 'peca') {
                $totalPecas += $subtotal;
            } else {
                $totalServicosItens += $subtotal;
            }
        }

        $mãoObra = $validated['mão_obra'] ?? 0;
        $desconto = $validated['total_desconto'] ?? 0;
        $totalServicosCompleto = $totalServicosItens + $mãoObra;
        $totalGeral = max(0, $totalPecas + $totalServicosCompleto - $desconto);

        $titulo = $validated['titulo'] 
            ?? (!empty($validated['veiculo_modelo']) ? "Atendimento - {$validated['veiculo_modelo']}" : 'Atendimento Geral');

        $os = OrdemServico::create([
            'numero_os' => $numeroOs,
            'cliente_id' => $validated['cliente_id'],
            'usuario_id' => auth()->id(),
            'tecnico_id' => $validated['tecnico_id'] ?? auth()->id(),
            'titulo' => $titulo,
            'veiculo_marca' => $validated['veiculo_marca'] ?? null,
            'veiculo_modelo' => $validated['veiculo_modelo'] ?? null,
            'veiculo_placa' => $validated['veiculo_placa'] ?? null,
            'veiculo_ano' => $validated['veiculo_ano'] ?? null,
            'quilometragem_entrada' => $validated['quilometragem_entrada'] ?? null,
            'status' => $validated['status'] ?? 'aberta',
            'prioridade' => $validated['prioridade'] ?? 'normal',
            'sintoma' => $validated['sintoma'] ?? $validated['descricao_problema'] ?? null,
            'descricao_problema' => $validated['descricao_problema'] ?? $validated['sintoma'] ?? null,
            'descricao_solucao' => $validated['descricao_solucao'] ?? null,
            'observacoes' => $validated['observacoes'] ?? null,
            'mão_obra' => $mãoObra,
            'total_servicos' => $totalServicosCompleto,
            'total_produtos' => $totalPecas,
            'total_pecas' => $totalPecas,
            'total_desconto' => $desconto,
            'desconto' => $desconto,
            'total' => $totalGeral,
            'total_geral' => $totalGeral,
            'data_abertura' => now(),
            'data_entrada' => now(),
        ]);

        foreach ($validated['itens'] as $item) {
            OrdemServicoItem::create([
                'os_id' => $os->id,
                'tipo' => $item['tipo'],
                'produto_id' => $item['produto_id'] ?? null,
                'servico_id' => $item['servico_id'] ?? null,
                'nome' => $item['nome'] ?? ($item['tipo'] === 'peca' ? 'Peça' : 'Serviço'),
                'quantidade' => $item['quantidade'],
                'valor_unitario' => $item['valor_unitario'],
                'total' => $item['quantidade'] * $item['valor_unitario'],
            ]);
        }

        return redirect()->route('ordens-servico.show', $os)->with('success', 'Ordem de Serviço criada com sucesso!');
    }

    public function finalizar(OrdemServico $os)
    {
        // Calcula mão de obra, pecas e total geral
        $totalPecas = $os->itens()->where('tipo', 'peca')->sum('total');
        $mãoObra = $os->mão_obra ?? 0;
        $totalGeral = $totalPecas + $mãoObra - $os->total_desconto;

        $os->update([
            'total_pecas' => $totalPecas,
            'mão_obra' => $mãoObra,
            'total_geral' => $totalGeral,
            'status' => 'concluida',
            'data_conclusao' => now(),
        ]);

        // Cria conta a receber se necessário
        // ...

        return redirect()->route('ordens-servico.index')->with('success', 'Ordem de Serviço finalizada!');
    }

    public function show(OrdemServico $ordens_servico)
    {
        $ordens_servico->load(['cliente', 'tecnico', 'itens', 'contasReceber']);
        return view('ordens-servico.show', ['os' => $ordens_servico]);
    }
}
