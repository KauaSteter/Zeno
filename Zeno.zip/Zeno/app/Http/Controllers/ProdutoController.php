<?php

namespace App\Http\Controllers;

use App\Models\CategoriaProduto;
use App\Models\Produto;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Illuminate\Validation\Rule;

class ProdutoController extends Controller
{
    public function index(Request $request): View
    {
        $produtos = Produto::with('categoria')
            ->when($request->filled('busca'), function ($query) use ($request) {
                $termo = trim($request->string('busca')->toString());
                $query->where(function ($query) use ($termo) {
                    $query->where('nome', 'like', "%{$termo}%")
                        ->orWhere('sku', 'like', "%{$termo}%");
                });
            })
            ->when($request->filled('categoria_id'), fn ($query) => $query->where('categoria_id', $request->input('categoria_id')))
            ->when($request->filled('status'), fn ($query) => $query->where('ativo', $request->boolean('status')))
            ->orderBy('nome')
            ->paginate(15)
            ->withQueryString();

        $categorias = CategoriaProduto::where('ativo', true)->orderBy('nome')->get();

        return view('produtos.index', compact('produtos', 'categorias'));
    }

    public function create(): View
    {
        return view('produtos.create', ['produto' => new Produto(['unidade' => 'un', 'estoque_atual' => 0, 'estoque_minimo' => 0, 'preco_custo' => 0, 'preco_venda' => 0])]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validatedData($request);
        $data['categoria_id'] = !empty($data['categoria_id']) ? $data['categoria_id'] : null;
        $data['ativo'] = true;

        if ($request->hasFile('imagem')) {
            $path = $request->file('imagem')->store('produtos', 'public');
            $data['imagem'] = $path;
        }

        Produto::create($data);

        return redirect()->route('produtos.index')->with('success', 'Produto cadastrado.');
    }

    public function edit(Produto $produto): View
    {
        return view('produtos.edit', compact('produto'));
    }

    public function update(Request $request, Produto $produto): RedirectResponse
    {
        $data = $this->validatedData($request, $produto);
        $data['categoria_id'] = !empty($data['categoria_id']) ? $data['categoria_id'] : null;
        $data['ativo'] = $request->boolean('ativo');

        if ($request->hasFile('imagem')) {
            // Remove imagem antiga
            if ($produto->imagem) {
                Storage::delete('public/' . $produto->imagem);
            }
            $path = $request->file('imagem')->store('produtos', 'public');
            $data['imagem'] = $path;
        }

        $produto->update($data);

        return redirect()->route('produtos.index')->with('success', 'Produto atualizado.');
    }

    public function destroy(Produto $produto): RedirectResponse
    {
        $produto->update(['ativo' => false]);

        return redirect()->route('produtos.index')->with('success', 'Produto desativado.');
    }

    public function estoqueBaixo(): View
    {
        $produtos = Produto::where('ativo', true)
            ->whereColumn('estoque_atual', '<', 'estoque_minimo')
            ->orderBy('estoque_atual')
            ->paginate(15);

        $totalBaixo = Produto::where('ativo', true)
            ->whereColumn('estoque_atual', '<', 'estoque_minimo')
            ->count();

        $totalAtivo = Produto::where('ativo', true)->count();

        return view('produtos.estoque-baixo', compact('produtos', 'totalBaixo', 'totalAtivo'));
    }

    private function validatedData(Request $request, ?Produto $produto = null): array
    {
        return $request->validate([
            'sku' => ['required', 'string', 'max:100', Rule::unique('produtos', 'sku')->ignore($produto?->id)],
            'nome' => ['required', 'string', 'max:255'],
            'descricao' => ['nullable', 'string'],
            'preco_custo' => ['required', 'numeric', 'min:0'],
            'preco_venda' => ['required', 'numeric', 'min:0'],
            'estoque_atual' => ['required', 'integer', 'min:0'],
            'estoque_minimo' => ['required', 'integer', 'min:0'],
            'unidade' => ['required', 'string', 'max:20'],
            'categoria_id' => ['nullable', 'string', 'max:100'],
            'ativo' => ['sometimes', 'boolean'],
            'imagem' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:5120'],
        ], [
            'imagem.image' => 'O arquivo deve ser uma imagem.',
            'imagem.mimes' => 'A imagem deve ser JPEG, PNG, JPG, GIF ou WEBP.',
        ]);
    }
}
