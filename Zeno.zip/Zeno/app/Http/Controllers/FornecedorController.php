<?php

namespace App\Http\Controllers;

use App\Models\Fornecedor;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Closure;

class FornecedorController extends Controller
{
    public function index(Request $request): View
    {
        $fornecedores = Fornecedor::query()
            ->when($request->filled('busca'), function ($query) use ($request) {
                $termo = trim($request->string('busca')->toString());
                $documento = preg_replace('/\D+/', '', $termo);
                $query->where(function ($query) use ($termo, $documento) {
                    $query->where('nome', 'like', "%{$termo}%")
                        ->orWhere('razao_social', 'like', "%{$termo}%")
                        ->orWhere('cpf_cnpj', 'like', "%{$documento}%");
                });
            })
            ->when($request->filled('status'), fn ($query) => $query->where('ativo', $request->boolean('status')))
            ->orderBy('nome')->paginate(15)->withQueryString();

        return view('fornecedores.index', compact('fornecedores'));
    }

    public function create(): View
    {
        return view('fornecedores.create', ['fornecedor' => new Fornecedor()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validatedData($request);
        $data['cpf_cnpj'] = preg_replace('/\D+/', '', $data['cpf_cnpj']);
        $data['ativo'] = true;

        Fornecedor::create($data);

        return redirect()->route('fornecedores.index')->with('success', 'Fornecedor cadastrado.');
    }

    public function edit(Fornecedor $fornecedor): View
    {
        return view('fornecedores.edit', compact('fornecedor'));
    }

    public function update(Request $request, Fornecedor $fornecedor): RedirectResponse
    {
        $data = $this->validatedData($request, $fornecedor);
        $data['cpf_cnpj'] = preg_replace('/\D+/', '', $data['cpf_cnpj']);
        $data['ativo'] = $request->boolean('ativo');
        $fornecedor->update($data);

        return redirect()->route('fornecedores.index')->with('success', 'Fornecedor atualizado.');
    }

    public function destroy(Fornecedor $fornecedor): RedirectResponse
    {
        $fornecedor->update(['ativo' => false]);

        return redirect()->route('fornecedores.index')->with('success', 'Fornecedor desativado.');
    }

    private function validatedData(Request $request, ?Fornecedor $fornecedor = null): array
    {
        $rawDocument = (string) $request->input('cpf_cnpj', '');
        $digits = preg_replace('/\D+/', '', $rawDocument);
        $uniqueRule = 'unique:fornecedores,cpf_cnpj';
        if ($fornecedor) {
            $uniqueRule .= ',id,' . $fornecedor->getKey();
        }

        $data = $request->validate([
            'nome' => ['required', 'string', 'max:255'],
            'razao_social' => ['nullable', 'string', 'max:255'],
            'cpf_cnpj' => ['required', 'string', 'max:18', $uniqueRule, function (string $attribute, mixed $value, Closure $fail) use ($digits) {
                if (strlen($digits) !== 14) {
                    $fail('O CNPJ deve conter 14 dígitos.');
                }
            }],
            'inscricao_estadual' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'telefone' => ['nullable', 'string', 'max:20'],
            'cep' => ['nullable', 'string', 'max:9'],
            'endereco' => ['nullable', 'string', 'max:255'],
            'numero' => ['nullable', 'string', 'max:10'],
            'bairro' => ['nullable', 'string', 'max:100'],
            'cidade' => ['nullable', 'string', 'max:100'],
            'estado' => ['nullable', 'string', 'size:2'],
            'observacoes' => ['nullable', 'string'],
        ]);

        $data['cpf_cnpj'] = $digits;
        $data['inscricao_estadual'] = $data['inscricao_estadual'] ?? null;

        return $data;
    }
}
