<?php

namespace App\Http\Controllers;

use App\Models\Compra;
use App\Models\Fornecedor;
use App\Models\Produto;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class CompraController extends Controller
{
    public function index(): View { return view('compras.index', ['compras' => Compra::with('fornecedor')->latest()->paginate(15)]); }
    public function create(): View { return view('compras.create', ['fornecedores' => Fornecedor::where('ativo', true)->orderBy('nome')->get(), 'produtos' => Produto::where('ativo', true)->orderBy('nome')->get()]); }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'fornecedor_id' => ['required', 'uuid', 'exists:fornecedores,id'], 'data_compra' => ['required', 'date'],
            'data_entrega_prevista' => ['nullable', 'date', 'after_or_equal:data_compra'], 'frete' => ['nullable', 'numeric', 'min:0'],
            'desconto' => ['nullable', 'numeric', 'min:0'], 'outras_despesas' => ['nullable', 'numeric', 'min:0'], 'observacoes' => ['nullable', 'string'],
            'itens' => ['required', 'array', 'min:1'], 'itens.*.produto_id' => ['required', 'uuid', 'distinct', 'exists:produtos,id'],
            'itens.*.quantidade' => ['required', 'integer', 'min:1'], 'itens.*.custo_unitario' => ['required', 'numeric', 'min:0'], 'itens.*.desconto' => ['nullable', 'numeric', 'min:0'],
        ]);
        $subtotal = 0;
        foreach ($data['itens'] as $i => $item) {
            $line = (int)$item['quantidade'] * (int)round((float)$item['custo_unitario'] * 100);
            $lineDiscount = (int)round((float)($item['desconto'] ?? 0) * 100);
            if ($lineDiscount > $line) throw ValidationException::withMessages(["itens.$i.desconto" => 'Desconto maior que o total do item.']);
            $subtotal += $line - $lineDiscount;
        }
        $discount = (int)round((float)($data['desconto'] ?? 0) * 100);
        if ($discount > $subtotal) throw ValidationException::withMessages(['desconto' => 'Desconto maior que o subtotal.']);
        $freight = (int)round((float)($data['frete'] ?? 0) * 100);
        $expenses = (int)round((float)($data['outras_despesas'] ?? 0) * 100);
        $compra = DB::transaction(function () use ($data, $request, $subtotal, $discount, $freight, $expenses) {
            $compra = Compra::create([
                'numero_compra' => 'CMP-' . now()->format('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2))),
                'fornecedor_id' => $data['fornecedor_id'], 'usuario_id' => $request->user()?->id,
                'data_compra' => $data['data_compra'], 'data_entrega_prevista' => $data['data_entrega_prevista'] ?? null,
                'subtotal' => $subtotal / 100, 'desconto' => $discount / 100, 'frete' => $freight / 100,
                'outras_despesas' => $expenses / 100, 'total' => ($subtotal - $discount + $freight + $expenses) / 100,
                'status' => 'pendente', 'observacoes' => $data['observacoes'] ?? null,
            ]);
            foreach ($data['itens'] as $item) {
                $lineTotal = (int)$item['quantidade'] * (int)round((float)$item['custo_unitario'] * 100) - (int)round((float)($item['desconto'] ?? 0) * 100);
                $compra->itens()->create(['produto_id' => $item['produto_id'], 'quantidade' => $item['quantidade'], 'quantidade_recebida' => 0, 'custo_unitario' => $item['custo_unitario'], 'desconto' => $item['desconto'] ?? 0, 'total' => $lineTotal / 100]);
            }
            return $compra;
        });
        return redirect()->route('compras.show', $compra)->with('success', 'Compra registrada como pendente; estoque não foi alterado.');
    }

    public function show(Compra $compra): View { return view('compras.show', ['compra' => $compra->load(['fornecedor', 'itens.produto'])]); }

    public function receive(Request $request, Compra $compra): RedirectResponse
    {
        DB::transaction(function () use ($compra) {
            $locked = Compra::whereKey($compra->id)->lockForUpdate()->firstOrFail();
            if (in_array($locked->status, ['recebido', 'cancelado'], true)) throw ValidationException::withMessages(['status' => 'Compra não está pendente de recebimento.']);
            foreach ($locked->itens()->lockForUpdate()->get() as $item) {
                $remaining = $item->quantidade - $item->quantidade_recebida;
                if ($remaining < 1) continue;
                $product = Produto::whereKey($item->produto_id)->lockForUpdate()->firstOrFail();
                $product->increment('estoque_atual', $remaining);
                $product->update(['preco_custo' => $item->custo_unitario]);
                $item->update(['quantidade_recebida' => $item->quantidade]);
            }
            $locked->update(['status' => 'recebido', 'data_entrega_real' => now()->toDateString()]);
        });
        return redirect()->route('compras.show', $compra)->with('success', 'Mercadoria recebida e estoque atualizado.');
    }
}
