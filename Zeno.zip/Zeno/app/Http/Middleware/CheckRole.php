<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        if (! $user || ! $user->ativo) {
            auth()->logout();
            return redirect()->route('login')->withErrors(['email' => 'Sua conta está desativada ou você não está autenticado.']);
        }

        if (empty($roles)) {
            return $next($request);
        }

        // Se o usuário for admin, acesso irrestrito
        if ($user->isAdmin()) {
            return $next($request);
        }

        // Verifica se a role do usuário bate com alguma das permitidas
        if (in_array($user->role, $roles, true)) {
            return $next($request);
        }

        abort(403, 'Acesso não autorizado para o seu perfil de usuário.');
    }
}
