<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VendaItem extends Model
{
    use HasUuids;
    public $timestamps = false; // vendas_itens possui created_at, sem updated_at.
    protected $table = 'vendas_itens';
    protected $fillable = ['venda_id', 'produto_id', 'quantidade', 'preco_unitario', 'desconto', 'total'];

    protected $casts = [
        'quantidade' => 'integer',
        'preco_unitario' => 'decimal:2',
        'desconto' => 'decimal:2',
        'total' => 'decimal:2',
    ];
    public function venda(): BelongsTo { return $this->belongsTo(Venda::class); }
    public function produto(): BelongsTo { return $this->belongsTo(Produto::class); }
}