<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Produto extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'produtos';

    protected $fillable = [
        'sku',
        'nome',
        'descricao',
        'preco_custo',
        'preco_venda',
        'estoque_atual',
        'estoque_minimo',
        'unidade',
        'categoria_id',
        'imagem',
        'ativo',
    ];

    protected $appends = ['imagem_url'];

    public function getImagemUrlAttribute(): ?string
    {
        if ($this->imagem && Storage::fileExists('produtos/' . $this->imagem)) {
            return asset('storage/produtos/' . $this->imagem);
        }
        // SVG placeholder inline - green plus icon
        return 'data:image/svg+xml;base64,' . base64_encode(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23064E3B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="7" x2="12" y2="17"></line><line x1="7" y1="12" x2="17" y2="12"></line></svg>'
        );
    }

    protected $casts = [
        'preco_custo' => 'decimal:2',
        'preco_venda' => 'decimal:2',
        'estoque_atual' => 'integer',
        'estoque_minimo' => 'integer',
        'ativo' => 'boolean',
    ];

    public function categoria()
    {
        return $this->belongsTo(CategoriaProduto::class, 'categoria_id');
    }
}