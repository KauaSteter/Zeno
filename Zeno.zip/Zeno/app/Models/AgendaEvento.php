<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AgendaEvento extends Model
{
    use HasUuids;

    protected $keyType = 'string';
    public $incrementing = false;

    use HasFactory;

    protected $table = 'agenda_eventos';

    protected $fillable = [
        'titulo',
        'descricao',
        'data_evento',
        'hora',
        'prioridade',
        'status',
        'categoria',
        'cliente_id',
        'fornecedor_id',
        'compra_id',
        'usuario_id',
        'created_by',
        'recorrencia',
        'data_fim_recorrencia',
    ];

    protected $casts = [
        'data_evento' => 'date',
        'data_fim_recorrencia' => 'date',
        'hora' => 'time:H:i',
    ];

    // Status constants
    const STATUS_PENDENTE = 'pendente';
    const STATUS_CONCLUIDO = 'concluido';
    const STATUS_CANCELADO = 'cancelado';

    // Prioridade constants
    const PRIORIDADE_ALTA = 'alta';
    const PRIORIDADE_NORMAL = 'normal';
    const PRIORIDADE_BAIXA = 'baixa';

    // Categorias constants
    const CATEGORIA_CRM = 'crm';
    const CATEGORIA_COMPRAS = 'compras';
    const CATEGORIA_FINANCEIRO = 'financeiro';
    const CATEGORIA_ESTOQUE = 'estoque';
    const CATEGORIA_OUTRO = 'outro';

    public static function getCategorias(): array
    {
        return [
            self::CATEGORIA_CRM => 'CRM',
            self::CATEGORIA_COMPRAS => 'Compras',
            self::CATEGORIA_FINANCEIRO => 'Financeiro',
            self::CATEGORIA_ESTOQUE => 'Estoque',
            self::CATEGORIA_OUTRO => 'Outro',
        ];
    }

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class);
    }

    public function fornecedor(): BelongsTo
    {
        return $this->belongsTo(Fornecedor::class);
    }

    public function compra(): BelongsTo
    {
        return $this->belongsTo(Compra::class);
    }

    public function usuario(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function criador(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function scopePorData($query, $dataInicio, $dataFim = null)
    {
        $query->where('data_evento', '>=', $dataInicio);
        
        if ($dataFim) {
            $query->where('data_evento', '<=', $dataFim);
        }
        
        return $query;
    }

    public function scopePorCategoria($query, $categoria)
    {
        return $query->where('categoria', $categoria);
    }

    public function scopePendentes($query)
    {
        return $query->where('status', self::STATUS_PENDENTE);
    }

    public function scopePorUsuario($query, $usuarioId)
    {
        return $query->where('usuario_id', $usuarioId);
    }

    public function isVencido(): bool
    {
        return $this->data_evento->isPast() && $this->status === self::STATUS_PENDENTE;
    }

    public function canMarkConcluido(User $user): bool
    {
        if ($user->isAdmin()) {
            return true;
        }
        
        return $this->usuario_id === $user->id || 
               $this->created_by === $user->id ||
               ($this->categoria === self::CATEGORIA_FINANCEIRO && $user->hasRole('financeiro'));
    }
}