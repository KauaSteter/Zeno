<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ContaReceber extends Model
{
    use HasFactory;

    protected $table = 'contas_receber';
    protected $fillable = [
        'origem',
        'origem_id',
        'cliente_id',
        'venda_id',
        'os_id',
        'numero_parcela',
        'valor',
        'desconto',
        'acrescimo',
        'valor_liquido',
        'data_vencimento',
        'data_recebimento',
        'status',
        'forma_pagamento',
        'observacoes',
    ];

    protected $casts = [
        'data_vencimento' => 'date',
        'data_recebimento' => 'datetime',
    ];

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }

    public function venda(): BelongsTo
    {
        return $this->belongsTo(Venda::class, 'venda_id');
    }

    public function ordemServico(): BelongsTo
    {
        return $this->belongsTo(OrdemServico::class, 'os_id');
    }

    public function registrarPagamento(float $valor, string $formaPagamento, ?string $observacoes = null): void
    {
        $this->update([
            'data_recebimento' => now(),
            'status' => 'recebido',
            'forma_pagamento' => $formaPagamento,
            'observacoes' => $observacoes ?? $this->observacoes,
        ]);
    }
}