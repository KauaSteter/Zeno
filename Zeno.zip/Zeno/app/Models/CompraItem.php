<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CompraItem extends Model
{
    use HasUuids;
    protected $table = 'compras_itens';
    public $timestamps = false;
    protected $fillable = ['compra_id', 'produto_id', 'quantidade', 'quantidade_recebida', 'custo_unitario', 'desconto', 'total'];
    protected function casts(): array { return ['quantidade' => 'integer', 'quantidade_recebida' => 'integer', 'custo_unitario' => 'decimal:2', 'desconto' => 'decimal:2', 'total' => 'decimal:2']; }
    public function compra(): BelongsTo { return $this->belongsTo(Compra::class); }
    public function produto(): BelongsTo { return $this->belongsTo(Produto::class); }
}
