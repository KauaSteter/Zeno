<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Compra extends Model
{
    use HasUuids;

    protected $table = 'compras';
    protected $fillable = ['numero_compra', 'fornecedor_id', 'usuario_id', 'data_compra', 'data_entrega_prevista', 'data_entrega_real', 'subtotal', 'desconto', 'frete', 'outras_despesas', 'total', 'status', 'observacoes'];
    protected function casts(): array { return ['data_compra' => 'date', 'data_entrega_prevista' => 'date', 'data_entrega_real' => 'date', 'subtotal' => 'decimal:2', 'desconto' => 'decimal:2', 'frete' => 'decimal:2', 'outras_despesas' => 'decimal:2', 'total' => 'decimal:2']; }
    public function fornecedor(): BelongsTo { return $this->belongsTo(Fornecedor::class); }
    public function itens(): HasMany { return $this->hasMany(CompraItem::class, 'compra_id'); }
}
