<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ContaPagar extends Model
{
    use HasFactory;

    protected $table = 'contas_pagar';
    protected $fillable = [
        'origem',
        'origem_id',
        'fornecedor_id',
        'compra_id',
        'os_id',
        'numero_parcela',
        'valor',
        'desconto',
        'acrescimo',
        'valor_liquido',
        'data_vencimento',
        'data_pagamento',
        'status',
        'forma_pagamento',
        'observacoes',
    ];

    protected $casts = [
        'data_vencimento' => 'date',
        'data_pagamento' => 'datetime',
    ];

    public function fornecedor(): BelongsTo
    {
        return $this->belongsTo(Fornecedor::class, 'fornecedor_id');
    }

    public function compra(): BelongsTo
    {
        return $this->belongsTo(Compra::class, 'compra_id');
    }

    public function ordemServico(): BelongsTo
    {
        return $this->belongsTo(OrdemServico::class, 'os_id');
    }

    public function registrarPagamento(float $valor, string $formaPagamento, ?string $observacoes = null): void
    {
        $this->update([
            'data_pagamento' => now(),
            'status' => 'pago',
            'forma_pagamento' => $formaPagamento,
            'observacoes' => $observacoes ?? $this->observacoes,
        ]);
    }
}
