<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class Fornecedor extends Model
{
    use HasUuids;

    protected $table = 'fornecedores';

    protected $fillable = [
        'nome',
        'razao_social',
        'cpf_cnpj',
        'inscricao_estadual',
        'email',
        'telefone',
        'cep',
        'endereco',
        'numero',
        'bairro',
        'cidade',
        'estado',
        'observacoes',
        'ativo',
    ];

    protected function casts(): array
    {
        return [
            'ativo' => 'boolean',
        ];
    }
}
