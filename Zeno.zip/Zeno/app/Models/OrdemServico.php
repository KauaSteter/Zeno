<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class OrdemServico extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'ordens_servico';
    protected $fillable = [
        'numero_os',
        'cliente_id',
        'usuario_id',
        'tecnico_id',
        'titulo',
        'descricao_problema',
        'descricao_solucao',
        'sintoma',
        'observacoes',
        // Dados automotivos/transporte (opcionais, nullable)
        'veiculo_marca',
        'veiculo_modelo',
        'veiculo_placa',
        'veiculo_ano',
        'quilometragem_entrada',
        // Valores e totais
        'mão_obra',
        'total_servicos',
        'total_produtos',
        'total_pecas',
        'total_desconto',
        'desconto',
        'total',
        'total_geral',
        // Datas
        'data_abertura',
        'data_entrada',
        'data_previsao',
        'data_entrega',
        'data_conclusao',
        // Status e fiscal
        'status',
        'prioridade',
        'nfse_emitida',
        'nfse_numero',
        'nfse_codigo_verificacao',
    ];

    protected $appends = ['total_final'];

    protected $casts = [
        'data_abertura' => 'datetime',
        'data_entrada' => 'datetime',
        'data_previsao' => 'date',
        'data_entrega' => 'datetime',
        'data_conclusao' => 'datetime',
        'total_servicos' => 'decimal:2',
        'total_produtos' => 'decimal:2',
        'total_pecas' => 'decimal:2',
        'mão_obra' => 'decimal:2',
        'total_desconto' => 'decimal:2',
        'desconto' => 'decimal:2',
        'total' => 'decimal:2',
        'total_geral' => 'decimal:2',
        'nfse_emitida' => 'boolean',
    ];

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }

    public function usuario(): BelongsTo
    {
        return $this->belongsTo(User::class, 'usuario_id');
    }

    public function tecnico(): BelongsTo
    {
        return $this->belongsTo(User::class, 'tecnico_id');
    }

    public function itens(): HasMany
    {
        return $this->hasMany(OrdemServicoItem::class, 'os_id');
    }

    public function servicos(): HasMany
    {
        return $this->hasMany(OrdemServicoItem::class, 'os_id')->where('tipo', 'servico');
    }

    public function produtos(): HasMany
    {
        return $this->hasMany(OrdemServicoItem::class, 'os_id')->where('tipo', 'peca');
    }

    public function contasReceber(): HasMany
    {
        return $this->hasMany(ContaReceber::class, 'os_id');
    }

    public function getTotalFinalAttribute(): float
    {
        return (float) ($this->total_geral ?? $this->total ?? 0);
    }
}