<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'clientes';

    protected $fillable = [
        'tipo', 'cpf_cnpj', 'nome', 'nome_fantasia', 'razao_social', 'ie', 'inscricao_municipal',
        'email', 'telefone', 'celular', 'cep', 'endereco', 'numero', 'complemento', 'bairro', 'cidade',
        'estado', 'codigo_ibge_municipio', 'limite_credito', 'credito_utilizado', 'ativo', 'observacoes',
    ];

    protected $casts = [
        'limite_credito' => 'decimal:2',
        'credito_utilizado' => 'decimal:2',
        'credito_disponivel' => 'decimal:2',
        'ativo' => 'boolean',
    ];

    public function vendas()
    {
        return $this->hasMany(Venda::class);
    }
}
