<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class CategoriaProduto extends Model
{
    use HasUuids;

    protected $table = 'categorias_produto';

    protected $fillable = [
        'nome',
        'descricao',
        'ativo',
    ];

    protected function casts(): array
    {
        return [
            'ativo' => 'boolean',
        ];
    }

    public function produtos()
    {
        return $this->hasMany(Produto::class, 'categoria_id');
    }
}