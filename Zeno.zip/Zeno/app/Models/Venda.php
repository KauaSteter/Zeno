<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Venda extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'vendas';

    protected $fillable = [
        'numero_venda',
        'cliente_id',
        'usuario_id',
        'data_venda',
        'subtotal',
        'desconto',
        'frete',
        'total',
        'forma_pagamento',
        'status_pagamento',
        'nfe_emitida',
        'nfe_numero',
        'nfe_chave',
        'nfe_xml',
        'ml_order_id',
        'origem',
        'observacoes',
    ];

    protected $casts = [
        'data_venda' => 'datetime',
        'subtotal' => 'decimal:2',
        'desconto' => 'decimal:2',
        'frete' => 'decimal:2',
        'total' => 'decimal:2',
        'nfe_emitida' => 'boolean',
    ];

    public function cliente()
    {
        return $this->belongsTo(Cliente::class);
    }

    public function vendedor()
        {
            return $this->belongsTo(User::class, 'usuario_id');
        }

        public function itens()
        {
            return $this->hasMany(VendaItem::class);
        }

        public function produtos()
        {
            return $this->belongsToMany(Produto::class, 'vendas_itens', 'venda_id', 'produto_id')->withPivot('quantidade', 'preco_unitario', 'total', 'desconto');
        }
    }
