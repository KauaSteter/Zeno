<?php

use Illuminate\Session\SessionManager;

return [
    'driver' => env('SESSION_DRIVER', 'cookie'),
    'lifetime' => env('SESSION_LIFETIME', 120),
    'expire_on_close' => false,
    'encrypt' => true,
    'secure' => env('SESSION_SECURE_COOKIE', false),
    'http_only' => true,
    'cookie' => env('SESSION_COOKIE', 'zeno-session'),
    'same_site' => 'lax',
];