<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\AgendaEventoController;
use App\Http\Controllers\CategoriaProdutoController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\CompraController;
use App\Http\Controllers\FornecedorController;
use App\Http\Controllers\ProdutoController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VendaController;
use App\Http\Controllers\OrdemServicoController;
use App\Http\Controllers\ContaReceberController;
use App\Http\Controllers\ContaPagarController;
use App\Http\Controllers\CrmController;
use App\Http\Controllers\DashboardController;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/lab-ui', function () {
    return view('lab-ui');
})->name('lab-ui');

Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'app' => 'ZENO ERP',
        'timestamp' => now()->toIso8601String()
    ]);
});

// Auth routes (guest middleware handles redirect to login)
Route::middleware(['guest', 'web'])->group(function () {
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store']);
    Route::get('/forgot-password', [App\Http\Controllers\Auth\PasswordResetLinkController::class, 'create'])->name('password.request');
    Route::post('/forgot-password', [App\Http\Controllers\Auth\PasswordResetLinkController::class, 'store'])->name('password.email');
    Route::get('/reset-password/{token}', [App\Http\Controllers\Auth\NewPasswordController::class, 'create'])->name('password.reset');
    Route::post('/reset-password', [App\Http\Controllers\Auth\NewPasswordController::class, 'store'])->name('password.update');
});

// Logout route (auth + web for session)
Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout')->middleware(['auth', 'web']);

// Protected routes
Route::middleware(['auth', 'web'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Gestão de Usuários - Admin
    Route::prefix('admin')->group(function () {
        Route::resource('usuarios', UserController::class)->names('admin.usuarios');
        Route::patch('usuarios/{usuario}/toggle', [UserController::class, 'toggleAtivo'])->name('admin.usuarios.toggle');
    });

    // Agenda de Atividades - Todos os perfis
    Route::prefix('agenda')->name('agenda.')->group(function () {
        Route::get('/', [AgendaEventoController::class, 'index'])->name('index');
        Route::get('/calendario', [AgendaEventoController::class, 'calendario'])->name('calendario');
        Route::get('/create', [AgendaEventoController::class, 'create'])->name('create');
        Route::post('/', [AgendaEventoController::class, 'store'])->name('store');
        Route::get('/{agendaEvento}/edit', [AgendaEventoController::class, 'edit'])->name('edit');
        Route::post('/{agendaEvento}/concluir', [AgendaEventoController::class, 'marcarConcluido'])->name('concluir');
        Route::get('/{agendaEvento}', [AgendaEventoController::class, 'show'])->name('show');
        Route::put('/{agendaEvento}', [AgendaEventoController::class, 'update'])->name('update');
        Route::delete('/{agendaEvento}', [AgendaEventoController::class, 'destroy'])->name('destroy');
    });

    // Clientes - Todos os perfis
    Route::resource('clientes', ClienteController::class)->except(['show']);

    // Fornecedores - Todos os perfis
    Route::resource('fornecedores', FornecedorController::class)->except(['show'])->parameters(['fornecedores' => 'fornecedor']);

    // Categorias de Produto - Admin, Gerente
    Route::resource('categorias-produto', CategoriaProdutoController::class)->except(['show'])->parameters(['categorias-produto' => 'categoria']);

    // Produtos - Admin, Gerente, Vendedor
    Route::resource('produtos', ProdutoController::class)->except(['show']);
    Route::get('/estoque/baixo', [ProdutoController::class, 'estoqueBaixo'])->name('estoque.baixo');

    // Compras - Admin, Gerente, Financeiro
    Route::get('/compras', [CompraController::class, 'index'])->name('compras.index');
    Route::get('/compras/create', [CompraController::class, 'create'])->name('compras.create');
    Route::post('/compras', [CompraController::class, 'store'])->name('compras.store');
    Route::get('/compras/{compra}', [CompraController::class, 'show'])->name('compras.show');
    Route::post('/compras/{compra}/receber', [CompraController::class, 'receive'])->name('compras.receive');

    // Vendas/PDV - Vendedor, Gerente, Financeiro

    // Pedidos de venda
    Route::get('/vendas/pedido', [VendaController::class, 'createPedido'])->name('vendas.pedido');
    Route::post('/vendas/pedido', [VendaController::class, 'storePedido'])->name('vendas.storePedido');

    // Vendas e PDV
    Route::get('/vendas', [VendaController::class, 'index'])->name('vendas.index');
    Route::get('/vendas/nova', [VendaController::class, 'create'])->name('vendas.create');
    Route::post('/vendas', [VendaController::class, 'store'])->name('vendas.store');

    // Detalhes e operações da venda
    Route::get('/vendas/{venda}', [VendaController::class, 'show'])->name('vendas.show');
    Route::post('/vendas/{venda}/finalizar', [VendaController::class, 'finalizar'])->name('vendas.finalizar');
    Route::post('/vendas/{venda}/cancelar', [VendaController::class, 'cancelar'])->name('vendas.cancelar');

    // Ordens de Serviço - Técnico, Vendedor, Gerente
    Route::resource('ordens-servico', OrdemServicoController::class);
    Route::get('/ordens-servico/{os}/finalizar', [OrdemServicoController::class, 'finalizar'])->name('ordens-servico.finalizar');

    // Contas a Receber - Financeiro, Gerente
    Route::get('/contas-receber', [ContaReceberController::class, 'index'])->name('contas-receber.index');
    Route::post('/contas-receber/{conta}/receber', [ContaReceberController::class, 'registrarPagamento'])->name('contas-receber.registrar-pagamento');

    // Contas a Pagar - Financeiro, Gerente
    Route::get('/contas-pagar', [ContaPagarController::class, 'index'])->name('contas-pagar.index');
    Route::post('/contas-pagar/{conta}/pagar', [ContaPagarController::class, 'registrarPagamento'])->name('contas-pagar.registrar-pagamento');

    // CRM - Vendedor, Gerente
    Route::prefix('crm')->name('crm.')->group(function () {
        Route::get('/', [CrmController::class, 'index'])->name('index');
        Route::get('/prospeccao', [CrmController::class, 'prospeccao'])->name('prospeccao');
        Route::post('/prospeccao', [CrmController::class, 'prospeccaoStore'])->name('prospeccao.store');
        Route::get('/prospeccao/{cliente}/contatar', [CrmController::class, 'contatar'])->name('prospeccao.contatar');
        Route::patch('/prospeccao/{cliente}', [CrmController::class, 'prospeccaoUpdate'])->name('prospeccao.update');
    });
});
