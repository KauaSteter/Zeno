#!/bin/bash
# Diagnóstico rápido LXC ZENO ERP

echo "=== DIAGNÓSTICO LXC ZENO ERP ==="

# 1. Verificar se index.php existe
echo "1. Verificando public/index.php..."
ls -la /var/www/zeno-erp-develop/public/index.php 2>&1

# 2. Verificar .env
echo -e "\n2. Verificando .env..."
if [ -f /var/www/zeno-erp-develop/.env ]; then
    grep "APP_KEY" /var/www/zeno-erp-develop/.env
    grep "DB_CONNECTION" /var/www/zeno-erp-develop/.env
else
    echo "ERRO: .env NÃO EXISTE!"
fi

# 3. Verificar bootstrap/cache
echo -e "\n3. Verificando bootstrap/cache..."
ls -la /var/www/zeno-erp-develop/bootstrap/cache/ 2>&1

# 4. Verificar storage
echo -e "\n4. Verificando storage..."
ls -la /var/www/zeno-erp-develop/storage/ 2>&1

# 5. Verificar Nginx config
echo -e "\n5. Verificando Nginx..."
cat /etc/nginx/sites-enabled/zeno-erp 2>&1 | head -15

# 6. Verificar PHP-FPM
echo -e "\n6. Verificando PHP-FPM..."
ps aux | grep php-fpm | head -3
ls -la /run/php/php8.2-fpm.sock 2>&1

# 7. Testar Laravel
echo -e "\n7. Testando Laravel com HTTP..."
curl -s -I http://localhost/health 2>&1 | head -5

# 8. Logs recentes
echo -e "\n8. Últimos erros do Nginx..."
tail -5 /var/log/nginx/error.log 2>&1

echo -e "\n=== FIM DIAGNÓSTICO ==="