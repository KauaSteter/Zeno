#!/bin/bash
# Script de setup para LXC - ZENO ERP
# Usage: ./scripts/setup-lxc.sh

set -e

echo "=== Setup ZENO ERP no LXC ==="

# 1. Verificar conexão com o banco
echo "Verificando conexão com Supabase..."
if [ -z "$DB_HOST" ] || [ -z "$DB_USERNAME" ] || [ -z "$DB_PASSWORD" ]; then
    echo "ERRO: Variáveis de ambiente do banco não configuradas!"
    echo "Adicione ao seu .env ou exporte as variáveis:"
    echo "  export DB_HOST='aws-0-sa-east-1.pooler.supabase.com'"
    echo "  export DB_DATABASE='postgres'"
    echo "  export DB_USERNAME='seu-uuid-projeto'"
    echo "  export DB_PASSWORD='sua-senha'"
    exit 1
fi

# 2. Verificar se o artisan existe
if [ ! -f "artisan" ]; then
    echo "ERRO: artisan não encontrado!"
    echo "Execute este script no diretório raiz do projeto ZENO ERP"
    exit 1
fi

# 3. Gerar APP_KEY se não existir
echo "Gerando APP_KEY..."
php artisan key:generate --no-interaction

# 4. Migrar banco
echo "Executando migrations..."
php artisan migrate --force

# 5. Seed admin (opcional)
read -p "Criar usuário admin de teste? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    php artisan db:seed --force
    echo "Usuário admin criado: admin@zeno.erp / pires274168"
fi

# 6. Cache de configurações
echo "Cacheando configurações..."
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 7. Permissões
echo "Ajustando permissões..."
chmod -R 775 storage bootstrap/cache

echo "=== Setup concluído! ==="
echo "Acesse: http://seu-lxc-ip:porta"