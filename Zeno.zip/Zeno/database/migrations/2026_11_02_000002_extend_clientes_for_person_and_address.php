<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            $table->string('tipo', 2)->default('PF');
            $table->string('razao_social', 255)->nullable();
            $table->string('nome_fantasia', 255)->nullable();
            $table->string('inscricao_municipal', 20)->nullable();
            $table->string('celular', 20)->nullable();
            $table->string('whatsapp', 20)->nullable();
            $table->string('cep', 9)->nullable();
            $table->string('numero', 10)->nullable();
            $table->string('complemento', 100)->nullable();
            $table->string('bairro', 100)->nullable();
            $table->string('cidade', 100)->nullable();
            $table->string('estado', 2)->nullable();
            $table->string('codigo_ibge_municipio', 7)->nullable();
            $table->decimal('credito_utilizado', 15, 2)->default(0);
            $table->text('observacoes')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            $table->dropColumn([
                'tipo', 'razao_social', 'nome_fantasia', 'inscricao_municipal',
                'celular', 'whatsapp', 'cep', 'numero', 'complemento', 'bairro',
                'cidade', 'estado', 'codigo_ibge_municipio', 'credito_utilizado', 'observacoes'
            ]);
        });
    }
};
