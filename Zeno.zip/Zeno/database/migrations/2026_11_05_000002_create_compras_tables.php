<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('compras', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('numero_compra', 20)->unique();
            $table->foreignUuid('fornecedor_id')->nullable()->constrained('fornecedores')->restrictOnDelete();
            $table->foreignUuid('usuario_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('data_compra');
            $table->date('data_entrega_prevista')->nullable();
            $table->date('data_entrega_real')->nullable();
            $table->decimal('subtotal', 15, 2)->default(0);
            $table->decimal('desconto', 15, 2)->default(0);
            $table->decimal('frete', 15, 2)->default(0);
            $table->decimal('outras_despesas', 15, 2)->default(0);
            $table->decimal('total', 15, 2);
            $table->string('status', 50)->default('pendente');
            $table->text('observacoes')->nullable();
            $table->timestamps();
            $table->index('fornecedor_id');
            $table->index('data_compra');
            $table->index('status');
        });

        Schema::create('compras_itens', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('compra_id')->constrained('compras')->cascadeOnDelete();
            $table->foreignUuid('produto_id')->constrained('produtos')->restrictOnDelete();
            $table->unsignedInteger('quantidade');
            $table->unsignedInteger('quantidade_recebida')->default(0);
            $table->decimal('custo_unitario', 15, 2);
            $table->decimal('desconto', 15, 2)->default(0);
            $table->decimal('total', 15, 2);
            $table->timestamp('created_at')->nullable();
            $table->index('compra_id');
            $table->index('produto_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('compras_itens');
        Schema::dropIfExists('compras');
    }
};
