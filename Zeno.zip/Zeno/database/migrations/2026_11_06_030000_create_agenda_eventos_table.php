<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('agenda_eventos', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('titulo');
            $table->text('descricao')->nullable();
            $table->date('data_evento');
            $table->time('hora')->nullable();
            $table->string('prioridade')->default('normal')->comment('alta, normal, baixa');
            $table->string('status')->default('pendente')->comment('pendente, concluido, cancelado');
            $table->string('categoria')->comment('crm, compras, financeiro, estoque, outro');
            
            // Referências
            $table->uuid('cliente_id')->nullable();
            $table->uuid('fornecedor_id')->nullable();
            $table->uuid('compra_id')->nullable();
            $table->uuid('usuario_id')->nullable();
            $table->uuid('created_by')->nullable();
            
            // Recorrência
            $table->string('recorrencia')->default('nunca')->comment('nunca, diario, semanal, quinzenal, mensal');
            $table->date('data_fim_recorrencia')->nullable();
            
            $table->timestamps();
            
            // Foreign keys
            $table->foreign('cliente_id')->references('id')->on('clientes')->onDelete('set null');
            $table->foreign('fornecedor_id')->references('id')->on('fornecedores')->onDelete('set null');
            $table->foreign('compra_id')->references('id')->on('compras')->onDelete('set null');
            $table->foreign('usuario_id')->references('id')->on('users')->onDelete('set null');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
        });

        // Índices
        Schema::table('agenda_eventos', function (Blueprint $table) {
            $table->index('data_evento');
            $table->index('categoria');
            $table->index('status');
            $table->index('usuario_id');
            $table->index('cliente_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('agenda_eventos');
    }
};