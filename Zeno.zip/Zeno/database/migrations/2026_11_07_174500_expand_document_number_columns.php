<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('compras', function (Blueprint $table) {
            $table->string('numero_compra', 50)->change();
        });

        Schema::table('vendas', function (Blueprint $table) {
            $table->string('numero_venda', 50)->change();
        });

        Schema::table('ordens_servico', function (Blueprint $table) {
            $table->string('numero_os', 50)->change();
        });

        if (Schema::hasTable('devolucoes')) {
            Schema::table('devolucoes', function (Blueprint $table) {
                $table->string('numero_devolucao', 50)->change();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('compras', function (Blueprint $table) {
            $table->string('numero_compra', 20)->change();
        });

        Schema::table('vendas', function (Blueprint $table) {
            $table->string('numero_venda', 20)->change();
        });

        Schema::table('ordens_servico', function (Blueprint $table) {
            $table->string('numero_os', 20)->change();
        });

        if (Schema::hasTable('devolucoes')) {
            Schema::table('devolucoes', function (Blueprint $table) {
                $table->string('numero_devolucao', 20)->change();
            });
        }
    }
};
