<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendas_itens', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('venda_id');
            $table->uuid('produto_id');
            $table->integer('quantidade');
            $table->decimal('preco_unitario', 15, 2);
            $table->decimal('desconto', 15, 2)->default(0);
            $table->decimal('total', 15, 2);
            $table->timestamp('created_at')->useCurrent();

            $table->foreign('venda_id')->references('id')->on('vendas')->onDelete('cascade');
            $table->foreign('produto_id')->references('id')->on('produtos');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendas_itens');
    }
};