<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendas', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('numero_venda', 50)->unique();
            $table->uuid('cliente_id')->nullable();
            $table->uuid('usuario_id')->nullable();
            $table->timestamp('data_venda')->useCurrent();
            $table->decimal('subtotal', 15, 2)->default(0);
            $table->decimal('desconto', 15, 2)->default(0);
            $table->decimal('frete', 15, 2)->default(0);
            $table->decimal('total', 15, 2)->default(0);
            $table->string('forma_pagamento')->nullable();
            $table->string('status_pagamento')->default('pendente');
            $table->boolean('nfe_emitida')->default(false);
            $table->string('nfe_numero')->nullable();
            $table->string('nfe_chave')->nullable();
            $table->text('nfe_xml')->nullable();
            $table->string('ml_order_id')->nullable();
            $table->string('origem')->default('loja');
            $table->text('observacoes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendas');
    }
};