<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'nome' => 'Administrador',
            'email' => 'admin@zeno.erp',
            'password' => Hash::make('pires274168'), // Mesma senha do Jenkins
            'cpf' => '000.000.00-00',
            'telefone' => '(00) 00000-0000',
            'role' => 'admin',
            'ativo' => true,
        ]);

        $this->command->info('Usuário admin criado com sucesso!');
    }
}