<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SeedPdv extends Seeder
{
    public function run(): void
    {
        $produtos = [
            [
                'sku' => 'PROD-001',
                'nome' => 'Notebook Pro X',
                'descricao' => 'Notebook Intel Core i7, 16GB RAM, 512GB SSD',
                'custo_compra' => 2800.00,
                'margem_lucro' => 25.00,
                'preco_venda' => 3500.00,
                'estoque_atual' => 10,
                'estoque_minimo' => 2,
                'unidade_medida' => 'un',
                'ativo' => true,
            ],
            [
                'sku' => 'PROD-002',
                'nome' => 'Mouse Wireless MX',
                'descricao' => 'Mouse sem fio ergonômico, 4000 DPI, bateria 70 dias',
                'custo_compra' => 80.00,
                'margem_lucro' => 87.50,
                'preco_venda' => 150.00,
                'estoque_atual' => 25,
                'estoque_minimo' => 5,
                'unidade_medida' => 'un',
                'ativo' => true,
            ],
            [
                'sku' => 'PROD-003',
                'nome' => 'Teclado RGB Mecânico',
                'descricao' => 'Teclado mecânico switch blue, RGB personalizável, ABNT2',
                'custo_compra' => 180.00,
                'margem_lucro' => 77.78,
                'preco_venda' => 320.00,
                'estoque_atual' => 15,
                'estoque_minimo' => 3,
                'unidade_medida' => 'un',
                'ativo' => true,
            ],
            [
                'sku' => 'PROD-004',
                'nome' => 'Webcam HD 1080p',
                'descricao' => 'Webcam Full HD com microfone embutido, foco automático',
                'custo_compra' => 120.00,
                'margem_lucro' => 83.33,
                'preco_venda' => 220.00,
                'estoque_atual' => 20,
                'estoque_minimo' => 4,
                'unidade_medida' => 'un',
                'ativo' => true,
            ],
        ];

        foreach ($produtos as $produto) {
            \App\Models\Produto::updateOrInsert(
                ['sku' => $produto['sku']],
                $produto
            );
        }

        $this->command->info('✅ 4 produtos de teste carregados para PDV!');
    }
}