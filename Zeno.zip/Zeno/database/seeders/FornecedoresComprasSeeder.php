<?php

namespace Database\Seeders;

use App\Models\Fornecedor;
use Illuminate\Database\Seeder;

class FornecedoresComprasSeeder extends Seeder
{
    public function run(): void
    {
        Fornecedor::firstOrCreate(
            ['cnpj_cpf' => '11.222.333/0001-81'],
            [
                'nome' => 'Tech Supply Ltda',
                'razao_social' => 'Tech Supply Ltda',
                'email' => 'contato@techsupply.com.br',
                'telefone' => '(11) 3333-4444',
                'celular' => '(11) 99999-1111',
                'site' => 'https://techsupply.com.br',
                'endereco' => 'Rua das Empresas, 123',
                'numero' => '123',
                'complemento' => 'Sala 101',
                'bairro' => 'Empresarial',
                'cidade' => 'São Paulo',
                'estado' => 'SP',
                'cep' => '01234-567',
                'responsavel' => 'João Silva',
                'pagamento_padrao' => 'pix',
                'prazo_entrega_dias' => 3,
                'ativa' => true,
            ]
        );

        Fornecedor::firstOrCreate(
            ['cnpj_cpf' => '22.333.444/0001-99'],
            [
                'nome' => 'Supply Center MT',
                'razao_social' => 'Supply Center MT',
                'email' => 'vendas@supplycenter.com.br',
                'telefone' => '(31) 3333-5555',
                'celular' => '(31) 98888-2222',
                'site' => 'https://supplycenter.com.br',
                'endereco' => 'Av. das Indústrias, 456',
                'numero' => '456',
                'bairro' => 'Industrial',
                'cidade' => 'Belo Horizonte',
                'estado' => 'MG',
                'cep' => '31234-567',
                'responsavel' => 'Maria Oliveira',
                'pagamento_padrao' => 'boleto',
                'prazo_entrega_dias' => 7,
                'ativa' => true,
            ]
        );

        $this->command->info('Fornecedores criados com sucesso!');
    }
}