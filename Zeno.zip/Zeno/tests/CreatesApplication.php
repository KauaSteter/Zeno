<?php

namespace Tests;

use Illuminate\Contracts\Console\Kernel;
use Illuminate\Foundation\Application;

trait CreatesApplication
{
    public function createApplication(): Application
    {
        $app = require __DIR__.'/../bootstrap/app.php';

        $app->make(Kernel::class)->bootstrap();

        $app['config']->set('session.driver', 'file');
        $app['config']->set('session.lifetime', 120);
        $app['config']->set('cache.store', 'file');
        $app['config']->set('queue.default', 'sync');

        return $app;
    }
}