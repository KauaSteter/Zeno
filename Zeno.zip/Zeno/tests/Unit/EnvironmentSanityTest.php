<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class EnvironmentSanityTest extends TestCase
{
    /**
     * Test basic PHP functionality and framework constants.
     */
    public function test_basic_arithmetic_and_string_functions(): void
    {
        $this->assertEquals(4, 2 + 2);
        $this->assertTrue(str_contains('ZENO ERP', 'ZENO'));
    }

    /**
     * Test Brazilian financial calculations (markup / margin).
     */
    public function test_pricing_calculation(): void
    {
        $custo = 100.00;
        $margem = 50.00; // 50%
        $precoVenda = $custo * (1 + ($margem / 100));

        $this->assertEquals(150.00, $precoVenda);
    }
}
