<?php

namespace Tests\Feature;

use App\Models\Cliente;
use App\Models\OrdemServico;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Helper para criar fixtures de teste de Ordens de Serviço.
 * Use diretamente Model::create() para evitar dependência de factories inexistentes.
 */
class OrdemServicoTest extends TestCase
{
    use RefreshDatabase;

    private User $user;
    private Cliente $cliente;

    protected function setUp(): void
    {
        parent::setUp();

        $this->user = User::create([
            'nome' => 'Operador Teste',
            'email' => 'operador.os@zeno.test',
            'cpf' => '12345678901',
            'password' => bcrypt('password'),
        ]);
    }

    protected function createCliente(string $nome, string $tipo = 'PF', string $cpfCnpj = null): Cliente
    {
        return Cliente::create([
            'tipo' => $tipo,
            'nome' => $nome,
            'cpf_cnpj' => $cpfCnpj ?? ($tipo === 'PF' ? '111.444.777-35' : '11.111.111/0001-99'),
            'telefone' => '11999998888',
        ]);
    }

    protected function createOsPayload(Cliente $cliente, array $overrides = []): array
    {
        $base = [
            'cliente_id' => $cliente->id,
            'titulo' => 'Atendimento Padrão',
            'descricao_problema' => 'Teste de descrição do problema',
            'mão_obra' => 100.00,
            'itens' => [
                [
                    'tipo' => 'servico',
                    'nome' => 'Serviço padrão',
                    'quantidade' => 1,
                    'valor_unitario' => 100.00,
                ],
            ],
        ];

        return array_merge($base, $overrides);
    }

    public function test_can_list_ordens_de_servico(): void
    {
        $response = $this->actingAs($this->user)->get(route('ordens-servico.index'));

        $response->assertOk();
        $response->assertViewIs('ordens-servico.index');
    }

    public function test_can_render_create_page(): void
    {
        $response = $this->actingAs($this->user)->get(route('ordens-servico.create'));

        $response->assertOk();
        $response->assertViewIs('ordens-servico.create');
    }

    public function test_can_create_ordem_de_servico_com_veiculo(): void
    {
        $cliente = Cliente::create([
            'tipo' => 'PF',
            'nome' => 'Carlos Silva',
            'cpf_cnpj' => '11122233344',
            'telefone' => '11999998888',
        ]);

        $payload = [
            'cliente_id' => $cliente->id,
            'veiculo_marca' => 'Toyota',
            'veiculo_modelo' => 'Corolla',
            'veiculo_placa' => 'ABC1D23',
            'veiculo_ano' => 2020,
            'quilometragem_entrada' => 50000,
            'sintoma' => 'Barulho na suspensao dianteira',
            'observacoes' => 'Cliente aguarda retorno',
            'mão_obra' => 250.00,
            'itens' => [
                [
                    'tipo' => 'servico',
                    'nome' => 'Alinhamento e Balanceamento',
                    'quantidade' => 1,
                    'valor_unitario' => 120.00,
                ],
                [
                    'tipo' => 'peca',
                    'nome' => 'Bucha da Bandeja',
                    'quantidade' => 2,
                    'valor_unitario' => 65.00,
                ],
            ],
        ];

        $response = $this->actingAs($this->user)->post(route('ordens-servico.store'), $payload);

        $response->assertSessionHasNoErrors();
        $response->assertRedirect();

        $this->assertDatabaseHas('ordens_servico', [
            'cliente_id' => $cliente->id,
            'veiculo_marca' => 'Toyota',
            'veiculo_modelo' => 'Corolla',
            'veiculo_placa' => 'ABC1D23',
            'mão_obra' => 250.00,
            'total_pecas' => 130.00,
            'total_servicos' => 370.00, // 120 item + 250 mao de obra
            'total_geral' => 500.00,    // 130 pecas + 370 servicos
        ]);

        $os = OrdemServico::firstOrFail();

        $this->assertCount(2, $os->itens);
        $this->assertEquals(500.00, (float) $os->total_geral);

        $showResponse = $this->actingAs($this->user)->get(route('ordens-servico.show', $os));
        $showResponse->assertOk();
        $showResponse->assertSee('ABC1D23');
        $showResponse->assertSee('Toyota');
        $showResponse->assertSee('Corolla');
    }

    public function test_can_create_ordem_de_servico_sem_veiculo(): void
    {
        $cliente = Cliente::create([
            'nome' => 'Empresa XYZ Ltda',
            'tipo' => 'pj',
            'cpf_cnpj' => '99888777000166',
        ]);

        $payload = [
            'cliente_id' => $cliente->id,
            'titulo' => 'Conserto de Servidor e Rede',
            'descricao_problema' => 'Falha na fonte de alimentação e configuração de switch',
            'mão_obra' => 300.00,
            'total_desconto' => 50.00,
            'itens' => [
                [
                    'tipo' => 'servico',
                    'nome' => 'Configuração de Switch Gerenciável',
                    'quantidade' => 1,
                    'valor_unitario' => 200.00,
                ],
                [
                    'tipo' => 'peca',
                    'nome' => 'Fonte Redundante 500W',
                    'quantidade' => 1,
                    'valor_unitario' => 350.00,
                ],
            ],
        ];

        $response = $this->actingAs($this->user)->post(route('ordens-servico.store'), $payload);

        $response->assertSessionHasNoErrors();
        $response->assertRedirect();

        $this->assertDatabaseHas('ordens_servico', [
            'cliente_id' => $cliente->id,
            'titulo' => 'Conserto de Servidor e Rede',
            'veiculo_modelo' => null,
            'veiculo_placa' => null,
            'total_servicos' => 500.00,
            'total_produtos' => 350.00,
            'desconto' => 50.00,
            'total_geral' => 800.00,
        ]);

        $os = OrdemServico::where('titulo', 'Conserto de Servidor e Rede')->firstOrFail();
        $showResponse = $this->actingAs($this->user)->get(route('ordens-servico.show', $os));
        $showResponse->assertOk();
        $showResponse->assertSee('Conserto de Servidor e Rede');
        $showResponse->assertDontSee('🚗 Veículo / Transporte do Atendimento');
    }
}
