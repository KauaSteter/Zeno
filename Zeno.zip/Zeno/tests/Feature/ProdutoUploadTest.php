<?php

namespace Tests\Feature;

use App\Models\Produto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ProdutoUploadTest extends TestCase
{
    use RefreshDatabase;

    public function test_produto_pode_ser_criado_sem_imagem(): void
    {
        $user = User::create(['nome' => 'Upload Tester', 'email' => uniqid('upload-') . '@test.local', 'password' => 'password']);
        $response = $this->actingAs($user)->post(route('produtos.store'), [
            'sku' => 'UP-001', 'nome' => 'Produto sem Imagem', 'descricao' => 'Teste de criação',
            'preco_custo' => 10.00, 'preco_venda' => 20.00, 'estoque_atual' => 10,
            'estoque_minimo' => 5, 'unidade' => 'un',
        ]);
        $response->assertRedirect(route('produtos.index'));
        $this->assertDatabaseHas('produtos', ['sku' => 'UP-001', 'nome' => 'Produto sem Imagem']);
        $produto = Produto::where('sku', 'UP-001')->first();
        $this->assertNotNull($produto->imagem_url);
    }

    public function test_produto_pode_ser_criado_com_imagem(): void
    {
        Storage::fake('public');
        $user = User::create(['nome' => 'Upload Tester', 'email' => uniqid('upload-') . '@test.local', 'password' => 'password']);
        $response = $this->actingAs($user)->post(route('produtos.store'), [
            'sku' => 'UP-002', 'nome' => 'Produto com Imagem', 'preco_custo' => 10.00,
            'preco_venda' => 20.00, 'estoque_atual' => 10, 'estoque_minimo' => 5,
            'unidade' => 'un', 'imagem' => UploadedFile::fake()->create('produto.jpg', 100, 'image/jpeg'),
        ]);
        $response->assertRedirect(route('produtos.index'));
        $this->assertDatabaseHas('produtos', ['sku' => 'UP-002']);
        $produto = Produto::where('sku', 'UP-002')->first();
        $this->assertNotNull($produto->imagem);
        Storage::disk('public')->assertExists($produto->imagem);
    }

    public function test_produto_imagen_url_fallback_to_placeholder(): void
    {
        $produto = Produto::create([
            'sku' => 'NO-IMG', 'nome' => 'Produto sem imagem', 'preco_custo' => 10.00,
            'preco_venda' => 20.00, 'estoque_atual' => 10, 'estoque_minimo' => 5,
            'unidade' => 'un', 'ativo' => true, 'imagem' => null,
        ]);
        $this->assertNotNull($produto->imagem_url);
        $this->assertStringContainsString('data:image/svg+xml;base64', $produto->imagem_url);
    }
}
