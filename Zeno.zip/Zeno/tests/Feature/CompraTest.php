<?php

namespace Tests\Feature;

use App\Models\Fornecedor;
use App\Models\Produto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CompraTest extends TestCase
{
    use RefreshDatabase;

    private function fixtures(): array
    {
        $user = User::create(['nome' => 'Operador', 'email' => uniqid('compra-').'@test.local', 'password' => 'password']);
        $supplier = Fornecedor::create(['tipo' => 'PJ', 'nome' => 'Fornecedor', 'cpf_cnpj' => '12345678000199']);
        $product = Produto::create(['sku' => uniqid('SKU'), 'nome' => 'Produto', 'preco_custo' => 5, 'preco_venda' => 10, 'estoque_atual' => 3, 'ativo' => true]);
        return [$user, $supplier, $product];
    }

    public function test_stock_changes_only_when_purchase_is_received_and_not_twice(): void
    {
        [$user, $supplier, $product] = $this->fixtures();
        $response = $this->actingAs($user)->post(route('compras.store'), [
            'fornecedor_id' => $supplier->id, 'data_compra' => now()->toDateString(),
            'itens' => [['produto_id' => $product->id, 'quantidade' => 4, 'custo_unitario' => '7.25', 'desconto' => 0]],
        ]);
        $compra = \App\Models\Compra::firstOrFail();
        $response->assertRedirect(route('compras.show', $compra));
        $this->assertDatabaseHas('produtos', ['id' => $product->id, 'estoque_atual' => 3]);
        $this->actingAs($user)->post(route('compras.receive', $compra))->assertRedirect(route('compras.show', $compra));
        $this->assertDatabaseHas('produtos', ['id' => $product->id, 'estoque_atual' => 7, 'preco_custo' => 7.25]);
        $this->actingAs($user)->post(route('compras.receive', $compra));
        $this->assertDatabaseHas('produtos', ['id' => $product->id, 'estoque_atual' => 7]);
        $this->assertDatabaseHas('compras_itens', ['compra_id' => $compra->id, 'quantidade_recebida' => 4]);
    }

    public function test_purchase_rejects_duplicate_product_lines_and_keeps_stock_unchanged(): void
    {
        [$user, $supplier, $product] = $this->fixtures();
        $this->actingAs($user)->from(route('compras.create'))->post(route('compras.store'), [
            'fornecedor_id' => $supplier->id, 'data_compra' => now()->toDateString(),
            'itens' => [
                ['produto_id' => $product->id, 'quantidade' => 1, 'custo_unitario' => 4],
                ['produto_id' => $product->id, 'quantidade' => 2, 'custo_unitario' => 4],
            ],
        ])->assertSessionHasErrors(['itens.1.produto_id']);
        $this->assertDatabaseHas('produtos', ['id' => $product->id, 'estoque_atual' => 3]);
        $this->assertDatabaseCount('compras', 0);
    }
}
