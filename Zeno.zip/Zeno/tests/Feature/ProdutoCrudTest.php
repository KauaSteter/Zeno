<?php

namespace Tests\Feature;

use App\Models\Produto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProdutoCrudTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_from_produto_pages(): void
    {
        $this->get(route('produtos.index'))->assertRedirect(route('login'));
    }

    public function test_authenticated_user_can_create_a_produto(): void
    {
        $user = User::create([
            'nome' => 'Operador',
            'email' => 'operador@example.test',
            'password' => 'password',
        ]);

        $response = $this->actingAs($user)
            ->post(route('produtos.store'), [
                'sku' => 'TEST-CREATE-001',
                'nome' => 'Café Gourmet 500g',
                'descricao' => 'Café arábica torrado e moído',
                'preco_custo' => '15.00',
                'preco_venda' => '29.90',
                'estoque_atual' => '50',
                'estoque_minimo' => '10',
                'unidade' => 'pct',
                'categoria_id' => 'Bebidas',
            ]);

        $produto = Produto::first();
        $response->assertRedirect(route('produtos.index'));
        $this->assertNotNull($produto);
        $this->assertSame('TEST-CREATE-001', $produto->sku);
        $this->assertDatabaseHas('produtos', ['id' => $produto->id, 'ativo' => true]);
    }

    public function test_produto_can_be_updated_and_deactivated(): void
    {
        $user = User::create([
            'nome' => 'Operador',
            'email' => 'operador2@example.test',
            'password' => 'password',
        ]);

        $produto = Produto::create([
            'sku' => 'TEST-UPDATE-001',
            'nome' => 'Açúcar Cristal',
            'preco_custo' => '4.00',
            'preco_venda' => '7.50',
            'estoque_atual' => 100,
            'estoque_minimo' => 20,
            'unidade' => 'kg',
            'ativo' => true,
        ]);

        $response = $this->actingAs($user)
            ->put(route('produtos.update', $produto), [
                'sku' => 'TEST-UPDATE-001',
                'nome' => 'Açúcar Cristal Orgânico',
                'preco_custo' => '4.50',
                'preco_venda' => '8.90',
                'estoque_atual' => 90,
                'estoque_minimo' => 15,
                'unidade' => 'kg',
                'ativo' => 1,
            ]);

        $response->assertRedirect(route('produtos.index'));
        $this->assertDatabaseHas('produtos', [
            'id' => $produto->id,
            'nome' => 'Açúcar Cristal Orgânico',
        ]);

        $this->actingAs($user)
            ->delete(route('produtos.destroy', $produto));

        $this->assertDatabaseHas('produtos', ['id' => $produto->id, 'ativo' => false]);
    }

    public function test_duplicate_sku_and_invalid_prices_are_rejected(): void
    {
        $user = User::create([
            'nome' => 'Operador',
            'email' => 'operador3@example.test',
            'password' => 'password',
        ]);

        Produto::create([
            'sku' => 'TEST-DUP-001',
            'nome' => 'Produto Existente',
            'preco_custo' => '10.00',
            'preco_venda' => '20.00',
            'estoque_atual' => 10,
            'estoque_minimo' => 2,
            'unidade' => 'un',
            'ativo' => true,
        ]);

        $this->actingAs($user)
            ->from(route('produtos.create'))
            ->post(route('produtos.store'), [
                'sku' => 'TEST-DUP-001',
                'nome' => 'Outro Produto',
                'preco_custo' => '10.00',
                'preco_venda' => '20.00',
                'estoque_atual' => 10,
                'estoque_minimo' => 2,
                'unidade' => 'un',
            ])
            ->assertSessionHasErrors(['sku']);

        $this->actingAs($user)
            ->post(route('produtos.store'), [
                'sku' => 'TEST-NEW-001',
                'nome' => 'Produto Novo',
                'preco_custo' => '-5.00',
                'preco_venda' => '20.00',
                'estoque_atual' => 10,
                'estoque_minimo' => 2,
                'unidade' => 'un',
            ])
            ->assertSessionHasErrors(['preco_custo']);
    }
}
