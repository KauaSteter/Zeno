<?php

namespace Tests\Feature;

use App\Models\Produto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class EstoqueBaixoTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_from_estoque_baixo(): void
    {
        $this->get(route('estoque.baixo'))->assertRedirect(route('login'));
    }

    public function test_estoque_baixo_shows_products_below_minimum(): void
    {
        $user = User::create([
            'nome' => 'Operador',
            'email' => 'operador@estoque.test',
            'password' => 'password',
        ]);

        Produto::create([
            'sku' => 'EST-001',
            'nome' => 'Produto Crítico',
            'preco_custo' => 10.00,
            'preco_venda' => 20.00,
            'estoque_atual' => 2,
            'estoque_minimo' => 10,
            'unidade' => 'un',
            'ativo' => true,
        ]);

        Produto::create([
            'sku' => 'EST-002',
            'nome' => 'Produto Normal',
            'preco_custo' => 15.00,
            'preco_venda' => 30.00,
            'estoque_atual' => 50,
            'estoque_minimo' => 10,
            'unidade' => 'un',
            'ativo' => true,
        ]);

        $response = $this->actingAs($user)
            ->get(route('estoque.baixo'));

        $response->assertStatus(200);

        $html = $response->getContent();
        $this->assertStringContainsString('Estoque Baixo', $html);
        $this->assertStringContainsString('Produto Crítico', $html);
        $this->assertMatchesRegularExpression('/SKU:\s*(?:<[^>]+>\s*)*EST-001/', $html);
        $this->assertStringNotContainsString('Produto Normal', $html);
    }
}
