<?php

namespace Tests\Feature;

use App\Models\Cliente;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ClienteCrudTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_from_cliente_pages(): void
    {
        $this->get(route('clientes.index'))->assertRedirect(route('login'));
    }

    public function test_authenticated_user_can_create_a_cliente(): void
    {
        $this->actingAs(User::create([
            'nome' => 'Operador', 'email' => 'operador@example.test', 'password' => 'password',
        ]));

        $response = $this->post(route('clientes.store'), [
            'tipo' => 'PF', 'cpf_cnpj' => '123.456.789-09', 'nome' => 'Maria de Souza',
            'email' => 'maria@example.test', 'telefone' => '(11) 99999-1111', 'cep' => '01001-000',
            'endereco' => 'Praça da Sé', 'numero' => '10', 'cidade' => 'São Paulo', 'estado' => 'SP',
            'limite_credito' => '1500.00',
        ]);

        $cliente = Cliente::first();
        $response->assertRedirect(route('clientes.index'));
        $this->assertNotNull($cliente);
        $this->assertSame('12345678909', $cliente->cpf_cnpj);
        $this->assertSame('Maria de Souza', $cliente->nome);
        $this->assertDatabaseHas('clientes', ['id' => $cliente->id, 'ativo' => true]);
    }

    public function test_cliente_can_be_updated_and_deactivated_without_deleting_the_record(): void
    {
        $user = User::create([
            'nome' => 'Operador', 'email' => 'operador@example.test', 'password' => 'password',
        ]);
        $cliente = Cliente::create([
            'tipo' => 'PJ', 'cpf_cnpj' => '12345678000199', 'nome' => 'Empresa Exemplo', 'ativo' => true,
        ]);

        $this->actingAs($user)->put(route('clientes.update', $cliente), [
            'tipo' => 'PJ', 'cpf_cnpj' => '12.345.678/0001-99', 'nome' => 'Empresa Atualizada',
            'nome_fantasia' => 'Fantasia Nova', 'ativo' => '1',
        ])->assertRedirect(route('clientes.index'));

        $this->assertDatabaseHas('clientes', [
            'id' => $cliente->id, 'nome' => 'Empresa Atualizada', 'nome_fantasia' => 'Fantasia Nova', 'ativo' => true,
        ]);

        $this->actingAs($user)->delete(route('clientes.destroy', $cliente));
        $this->assertDatabaseHas('clientes', ['id' => $cliente->id, 'ativo' => false]);
    }

    public function test_duplicate_document_and_invalid_person_type_are_rejected(): void
    {
        $user = User::create([
            'nome' => 'Operador', 'email' => 'operador@example.test', 'password' => 'password',
        ]);
        Cliente::create([
            'tipo' => 'PF', 'cpf_cnpj' => '12345678909', 'nome' => 'Cliente Existente', 'ativo' => true,
        ]);

        $this->actingAs($user)->from(route('clientes.create'))->post(route('clientes.store'), [
            'tipo' => 'PJ', 'cpf_cnpj' => '12345678909', 'nome' => 'Duplicado',
        ])->assertSessionHasErrors(['cpf_cnpj']);

        $this->post(route('clientes.store'), [
            'tipo' => 'XX', 'cpf_cnpj' => '12345678901234', 'nome' => 'Tipo Invalido',
        ])->assertSessionHasErrors(['tipo']);
    }
}
