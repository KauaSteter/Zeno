<?php

namespace Tests\Feature;

use App\Models\Fornecedor;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FornecedorCrudTest extends TestCase
{
    use RefreshDatabase;

    private function operador(): User
    {
        return User::create([
            'nome' => 'Operador',
            'email' => 'operador-' . uniqid() . '@fornecedor.test',
            'password' => 'password',
        ]);
    }

    public function test_authenticated_user_can_create_a_fornecedor(): void
    {
        $this->actingAs($this->operador());

        $response = $this->post(route('fornecedores.store'), [
            'tipo' => 'PJ',
            'nome' => 'Fornecedor Exemplo',
            'razao_social' => 'Fornecedor Exemplo LTDA',
            'cpf_cnpj' => '12.345.678/0001-99',
            'email' => 'contato@fornecedor.test',
            'telefone' => '(11) 98888-0000',
        ]);

        $fornecedor = Fornecedor::query()->first();
        $response->assertRedirect(route('fornecedores.index'));
        $this->assertNotNull($fornecedor);
        $this->assertSame('12345678000199', $fornecedor->cpf_cnpj);
        $this->assertSame('Fornecedor Exemplo', $fornecedor->nome);
        $this->assertDatabaseHas('fornecedores', ['id' => $fornecedor->id, 'ativo' => true]);
    }

    public function test_fornecedor_can_be_updated_and_deactivated_without_deleting_record(): void
    {
        $fornecedor = Fornecedor::create([
            'tipo' => 'PJ',
            'nome' => 'Fornecedor Antigo',
            'cpf_cnpj' => '12345678000199',
            'ativo' => true,
        ]);

        $this->actingAs($this->operador())->put(route('fornecedores.update', $fornecedor), [
            'tipo' => 'PJ',
            'nome' => 'Fornecedor Atualizado',
            'cpf_cnpj' => '12.345.678/0001-99',
            'ativo' => '1',
        ])->assertRedirect(route('fornecedores.index'));

        $this->assertDatabaseHas('fornecedores', [
            'id' => $fornecedor->id,
            'nome' => 'Fornecedor Atualizado',
            'cpf_cnpj' => '12345678000199',
            'ativo' => true,
        ]);

        $this->actingAs($this->operador())->delete(route('fornecedores.destroy', $fornecedor));
        $this->assertDatabaseHas('fornecedores', ['id' => $fornecedor->id, 'ativo' => false]);
    }

    public function test_duplicate_document_is_rejected(): void
    {
        Fornecedor::create([
            'tipo' => 'PF',
            'nome' => 'Fornecedor Existente',
            'cpf_cnpj' => '12345678909',
        ]);

        $this->actingAs($this->operador())
            ->from(route('fornecedores.create'))
            ->post(route('fornecedores.store'), [
                'tipo' => 'PF',
                'nome' => 'Duplicado',
                'cpf_cnpj' => '12345678909',
            ])
            ->assertSessionHasErrors(['cpf_cnpj']);
    }
}
