<form method="POST" action="{{ $cliente->exists ? route('clientes.update', $cliente) : route('clientes.store') }}">
    @if ($cliente->exists)
        @method('PUT')
    @endif
    @csrf

    <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
        <div>
            <label class="block text-sm font-medium text-gray-700">Tipo de pessoa
                <select name="tipo" id="tipo-pessoa" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="PF" @selected(old('tipo', $cliente->tipo ?: 'PF') === 'PF')>Pessoa física</option>
                    <option value="PJ" @selected(old('tipo', $cliente->tipo) === 'PJ')>Pessoa jurídica</option>
                </select>
                @error('tipo')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">CPF/CNPJ <span class="text-red-500">*</span>
                <input name="cpf_cnpj" value="{{ old('cpf_cnpj', $cliente->cpf_cnpj) }}" required maxlength="18" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="00.000.000/0000-00">
                @error('cpf_cnpj')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Nome completo / Razão social <span class="text-red-500">*</span>
                <input name="nome" value="{{ old('nome', $cliente->nome) }}" required maxlength="255" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Nome completo">
                @error('nome')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div id="campo-nome-fantasia" style="display: none;">
            <label class="block text-sm font-medium text-gray-700">Nome fantasia
                <input name="nome_fantasia" value="{{ old('nome_fantasia', $cliente->nome_fantasia) }}" maxlength="255" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Nome fantasia">
                @error('nome_fantasia')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div id="campo-ie" style="display: none;">
            <label class="block text-sm font-medium text-gray-700">Inscrição estadual
                <input name="ie" value="{{ old('ie', $cliente->ie) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="IE">
                @error('ie')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div id="campo-inscricao-municipal" style="display: none;">
            <label class="block text-sm font-medium text-gray-700">Inscrição municipal
                <input name="inscricao_municipal" value="{{ old('inscricao_municipal', $cliente->inscricao_municipal) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="IM">
                @error('inscricao_municipal')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">E-mail
                <input type="email" name="email" value="{{ old('email', $cliente->email) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="email@exemplo.com">
                @error('email')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Telefone
                <input name="telefone" value="{{ old('telefone', $cliente->telefone) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="(00) 00000-0000">
                @error('telefone')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">WhatsApp
                <input name="celular" value="{{ old('celular', $cliente->celular) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="(00) 00000-0000">
                @error('celular')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">CEP
                <input name="cep" value="{{ old('cep', $cliente->cep) }}" maxlength="9" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="00000-000">
                @error('cep')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Logradouro
                <input name="endereco" value="{{ old('endereco', $cliente->endereco) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Rua, Av., etc.">
                @error('endereco')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Número
                <input name="numero" value="{{ old('numero', $cliente->numero) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="123">
                @error('numero')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Complemento
                <input name="complemento" value="{{ old('complemento', $cliente->complemento) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Apto, Sala, etc.">
                @error('complemento')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Bairro
                <input name="bairro" value="{{ old('bairro', $cliente->bairro) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Bairro">
                @error('bairro')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Cidade
                <input name="cidade" value="{{ old('cidade', $cliente->cidade) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Cidade">
                @error('cidade')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">UF
                <input name="estado" value="{{ old('estado', $cliente->estado) }}" maxlength="2" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="SP">
                @error('estado')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Limite de crédito
                <input type="number" min="0" step="0.01" name="limite_credito" value="{{ old('limite_credito', $cliente->limite_credito ?? 0) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="0.00">
                @error('limite_credito')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>
    </div>

    <div class="mt-5">
        <label class="block text-sm font-medium text-gray-700">Observações
            <textarea name="observacoes" rows="3" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500">{{ old('observacoes', $cliente->observacoes) }}</textarea>
            @error('observacoes')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
        </label>
    </div>

    @if ($cliente->exists)
        <label class="mt-4 flex items-center gap-2">
            <input type="checkbox" name="ativo" value="1" @checked(old('ativo', $cliente->ativo))>
            <span class="text-sm text-gray-700">Ativo</span>
        </label>
    @endif

    <div class="mt-6 flex gap-3">
        <button type="submit" class="rounded-lg bg-emerald-900 px-5 py-2.5 text-white hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2">
            {{ $cliente->exists ? 'Salvar alterações' : 'Cadastrar cliente' }}
        </button>
        <a href="{{ route('clientes.index') }}" class="rounded-lg border border-gray-300 px-5 py-2.5 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2">Cancelar</a>
    </div>
</form>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tipoSelect = document.getElementById('tipo-pessoa');
    const camposPJ = [
        document.getElementById('campo-nome-fantasia'),
        document.getElementById('campo-ie'),
        document.getElementById('campo-inscricao-municipal')
    ];

    function toggleCamposPJ() {
        const isPJ = tipoSelect.value === 'PJ';
        camposPJ.forEach(campo => {
            if (campo) {
                campo.style.display = isPJ ? 'block' : 'none';
            }
        });
    }

    tipoSelect.addEventListener('change', toggleCamposPJ);
    toggleCamposPJ();
});
</script>
@endpush