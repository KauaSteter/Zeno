@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div><p class="text-sm font-semibold uppercase tracking-wider text-emerald-800">Cadastros</p><h1 class="text-3xl font-bold text-gray-900">Clientes</h1></div>
        <a href="{{ route('clientes.create') }}" class="rounded-lg bg-emerald-900 px-5 py-3 font-semibold text-white">Novo cliente</a>
    </div>

    @if (session('success'))<div class="mb-4 rounded-lg bg-emerald-50 p-4 text-emerald-900">{{ session('success') }}</div>@endif

    <form method="GET" action="{{ route('clientes.index') }}" class="mb-5 flex flex-wrap gap-3 rounded-xl border bg-white p-4">
        <input name="busca" value="{{ request('busca') }}" placeholder="Nome, e-mail ou CPF/CNPJ" class="min-w-64 flex-1 rounded-lg border-gray-300">
        <select name="status" class="rounded-lg border-gray-300"><option value="">Todos os status</option><option value="1" @selected(request('status') === '1')>Ativos</option><option value="0" @selected(request('status') === '0')>Inativos</option></select>
        <button class="rounded-lg border px-4 py-2">Filtrar</button>
    </form>

    <div class="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50"><tr><th class="px-5 py-3 text-left text-xs font-semibold uppercase">Cliente</th><th class="px-5 py-3 text-left text-xs font-semibold uppercase">CPF/CNPJ</th><th class="px-5 py-3 text-left text-xs font-semibold uppercase">Contato</th><th class="px-5 py-3 text-left text-xs font-semibold uppercase">Status</th><th class="px-5 py-3 text-right text-xs font-semibold uppercase">Ações</th></tr></thead>
            <tbody class="divide-y divide-gray-100">
                @forelse ($clientes as $cliente)
                    <tr>
                        <td class="px-5 py-4"><div class="font-semibold text-gray-900">{{ $cliente->nome }}</div>@if ($cliente->nome_fantasia)<div class="text-sm text-gray-500">{{ $cliente->nome_fantasia }}</div>@endif</td>
                        <td class="px-5 py-4 text-sm">{{ $cliente->cpf_cnpj }}</td>
                        <td class="px-5 py-4 text-sm"><div>{{ $cliente->email ?: '—' }}</div><div class="text-gray-500">{{ $cliente->telefone ?: '—' }}</div></td>
                        <td class="px-5 py-4"><span class="rounded-full px-3 py-1 text-xs font-semibold {{ $cliente->ativo ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-600' }}">{{ $cliente->ativo ? 'Ativo' : 'Inativo' }}</span></td>
                        <td class="px-5 py-4 text-right"><div class="flex justify-end gap-3"><a class="font-medium text-emerald-800" href="{{ route('clientes.edit', $cliente) }}">Editar</a>@if ($cliente->ativo)<form method="POST" action="{{ route('clientes.destroy', $cliente) }}" onsubmit="return confirm('Desativar este cliente?')">@csrf @method('DELETE')<button class="font-medium text-red-700">Desativar</button></form>@endif</div></td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="px-5 py-12 text-center text-gray-500">Nenhum cliente encontrado.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-5">{{ $clientes->links() }}</div>
</div>
@endsection
