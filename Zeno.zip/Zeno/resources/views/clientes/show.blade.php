@extends('layouts.app')

@section('conteudo')
<div class="p-6 bg-slate-100 rounded-lg shadow-sm mb-4">
    <div class="flex justify-between items-start">
        <div>
            <h1 class="text-2xl font-bold text-emerald-700">{{ $cliente->nome }}</h1>
            <p class="text-gray-600">{{ $cliente->email }}</p>
            <p class="text-gray-500 mt-2">{{ $cliente->cpf }} · {{ $cliente->telefone }}</p>
        </div>
        <div class="flex gap-2">
            <a href="{{ route('clientes.edit', $cliente->id) }}"
               class="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded text-sm">
                Editar
            </a>
            <form action="{{ route('clientes.destroy', $cliente->id) }}" method="POST" class="inline">
                @csrf
                @method('DELETE')
                <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded text-sm"
                        onclick="return confirm('Confirmar exclusão?')">
                    Excluir
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
