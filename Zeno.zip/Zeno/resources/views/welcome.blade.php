<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ZENO ERP — Gestão em Equilíbrio</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #F0FDF4;
            color: #064E3B;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background: #FFFFFF;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(6, 78, 59, 0.08);
            text-align: center;
            max-width: 480px;
            border-top: 5px solid #064E3B;
        }
        h1 { margin: 0 0 10px; font-size: 28px; font-weight: 800; letter-spacing: -0.5px; }
        p { color: #4B5563; font-size: 15px; margin: 0 0 24px; }
        .tag {
            display: inline-block;
            background: #DCFCE7;
            color: #064E3B;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>ZENO ERP</h1>
        <p>Gestão em Equilíbrio — Aplicação Inicial Laravel 11</p>
        <div class="tag">Status: Ativo &amp; Configurado</div>
    </div>
</body>
</html>
