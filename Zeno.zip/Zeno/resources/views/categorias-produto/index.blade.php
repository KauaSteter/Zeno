@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6">
        <a href="{{ route('dashboard') }}" class="text-sm font-medium text-emerald-800 hover:underline">← Voltar ao painel</a>
        <h1 class="mt-3 text-3xl font-bold text-gray-900">Categorias de Produto</h1>
    </div>

    <div class="rounded-xl border bg-white shadow-sm">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <form method="GET" class="flex gap-2">
                    <input type="text" name="busca" value="{{ request('busca') }}"
                        class="rounded-lg border border-gray-300 px-3 py-1.5 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Buscar categorias...">
                    <select name="status" class="rounded-lg border border-gray-300 px-3 py-1.5 text-sm focus:ring-emerald-500 focus:border-emerald-500">
                        <option value="">Todas</option>
                        <option value="1" @selected(request('status') === '1')>Ativas</option>
                        <option value="0" @selected(request('status') === '0')>Inativas</option>
                    </select>
                    <button type="submit" class="rounded-lg bg-emerald-900 px-4 py-1.5 text-white text-sm hover:bg-emerald-800">Buscar</button>
                </form>
                <a href="{{ route('categorias-produto.create') }}"
                    class="rounded-lg bg-emerald-900 px-4 py-1.5 text-white text-sm hover:bg-emerald-800">
                    + Nova Categoria
                </a>
            </div>

            @if(session('success'))
                <div class="mb-4 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">
                    {{ session('success') }}
                </div>
            @endif

            @if(session('error'))
                <div class="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-800">
                    {{ session('error') }}
                </div>
            @endif

            @if($categorias->isEmpty())
                <p class="py-8 text-center text-gray-500">Nenhuma categoria encontrada.</p>
            @else
                <div class="divide-y divide-gray-200">
                    @foreach($categorias as $categoria)
                        <div class="flex items-center justify-between py-4">
                            <div class="flex-1">
                                <h3 class="text-sm font-medium text-gray-900">{{ $categoria->nome }}</h3>
                                @if($categoria->descricao)
                                    <p class="mt-1 text-sm text-gray-500">{{ Str::limit($categoria->descricao, 100) }}</p>
                                @endif
                                <span class="mt-1 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium 
                                    @if($categoria->ativo) bg-emerald-100 text-emerald-800 @else bg-gray-100 text-gray-800 @endif">
                                    {{ $categoria->ativo ? 'Ativa' : 'Inativa' }}
                                </span>
                                <p class="mt-1 text-xs text-gray-400">
                                    {{ $categoria->produtos()->count() }} produtos
                                </p>
                            </div>
                            <div class="flex items-center gap-2">
                                <a href="{{ route('categorias-produto.edit', $categoria) }}"
                                    class="rounded-lg bg-gray-100 px-3 py-1.5 text-gray-700 hover:bg-gray-200 text-sm">
                                    Editar
                                </a>
                                @if($categoria->produtos()->exists())
                                    <button disabled
                                        class="rounded-lg bg-gray-100 px-3 py-1.5 text-gray-400 text-sm cursor-not-allowed">
                                        Excluir
                                    </button>
                                @else
                                    <form action="{{ route('categorias-produto.destroy', $categoria) }}" method="POST" 
                                        onsubmit="return confirm('Desativar esta categoria?')">
                                        @csrf @method('DELETE')
                                        <button type="submit"
                                            class="rounded-lg bg-red-100 px-3 py-1.5 text-red-700 hover:bg-red-200 text-sm">
                                            Excluir
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>

                <div class="mt-4">
                    {{ $categorias->links() }}
                </div>
            @endif
        </div>
    </div>
</div>
@endsection