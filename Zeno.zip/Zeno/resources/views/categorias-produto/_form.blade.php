<form method="POST" action="{{ $categoria->exists ? route('categorias-produto.update', $categoria) : route('categorias-produto.store') }}">
    @if ($categoria->exists) @method('PUT') @endif
    @csrf

    <div class="space-y-5">
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nome da Categoria <span class="text-red-500">*</span>
                <input name="nome" value="{{ old('nome', $categoria->nome) }}" required maxlength="100"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-emerald-500 focus:border-emerald-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                @error('nome')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Descrição
                <textarea name="descricao" rows="3"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-emerald-500 focus:border-emerald-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">{{ old('descricao', $categoria->descricao) }}</textarea>
                @error('descricao')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        @if ($categoria->exists)
            <div class="flex items-center gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                <input type="checkbox" name="ativo" value="1" @checked(old('ativo', $categoria->ativo))
                    class="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500">
                <label class="text-sm text-gray-700 dark:text-gray-300">
                    Categoria ativa
                </label>
            </div>
        @endif

        <div class="flex justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
            <a href="{{ route('categorias-produto.index') }}"
                class="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 transition">
                Cancelar
            </a>
            <button type="submit"
                class="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-900 px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition">
                {{ $categoria->exists ? 'Salvar Alterações' : 'Cadastrar Categoria' }}
            </button>
        </div>
    </div>
</form>