@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-2xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6">
        <a href="{{ route('categorias-produto.index') }}" class="text-sm font-medium text-emerald-800 hover:underline">← Voltar para categorias</a>
        <h1 class="mt-3 text-3xl font-bold text-gray-900">Editar Categoria</h1>
    </div>

    <div class="rounded-xl border bg-white shadow-sm">
        <div class="p-6">
            @include('categorias-produto._form')
        </div>
    </div>
</div>
@endsection