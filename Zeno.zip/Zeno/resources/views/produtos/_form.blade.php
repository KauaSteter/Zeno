<form method="POST" action="{{ $produto->exists ? route('produtos.update', $produto) : route('produtos.store') }}" enctype="multipart/form-data">
    @if ($produto->exists)
        @method('PUT')
    @endif
    @csrf

    <div class="space-y-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-900 dark:text-white">
                {{ $produto->exists ? 'Editar' : 'Novo' }} Produto
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Preencha os dados do produto abaixo
            </p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <span class="flex items-center gap-2">
                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4v16h16V4H4z"/></svg>
                    Imagem do Produto
                </span>
            </label>
            <div class="mt-1">
                @if ($produto->imagem_url && str_contains($produto->imagem_url, 'storage'))
                    <img src="{{ $produto->imagem_url }}" alt="{{ $produto->nome }}" class="h-32 w-32 rounded-xl object-cover bg-gray-100 dark:bg-gray-700">
                @else
                    <div class="flex h-32 w-32 items-center justify-center rounded-xl bg-zeno-forest/10 text-zeno-forest/70">
                        <svg class="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6m14 4l-2 2-2-4H6"/></svg>
                    </div>
                @endif
            </div>
            <div class="mt-2">
                <label class="block w-full">
                    <span class="sr-only">Selecionar imagem</span>
                    <input type="file" name="imagem" accept="image/*" class="hidden">
                    <button type="button" onclick="document.querySelector('input[name=\"imagem\"]').click()" class="inline-flex items-center justify-center w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 transition cursor-pointer">
                        <svg class="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 5v14m-7 0h14"/></svg>
                        {{ $produto->imagem ? 'Alterar imagem' : 'Selecionar imagem' }}
                    </button>
                </label>
            </div>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Formatos: JPG, PNG, GIF, WEBP. Máximo 5MB.
            </p>
            @error('imagem')
                <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
            @enderror
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    SKU (Código Único) *
                </label>
                <input name="sku" value="{{ old('sku', $produto->sku) }}" required maxlength="100"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                @error('sku')
                    <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Nome do Produto *
                </label>
                <input name="nome" value="{{ old('nome', $produto->nome) }}" required maxlength="255"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                @error('nome')
                    <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Unidade *
                </label>
                <input name="unidade" value="{{ old('unidade', $produto->unidade ?? 'un') }}" required maxlength="20"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                @error('unidade')
                    <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <div class="flex items-center justify-between mb-1">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Categoria
                    </label>
                    <a href="{{ route('categorias-produto.create') }}" target="_blank" class="text-xs font-medium text-zeno-forest hover:underline">
                        + Nova Categoria
                    </a>
                </div>
                <select name="categoria_id" class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-emerald-500 focus:border-emerald-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <option value="">Selecionar categoria</option>
                    @foreach(\App\Models\CategoriaProduto::where('ativo', true)->orderBy('nome')->get() as $cat)
                        <option value="{{ $cat->id }}" @selected(old('categoria_id', $produto->categoria_id) == $cat->id)>{{ $cat->nome }}</option>
                    @endforeach
                </select>
                @error('categoria_id')
                    <span class="text-sm text-red-600">{{ $message }}</span>
                @enderror
            </div>
        </div>

        <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <svg class="h-5 w-5 text-zeno-forest" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8c-1.1 0-2 .9-2 2s.9 2 2 2 2 .9 2 2-.9 2-2 2V12c0-.6.4-1 1-1s1 .4 1 1V15c0 .6-.4 1-1 1s-1-.4-1-1V13c0-.6.4-1 1-1s1 .4 1 1v2c0 1.1-.9 2-2 2z"/></svg>
                Preços
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Preço de Custo (R$) *
                    </label>
                    <div class="relative">
                        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">R$</span>
                        <input type="number" step="0.01" min="0" name="preco_custo" value="{{ old('preco_custo', $produto->preco_custo ?? 0) }}" required
                            class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 pl-8 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    </div>
                    @error('preco_custo')
                        <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Preço de Venda (R$) *
                    </label>
                    <div class="relative">
                        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">R$</span>
                        <input type="number" step="0.01" min="0" name="preco_venda" value="{{ old('preco_venda', $produto->preco_venda ?? 0) }}" required
                            class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 pl-8 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    </div>
                    @error('preco_venda')
                        <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                    @enderror
                </div>
            </div>
        </div>

        <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <svg class="h-5 w-5 text-zeno-forest" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6M9 8h6M5 20h14a2 2 0 002-2V6a2 2 0 00-2 2v12a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                Estoque
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Estoque Atual *
                    </label>
                    <input type="number" step="1" min="0" name="estoque_atual" value="{{ old('estoque_atual', $produto->estoque_atual ?? 0) }}" required
                        class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    @error('estoque_atual')
                        <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Estoque Mínimo *
                    </label>
                    <input type="number" step="1" min="0" name="estoque_minimo" value="{{ old('estoque_minimo', $produto->estoque_minimo ?? 0) }}" required
                        class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    @error('estoque_minimo')
                        <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
                    @enderror
                </div>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Descrição Detalhada
            </label>
            <textarea name="descricao" rows="3" class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-zeno-forest focus:border-zeno-forest dark:bg-gray-700 dark:border-gray-600 dark:text-white">{{ old('descricao', $produto->descricao ?? '') }}</textarea>
            @error('descricao')
                <span class="block text-sm text-red-600 mt-1">{{ $message }}</span>
            @enderror
        </div>

        @if ($produto->exists)
            <div class="flex items-center gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                <input type="checkbox" name="ativo" value="1" @checked(old('ativo', $produto->ativo))
                    class="h-4 w-4 rounded border-gray-300 text-zeno-forest focus:ring-zeno-forest">
                <label class="text-sm text-gray-700 dark:text-gray-300">
                    Produto ativo
                </label>
            </div>
        @endif
    </div>

    <div class="mt-8 flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
        <a href="{{ route('produtos.index') }}" class="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 transition">
            Cancelar
        </a>
        <button type="submit" class="inline-flex items-center justify-center gap-2 rounded-lg bg-zeno-forest px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-[#075F44] focus:outline-none focus:ring-2 focus:ring-zeno-forest focus:ring-offset-2 transition">
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="{{ $produto->exists ? 'M11 5H6a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2v-5m-5 5v-5m0 5a4 4 0 10-4-4 4 4 0 004 4z' : 'M12 4v16m8-8H4' }}"/></svg>
            {{ $produto->exists ? 'Salvar Alterações' : 'Cadastrar Produto' }}
        </button>
    </div>
</form>