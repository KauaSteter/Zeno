@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <p class="text-xs font-semibold uppercase tracking-wider text-zeno-forest">Catálogo</p>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Produtos</h1>
        </div>
        <div class="flex flex-wrap gap-3">
            <a href="{{ route('categorias-produto.index') }}" class="inline-flex items-center gap-2 rounded-xl border border-zeno-forest/30 bg-white dark:bg-gray-800 px-5 py-3 text-sm font-semibold text-zeno-forest hover:bg-zeno-forest/5 transition dark:border-zeno-forest/40">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
                Categorias
            </a>
            <a href="{{ route('estoque.baixo') }}" class="inline-flex items-center gap-2 rounded-xl border border-zeno-copper/30 bg-white dark:bg-gray-800 px-5 py-3 text-sm font-semibold text-zeno-copper hover:bg-zeno-copper/5 transition dark:border-zeno-copper/40">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6m14 4l-2 2-2-4H6"/></svg>
                Estoque Baixo
            </a>
            <a href="{{ route('produtos.create') }}" class="inline-flex items-center gap-2 rounded-xl bg-zeno-forest px-5 py-3 text-sm font-semibold text-white shadow-sm shadow-zeno-forest/20 hover:bg-[#075F44] focus:outline-none focus:ring-2 focus:ring-zeno-forest focus:ring-offset-2 transition">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Novo Produto
            </a>
            <a href="{{ route('clientes.index') }}" class="inline-flex items-center gap-2 rounded-xl border border-zeno-copper/30 bg-white dark:bg-gray-800 px-5 py-3 text-sm font-semibold text-zeno-copper hover:bg-zeno-copper/5 transition dark:border-zeno-copper/40">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke-width="1.5"/></svg>
                Clientes
            </a>
        </div>
    </div>

    @if (session('success'))
        <div class="mb-4 rounded-lg bg-emerald-50 p-4 text-emerald-900 border border-emerald-200">{{ session('success') }}</div>
    @endif

    <form method="GET" action="{{ route('produtos.index') }}" class="mb-5 flex flex-col gap-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-4 shadow-sm sm:flex-row sm:items-center">
        <div class="relative flex-1">
            <input name="busca" value="{{ request('busca') }}" placeholder="Buscar produto..." class="w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 pl-10 text-sm shadow-sm focus:border-zeno-forest focus:ring-zeno-forest/20 dark:bg-gray-700 dark:border-gray-600">
            <svg class="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 1116.65 16.65z"/></svg>
        </div>
        <div class="flex flex-wrap gap-3">
            <select name="categoria_id" class="rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm shadow-sm focus:border-zeno-forest focus:ring-zeno-forest/20 dark:bg-gray-700 dark:border-gray-600">
                <option value="">Todas as categorias</option>
                @foreach ($categorias as $cat)
                    <option value="{{ $cat->id }}" @selected(request('categoria_id') == $cat->id)>{{ $cat->nome }}</option>
                @endforeach
            </select>
            <select name="status" class="rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm shadow-sm focus:border-zeno-forest focus:ring-zeno-forest/20 dark:bg-gray-700 dark:border-gray-600">
                <option value="">Todos os status</option>
                <option value="1" @selected(request('status') === '1')>Ativos</option>
                <option value="0" @selected(request('status') === '0')>Inativos</option>
            </select>
            <button type="submit" class="rounded-lg bg-zeno-forest px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-[#075F44] transition">Filtrar</button>
            @if(request('busca') || request('status') || request('categoria_id'))
                <a href="{{ route('produtos.index') }}" class="rounded-lg border border-zeno-copper/30 bg-white px-4 py-2.5 text-sm font-semibold text-zeno-copper hover:bg-zeno-copper/5 transition dark:bg-gray-800 dark:border-zeno-copper/40">Limpar</a>
            @endif
        </div>
    </form>

    <div class="overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                    <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-300">Imagem</th>
                    <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-300">Produto / SKU</th>
                    <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-300">Preços (Custo / Venda)</th>
                    <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-300">Estoque</th>
                    <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-300">Status</th>
                    <th class="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-300">Ações</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                @forelse ($produtos as $produto)
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <td class="px-5 py-4">
                            <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-zeno-forest/10 text-zeno-forest">
                                <img src="{{ $produto->imagem_url }}" alt="{{ $produto->nome }}" class="h-8 w-8 rounded-md object-cover">
                            </div>
                        </td>
                        <td class="px-5 py-4">
                            <div class="font-semibold text-gray-900 dark:text-white">{{ $produto->nome }}</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">SKU: {{ $produto->sku }} @if($produto->categoria) | <span class="text-zeno-forest font-medium">{{ $produto->categoria->nome }}</span> @endif</div>
                        </td>
                        <td class="px-5 py-4 text-sm">
                            <div class="text-gray-600 dark:text-gray-300">Custo: R$ {{ number_format($produto->preco_custo, 2, ',', '.') }}</div>
                            <div class="font-medium text-emerald-800 dark:text-emerald-500">Venda: R$ {{ number_format($produto->preco_venda, 2, ',', '.') }}</div>
                        </td>
                        <td class="px-5 py-4 text-sm">
                            <div class="{{ $produto->estoque_atual <= $produto->estoque_minimo ? 'font-bold text-amber-700' : 'font-bold text-gray-900 dark:text-white' }}">
                                {{ $produto->estoque_atual }} {{ $produto->unidade }}
                            </div>
                            <div class="text-xs text-gray-500 dark:text-gray-400">Mín: {{ $produto->estoque_minimo }}</div>
                        </td>
                        <td class="px-5 py-4">
                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold {{ $produto->ativo ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-400' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300' }}">
                                {{ $produto->ativo ? 'Ativo' : 'Inativo' }}
                            </span>
                        </td>
                        <td class="px-5 py-4 text-right">
                            <div class="flex justify-end gap-2">
                                <a class="inline-flex items-center gap-1 rounded-lg bg-zeno-forest/5 px-3 py-1.5 text-sm font-medium text-zeno-forest hover:bg-zeno-forest/10 transition" href="{{ route('produtos.edit', $produto) }}">
                                    <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 5H6a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2v-5m-5 5v-5m0 5a4 4 0 10-4-4 4 4 0 004 4z"/></svg>
                                    Editar
                                </a>
                                @if ($produto->ativo)
                                    <form method="POST" action="{{ route('produtos.destroy', $produto) }}" onsubmit="return confirm('Desativar este produto?')">
                                        @csrf @method('DELETE')
                                        <button type="submit" class="inline-flex items-center gap-1 rounded-lg bg-red-50/5 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50/10 transition">
                                            <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"/></svg>
                                            Desativar
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-5 py-12 text-center text-gray-500 dark:text-gray-400">
                            <div class="flex flex-col items-center gap-2">
                                <svg class="h-10 w-10 text-gray-300" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-dasharray="3 4" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 7h18M3 12h18M3 17h18"/></svg>
                                <p class="text-sm font-medium">Nenhum produto encontrado.</p>
                            </div>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-5">{{ $produtos->links() }}</div>
</div>
@endsection
