@extends('layouts.app')

@section('content')
<div class="p-6 bg-slate-100 rounded-lg shadow-sm">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-bold text-emerald-700">Ordens de Serviço</h1>
        <a href="{{ route('ordens-servico.create') }}" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded">
            + Nova OS
        </a>
    </div>
    <table class="w-full text-sm">
        <thead class="bg-slate-200 text-slate-700">
            <tr>
                <th class="px-3 py-2 text-left">Número</th>
                <th class="px-3 py-2 text-left">Cliente</th>
                <th class="px-3 py-2 text-left">Veículo</th>
                <th class="px-3 py-2 text-left">Status</th>
                <th class="px-3 py-2 text-right">Mão de Obra</th>
                <th class="px-3 py-2 text-right">Total</th>
            </tr>
        </thead>
        <tbody>
            @forelse($ordens as $os)
            <tr class="border-b">
                <td class="px-3 py-2 font-mono">
                    <a href="{{ route('ordens-servico.show', $os) }}" class="text-emerald-700 font-semibold hover:underline">
                        {{ $os->numero_os }}
                    </a>
                </td>
                <td class="px-3 py-2">{{ $os->cliente?->nome ?? 'Sem cliente' }}</td>
                <td class="px-3 py-2">{{ trim(($os->veiculo_marca ?? '') . ' ' . ($os->veiculo_modelo ?? '')) ?: '—' }}</td>
                <td class="px-3 py-2">
                    <span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">{{ $os->status }}</span>
                </td>
                <td class="px-3 py-2 text-right">R$ {{ number_format((float) ($os->mão_obra ?? 0), 2, ',', '.') }}</td>
                <td class="px-3 py-2 text-right font-semibold">R$ {{ number_format((float) ($os->total_final ?? 0), 2, ',', '.') }}</td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-3 py-6 text-center text-gray-500">Nenhuma OS cadastrada</td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="mt-4">
        {{ $ordens->links() }}
    </div>
</div>
@endsection
