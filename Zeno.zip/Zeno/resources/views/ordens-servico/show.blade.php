@extends('layouts.app')

@section('content')
<div class="p-6 bg-slate-100 rounded-lg shadow-sm max-w-4xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <div>
            <span class="text-xs uppercase tracking-wider text-slate-500 font-semibold">Ordem de Serviço</span>
            <h1 class="text-2xl font-bold text-emerald-700">{{ $os->numero_os }}</h1>
            <p class="text-sm text-slate-600 font-medium">{{ $os->titulo ?? 'Atendimento Geral' }}</p>
        </div>
        <div class="text-right">
            <span class="inline-block px-3 py-1 rounded text-sm font-semibold 
                {{ $os->status === 'concluida' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800' }}">
                {{ ucfirst(str_replace('_', ' ', $os->status)) }}
            </span>
            <p class="text-xs text-slate-500 mt-1">Abertura: {{ ($os->data_abertura ?? $os->data_entrada)?->format('d/m/Y H:i') ?? '—' }}</p>
        </div>
    </div>

    {{-- Dados de Cliente & Responsáveis --}}
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div class="bg-white p-4 rounded-lg border border-slate-200">
            <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-2">👤 Cliente</h2>
            <p class="font-medium text-slate-900">{{ $os->cliente?->nome ?? '—' }}</p>
            @if($os->cliente?->cpf_cnpj)
                <p class="text-xs text-slate-500">{{ $os->cliente->tipo === 'pj' ? 'CNPJ' : 'CPF' }}: {{ $os->cliente->cpf_cnpj }}</p>
            @endif
            @if($os->cliente?->telefone)
                <p class="text-xs text-slate-500">Tel: {{ $os->cliente->telefone }}</p>
            @endif
        </div>

        <div class="bg-white p-4 rounded-lg border border-slate-200">
            <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-2">👨‍🔧 Atendimento & Fiscal</h2>
            <p class="text-sm"><strong>Técnico / Executor:</strong> {{ $os->tecnico?->nome ?? $os->usuario?->nome ?? '—' }}</p>
            <p class="text-sm"><strong>Criado por:</strong> {{ $os->usuario?->nome ?? 'Sistema' }}</p>
            <div class="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span>NFS-e: <strong>{{ $os->nfse_emitida ? 'Emitida (Nº ' . ($os->nfse_numero ?? 'S/N') . ')' : 'Não emitida' }}</strong></span>
                @if($os->nfse_codigo_verificacao)
                    <span class="text-slate-500">Cód: {{ $os->nfse_codigo_verificacao }}</span>
                @endif
            </div>
        </div>
    </div>

    {{-- Informações de Transporte / Veículo (quando aplicável) --}}
    @if($os->veiculo_marca || $os->veiculo_modelo || $os->veiculo_placa)
    <div class="bg-white p-4 rounded-lg border border-slate-200 mb-4">
        <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-2">🚗 Veículo / Transporte do Atendimento</h2>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            <div><span class="text-slate-500 text-xs block">Marca</span><strong>{{ $os->veiculo_marca ?? '—' }}</strong></div>
            <div><span class="text-slate-500 text-xs block">Modelo</span><strong>{{ $os->veiculo_modelo ?? '—' }}</strong></div>
            <div><span class="text-slate-500 text-xs block">Placa</span><strong>{{ $os->veiculo_placa ?? '—' }}</strong></div>
            <div><span class="text-slate-500 text-xs block">Ano / KM</span><strong>{{ $os->veiculo_ano ?? '—' }} / {{ $os->quilometragem_entrada ? number_format($os->quilometragem_entrada, 0, ',', '.') . ' km' : '—' }}</strong></div>
        </div>
    </div>
    @endif

    {{-- Problema / Sintoma / Laudo --}}
    @if($os->descricao_problema || $os->sintoma || $os->descricao_solucao || $os->observacoes)
    <div class="bg-white p-4 rounded-lg border border-slate-200 mb-4">
        <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-2">📋 Detalhes do Serviço</h2>
        <div class="space-y-2 text-sm text-slate-700">
            @if($os->descricao_problema || $os->sintoma)
                <div>
                    <strong class="text-slate-800">Problema Relatado / Sintoma:</strong>
                    <p class="text-slate-600 bg-slate-50 p-2 rounded mt-1">{{ $os->descricao_problema ?? $os->sintoma }}</p>
                </div>
            @endif
            @if($os->descricao_solucao || $os->solucao)
                <div>
                    <strong class="text-slate-800">Laudo Técnico / Solução:</strong>
                    <p class="text-slate-600 bg-slate-50 p-2 rounded mt-1">{{ $os->descricao_solucao ?? $os->solucao }}</p>
                </div>
            @endif
            @if($os->observacoes)
                <div>
                    <strong class="text-slate-800">Observações:</strong>
                    <p class="text-slate-600 bg-slate-50 p-2 rounded mt-1">{{ $os->observacoes }}</p>
                </div>
            @endif
        </div>
    </div>
    @endif

    {{-- Itens de Serviços e Peças --}}
    <div class="bg-white p-4 rounded-lg border border-slate-200 mb-4">
        <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-3">🔧 Serviços e Peças Utilizadas</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-slate-200 text-slate-500 text-xs uppercase">
                        <th class="py-2 text-left">Tipo</th>
                        <th class="py-2 text-left">Descrição</th>
                        <th class="py-2 text-right">Qtd</th>
                        <th class="py-2 text-right">Unitário</th>
                        <th class="py-2 text-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($os->itens as $item)
                    <tr>
                        <td class="py-2">
                            <span class="inline-block px-2 py-0.5 rounded text-xs font-semibold {{ $item->tipo === 'peca' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-blue-50 text-blue-700 border border-blue-200' }}">
                                {{ $item->tipo === 'peca' ? 'Peça / Material' : 'Serviço' }}
                            </span>
                        </td>
                        <td class="py-2 font-medium text-slate-800">{{ $item->nome }}</td>
                        <td class="py-2 text-right">{{ number_format($item->quantidade, 2, ',', '.') }}</td>
                        <td class="py-2 text-right">R$ {{ number_format($item->valor_unitario, 2, ',', '.') }}</td>
                        <td class="py-2 text-right font-semibold text-slate-900">R$ {{ number_format($item->total, 2, ',', '.') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="py-4 text-center text-slate-400">Nenhum item lançado nesta OS.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Totais Financeiros --}}
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div class="bg-white p-4 rounded-lg border border-slate-200">
            <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-2">💰 Composição dos Valores</h2>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between py-1 border-b border-slate-100">
                    <span class="text-slate-600">Serviços / Mão de Obra:</span>
                    <strong>R$ {{ number_format($os->total_servicos > 0 ? $os->total_servicos : $os->mão_obra, 2, ',', '.') }}</strong>
                </div>
                <div class="flex justify-between py-1 border-b border-slate-100">
                    <span class="text-slate-600">Peças e Produtos:</span>
                    <strong>R$ {{ number_format($os->total_pecas > 0 ? $os->total_pecas : $os->total_produtos, 2, ',', '.') }}</strong>
                </div>
                <div class="flex justify-between py-1 border-b border-slate-100 text-red-600">
                    <span>Desconto:</span>
                    <span>- R$ {{ number_format($os->total_desconto > 0 ? $os->total_desconto : $os->desconto, 2, ',', '.') }}</span>
                </div>
                <div class="flex justify-between py-2 text-base font-bold text-slate-900 pt-2">
                    <span>Valor Total Geral:</span>
                    <span class="text-emerald-700 text-lg">R$ {{ number_format($os->total_final, 2, ',', '.') }}</span>
                </div>
            </div>
        </div>

        <div class="bg-white p-4 rounded-lg border border-slate-200 flex flex-col justify-between">
            <div>
                <h2 class="text-sm font-semibold uppercase tracking-wider text-slate-700 mb-2">⏱️ Prazos e Previsões</h2>
                <div class="space-y-1 text-sm text-slate-600">
                    <p>Previsão de Entrega: <strong>{{ $os->data_previsao?->format('d/m/Y') ?? 'Não definida' }}</strong></p>
                    <p>Data de Conclusão: <strong>{{ $os->data_conclusao?->format('d/m/Y H:i') ?? 'Em andamento' }}</strong></p>
                </div>
            </div>

            @if($os->status === 'aberta')
            <form action="{{ route('ordens-servico.finalizar', $os) }}" method="POST" class="mt-4">
                @csrf
                <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-4 py-2 rounded transition">
                    ✅ Finalizar Ordem de Serviço
                </button>
            </form>
            @endif
        </div>
    </div>

    <div>
        <a href="{{ route('ordens-servico.index') }}" class="inline-flex items-center text-slate-600 hover:text-slate-900 text-sm font-medium">
            ← Voltar para listagem de OS
        </a>
    </div>
</div>
@endsection
