@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6"><a href="{{ route('fornecedores.index') }}" class="text-sm font-medium text-emerald-800">← Voltar para fornecedores</a><h1 class="mt-3 text-3xl font-bold text-gray-900">Editar fornecedor</h1></div>
    <div class="rounded-xl border bg-white p-6 shadow-sm">@include('fornecedores._form')</div>
</div>
@endsection
