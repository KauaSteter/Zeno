<form method="POST" action="{{ $fornecedor->exists ? route('fornecedores.update', $fornecedor) : route('fornecedores.store') }}">
    @if ($fornecedor->exists) @method('PUT') @endif
    @csrf

    <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
        <div>
            <label class="block text-sm font-medium text-gray-700">CNPJ <span class="text-red-500">*</span>
                <input name="cpf_cnpj" value="{{ old('cpf_cnpj', $fornecedor->cpf_cnpj) }}" required maxlength="18" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="00.000.000/0000-00">
                @error('cpf_cnpj')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Nome fantasia <span class="text-red-500">*</span>
                <input name="nome" value="{{ old('nome', $fornecedor->nome) }}" required maxlength="255" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Nome da empresa">
                @error('nome')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Razão social
                <input name="razao_social" value="{{ old('razao_social', $fornecedor->razao_social) }}" maxlength="255" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500">
                @error('razao_social')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Inscrição estadual
                <input name="inscricao_estadual" value="{{ old('inscricao_estadual', $fornecedor->inscricao_estadual) }}" maxlength="20" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="IE">
                @error('inscricao_estadual')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">E-mail
                <input type="email" name="email" value="{{ old('email', $fornecedor->email) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="email@exemplo.com">
                @error('email')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Telefone
                <input name="telefone" value="{{ old('telefone', $fornecedor->telefone) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="(00) 00000-0000">
                @error('telefone')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">CEP
                <input name="cep" value="{{ old('cep', $fornecedor->cep) }}" maxlength="9" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="00000-000">
                @error('cep')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Endereço
                <input name="endereco" value="{{ old('endereco', $fornecedor->endereco) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Rua, Av., etc.">
                @error('endereco')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Número
                <input name="numero" value="{{ old('numero', $fornecedor->numero) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="123">
                @error('numero')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Bairro
                <input name="bairro" value="{{ old('bairro', $fornecedor->bairro) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Bairro">
                @error('bairro')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Cidade
                <input name="cidade" value="{{ old('cidade', $fornecedor->cidade) }}" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="Cidade">
                @error('cidade')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">UF
                <input name="estado" value="{{ old('estado', $fornecedor->estado) }}" maxlength="2" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500" placeholder="SP">
                @error('estado')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
            </label>
        </div>
    </div>

    <div class="mt-5">
        <label class="block text-sm font-medium text-gray-700">Observações
            <textarea name="observacoes" rows="3" class="mt-1 w-full rounded-lg border-gray-300 focus:ring-emerald-500 focus:border-emerald-500">{{ old('observacoes', $fornecedor->observacoes) }}</textarea>
            @error('observacoes')<span class="text-sm text-red-600">{{ $message }}</span>@enderror
        </label>
    </div>

    @if ($fornecedor->exists)
        <label class="mt-4 flex items-center gap-2">
            <input type="checkbox" name="ativo" value="1" @checked(old('ativo', $fornecedor->ativo))>
            <span class="text-sm text-gray-700">Ativo</span>
        </label>
    @endif

    <div class="mt-6 flex gap-3">
        <button type="submit" class="rounded-lg bg-emerald-900 px-5 py-2.5 text-white hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2">
            {{ $fornecedor->exists ? 'Salvar alterações' : 'Cadastrar fornecedor' }}
        </button>
        <a href="{{ route('fornecedores.index') }}" class="rounded-lg border border-gray-300 px-5 py-2.5 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2">Cancelar</a>
    </div>
</form>