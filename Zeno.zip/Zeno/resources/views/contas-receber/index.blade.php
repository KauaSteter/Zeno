@extends('layouts.app')

@section('content')
<div class="p-6 bg-slate-100 rounded-lg shadow-sm">
    <h1 class="text-2xl font-bold text-emerald-700 mb-4">Contas a Receber</h1>

    <table class="w-full text-sm">
        <thead class="bg-slate-200 text-slate-700">
            <tr>
                <th class="px-3 py-2 text-left">Origem</th>
                <th class="px-3 py-2 text-left">Cliente</th>
                <th class="px-3 py-2 text-left">Valor</th>
                <th class="px-3 py-2 text-left">Vencimento</th>
                <th class="px-3 py-2 text-left">Status</th>
                <th class="px-3 py-2 text-left">Ação</th>
            </tr>
        </thead>
        <tbody>
            @forelse($contas as $conta)
            <tr class="border-b">
                <td class="px-3 py-2">{{ $conta->origem }}</td>
                <td class="px-3 py-2">{{ $conta->cliente?->nome ?? '—' }}</td>
                <td class="px-3 py-2 text-right">R$ {{ number_format($conta->valor, 2, ',', '.') }}</td>
                <td class="px-3 py-2">{{ $conta->data_vencimento?->format('d/m/Y') }}</td>
                <td class="px-3 py-2">
                    <span class="px-2 py-0.5 rounded-full text-xs font-semibold
                        {{ $conta->status === 'recebido' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800' }}">
                        {{ $conta->status }}
                    </span>
                </td>
                <td class="px-3 py-2">
                    @if($conta->status === 'pendente')
                    <form action="{{ route('contas-receber.registrar-pagamento', $conta) }}" method="POST" class="inline">
                        @csrf
                        <select name="forma_pagamento" class="px-2 py-1 border border-gray-300 rounded text-sm mr-2">
                            <option value="dinheiro">Dinheiro</option>
                            <option value="pix">PIX</option>
                            <option value="cartao">Cartão</option>
                        </select>
                        <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-2 py-1 rounded text-sm">Receber</button>
                    </form>
                    @else
                    <span class="text-green-600 text-xs">Recebido</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-3 py-6 text-center text-gray-500">Nenhuma conta a receber</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
