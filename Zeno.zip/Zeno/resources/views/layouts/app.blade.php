<!DOCTYPE html>
<html lang="pt-BR" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'ZENO ERP') }} - {{ $title ?? 'Gestão em Equilíbrio' }}</title>
    <script>
        // Anti-FOUC: aplica tema escuro antes da primeira pintura
        (function() {
            try {
                var theme = localStorage.getItem('zeno_theme');
                if (theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                    document.documentElement.classList.add('dark');
                } else {
                    document.documentElement.classList.remove('dark');
                }
            } catch (e) {}
        })();
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        zeno: {
                            forest: '#064E3B',
                            copper: '#C68346',
                            gold: '#C9962E',
                            'dark-bg': '#0a1512',
                            'dark-card': '#13211c',
                        }
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        .scrollbar-none::-webkit-scrollbar { display: none; }
        .scrollbar-none { -ms-overflow-style: none; scrollbar-width: none; }

        html.dark { color-scheme: dark; }
        html.dark body { background-color: #0a1512 !important; color: #f1f5f9 !important; }
        html.dark .bg-white { background-color: #13211c !important; color: #f8fafc !important; }
        html.dark .bg-gray-50 { background-color: #0a1512 !important; }
        html.dark .bg-gray-100 { background-color: #1a2c26 !important; color: #f8fafc !important; }
        html.dark .text-gray-900, html.dark .text-slate-800, html.dark .text-slate-900 { color: #f8fafc !important; }
        html.dark .text-gray-700, html.dark .text-gray-600 { color: #cbd5e1 !important; }
        html.dark .text-gray-500, html.dark .text-gray-400 { color: #94a3b8 !important; }
        html.dark .border, html.dark .border-gray-200, html.dark .border-gray-300, html.dark .border-gray-100 { border-color: #1d332b !important; }
        html.dark .divide-gray-200 > :not([hidden]) ~ :not([hidden]) { border-color: #1d332b !important; }
        html.dark input:not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]),
        html.dark select, html.dark textarea { background-color: #13211c !important; border-color: #264338 !important; color: #f8fafc !important; }
        html.dark input::placeholder, html.dark textarea::placeholder { color: #64748b !important; }
    </style>
</head>
<body class="min-h-screen bg-gray-50 text-slate-800 transition-colors duration-300 dark:bg-zeno-dark-bg">
    @php
        $isAuthenticated = auth()->check();
        $isDashboard = request()->routeIs('dashboard');
        $isClientes = request()->routeIs('clientes.*');
        $isProdutos = request()->routeIs('produtos.*');
        $isFornecedores = request()->routeIs('fornecedores.*');
        $isCompras = request()->routeIs('compras.*');
        $isVendas = request()->routeIs('vendas.*');
        $isOS = request()->routeIs('ordens-servico.*');
        $isContasReceber = request()->routeIs('contas-receber.*');
        $isContasPagar = request()->routeIs('contas-pagar.*');
        $isCrm = request()->routeIs('crm.*') || request()->routeIs('admin.usuarios.*');
        $isAgenda = request()->routeIs('agenda.*');
        $user = auth()->user();
        $isAdmin = $user && $user->hasRole('admin');
        $isGerente = $user && $user->hasRole('gerente');
        $isVendedor = $user && $user->hasRole('vendedor');
        $isFinanceiro = $user && $user->hasRole('financeiro');
        $isTecnico = $user && $user->hasRole('tecnico');
    @endphp
    @if($isAuthenticated)
        <header class="sticky top-0 z-40 border-b border-emerald-950/10 bg-[#064E3B] text-white shadow-lg shadow-emerald-950/10">
            <div class="mx-auto flex min-h-[76px] max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
                <a href="{{ route('dashboard') }}" class="flex shrink-0 items-center gap-3" aria-label="ZENO ERP — início">
                    <span class="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-lg font-extrabold text-[#E2B15E] shadow-inner">Z</span>
                    <span class="leading-tight"><span class="block text-base font-extrabold tracking-[.12em]">ZENO</span><span class="block text-[10px] font-medium tracking-[.22em] text-emerald-100/75">GESTÃO EM EQUILÍBRIO</span></span>
                </a>
                                <!-- Menu de Navegação Horizontal com Limite de 3-5 itens e Navegação Lateral -->
                                <div class="relative flex items-center max-w-[340px] sm:max-w-[440px] md:max-w-[540px] lg:max-w-[590px]">
                                    <button type="button" onclick="scrollNav(-1)" class="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-white/90 hover:bg-white/20 transition active:scale-95 mr-1" aria-label="Menu anterior" title="Menu anterior">
                                        <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" /></svg>
                                    </button>

                                    <nav id="main-nav-container" aria-label="Navegação principal" class="flex items-center gap-1.5 overflow-x-auto scroll-smooth rounded-2xl border border-white/10 bg-[#022C22]/40 p-1.5 scrollbar-none" style="scrollbar-width: none; -ms-overflow-style: none;">
                                        <a href="{{ route('dashboard') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isDashboard, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isDashboard]) @if($isDashboard) aria-current="page" @endif>
                                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke-width="1.8"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke-width="1.8"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke-width="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.5" stroke-width="1.8"/></svg>
                                            <span>Painel</span>
                                        </a>

                                        @if($user->hasRole(['admin', 'gerente', 'vendedor', 'financeiro']))
                                            <a href="{{ route('clientes.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isClientes, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isClientes]) @if($isClientes) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="9" cy="8" r="3.2" stroke-width="1.8"/><path d="M3.5 19c.5-3.2 2.3-4.8 5.5-4.8s5 1.6 5.5 4.8M16 5.2a3.2 3.2 0 010 6.1M17 14.5c2.1.6 3.3 2 3.6 4.5" stroke-width="1.8" stroke-linecap="round"/></svg>
                                                <span>Clientes</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente', 'vendedor', 'financeiro']))
                                            <a href="{{ route('agenda.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isAgenda, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isAgenda]) @if($isAgenda) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke-width="1.8"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke-width="1.8"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke-width="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.5" stroke-width="1.8"/></svg>
                                                <span>Agenda</span>
                                            </a>
                                        @endif

                                        @if($isAdmin)
                                            <a href="{{ route('admin.usuarios.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => request()->routeIs('admin.usuarios.*'), 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !request()->routeIs('admin.usuarios.*')]) @if(request()->routeIs('admin.usuarios.*')) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M12 4v16m8-8H4" stroke-width="1.8"/><path d="M20 16v4a2 2 0 01-2 2H6a2 2 0 01-2-2v-4M12 14a7 7 0 10-7-7 7 7 0 007 7z"/></svg>
                                                <span>Usuários</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente']))
                                            <a href="{{ route('fornecedores.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isFornecedores, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isFornecedores]) @if($isFornecedores) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 20h18M5 20V7l7-4 7 4v13M9 10h.01M15 10h.01M9 14h.01M15 14h.01M10 20v-3h4v3" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                                <span>Fornecedores</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente', 'financeiro']))
                                            <a href="{{ route('compras.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isCompras, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isCompras]) @if($isCompras) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3h2l2.4 12.2a2 2 0 002 1.6h8.8a2 2 0 002-1.6L22 8H6M10 21h.01M18 21h.01" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                                <span>Compras</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente', 'vendedor', 'financeiro']))
                                            <a href="{{ route('vendas.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isVendas, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isVendas]) @if($isVendas) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M3 3v18h18M3 9h18M9 9v18M15 9v18M7 13v6M11 13v6M13 13v6"/></svg>
                                                <span>Vendas</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente', 'tecnico']))
                                            <a href="{{ route('ordens-servico.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isOS, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isOS]) @if($isOS) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3h18v18H3z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                                <span>Ordens Serv.</span>
                                            </a>
                                        @endif

                                        @if($isFinanceiro)
                                            <a href="{{ route('contas-receber.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isContasReceber, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isContasReceber]) @if($isContasReceber) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M24 16c0 1.105-.895 2-2 2H2c-1.105 0-2-.895-2-2v-8c0-1.105.895-2 2-2h12c1.105 0 2 .895 2 2z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                                <span>Contas Rec.</span>
                                            </a>
                                            <a href="{{ route('contas-pagar.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isContasPagar, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isContasPagar]) @if($isContasPagar) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3h18v18H3z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                                <span>Contas Pagar</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente', 'vendedor']))
                                            <a href="{{ route('produtos.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isProdutos, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isProdutos]) @if($isProdutos) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="m4 7 8-4 8 4-8 4-8-4Zm0 0v10l8 4 8-4V7M12 11v10" stroke-width="1.8" stroke-linejoin="round"/></svg>
                                                <span>Produtos</span>
                                            </a>
                                        @endif

                                        @if($user->hasRole(['admin', 'gerente', 'vendedor']))
                                            <a href="{{ route('crm.index') }}" @class(['shrink-0 inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-3.5', 'bg-white text-[#064E3B] shadow-sm' => $isCrm, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isCrm]) @if($isCrm) aria-current="page" @endif>
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M12 4.5v15m7.5-7.5h-15" stroke-width="1.5" stroke-linecap="round"/></svg>
                                                <span>CRM</span>
                                            </a>
                                        @endif
                                    </nav>

                                    <button type="button" onclick="scrollNav(1)" class="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-white/90 hover:bg-white/20 transition active:scale-95 ml-1" aria-label="Próximo menu" title="Próximo menu">
                                        <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" /></svg>
                                    </button>
                                </div>
                <div class="flex shrink-0 items-center gap-2.5">
                    <!-- Alternador de Tema Escuro / Claro -->
                    <button type="button" onclick="toggleTheme()" id="theme-toggle-btn" class="flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-white transition hover:bg-white/20 active:scale-95 shadow-sm" title="Alternar modo escuro / claro" aria-label="Alternar modo escuro / claro">
                        <svg id="theme-icon-sun" class="h-4 w-4 hidden text-[#E2B15E]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                        <svg id="theme-icon-moon" class="h-4 w-4 hidden text-emerald-100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                    </button>

                    <div class="hidden text-right sm:block"><div class="max-w-36 truncate text-sm font-semibold">{{ auth()->user()->nome ?? auth()->user()->name }}</div><div class="text-[11px] text-emerald-100/75">{{ auth()->user()->role ?? 'Usuário' }}</div></div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-[#C68346] text-sm font-bold text-white" aria-hidden="true">{{ mb_strtoupper(mb_substr(auth()->user()->nome ?? auth()->user()->name ?? 'U', 0, 1)) }}</div>
                    <form method="POST" action="{{ route('logout') }}">@csrf<button type="submit" class="rounded-xl border border-white/15 px-3 py-2 text-xs font-semibold text-emerald-50 transition hover:border-white/30 hover:bg-white/10 sm:text-sm">Sair</button></form>
                </div>
            </div>
        </header>
    @endif
        <div id="app">
            @yield('content')
        </div>
        @stack('scripts')
        <script>
            function scrollNav(direction) {
                var nav = document.getElementById('main-nav-container');
                if (nav) {
                    nav.scrollBy({ left: direction * 220, behavior: 'smooth' });
                }
            }
            function updateThemeIcons() {
                var isDark = document.documentElement.classList.contains('dark');
                var sun = document.getElementById('theme-icon-sun');
                var moon = document.getElementById('theme-icon-moon');
                if (sun && moon) {
                    if (isDark) {
                        sun.classList.remove('hidden');
                        moon.classList.add('hidden');
                    } else {
                        sun.classList.add('hidden');
                        moon.classList.remove('hidden');
                    }
                }
            }
            function toggleTheme() {
                if (document.documentElement.classList.contains('dark')) {
                    document.documentElement.classList.remove('dark');
                    localStorage.setItem('zeno_theme', 'light');
                } else {
                    document.documentElement.classList.add('dark');
                    localStorage.setItem('zeno_theme', 'dark');
                }
                updateThemeIcons();
            }
            document.addEventListener('DOMContentLoaded', function() {
                updateThemeIcons();
                var nav = document.getElementById('main-nav-container');
                var active = nav ? nav.querySelector('[aria-current="page"]') : null;
                if (active && nav) {
                    active.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }
            });
        </script>
    </body>
    </html>