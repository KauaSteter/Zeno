@extends('layouts.app')

@section('content')
<div class="min-h-screen bg-gray-50 dark:bg-zeno-dark-bg">
    <!-- Stats Cards -->
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="mb-8">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
            <p class="mt-1 text-gray-500 dark:text-gray-400">Bem-vindo, {{ auth()->user()->nome ?? auth()->user()->name }}!</p>
            <div class="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div class="text-sm text-gray-600 dark:text-gray-300">Última atualização: {{ now()->format('d/m/Y H:i') }}</div>
                <div class="flex items-center gap-2">
                    <a href="{{ route('produtos.create') }}" class="inline-flex items-center gap-2 rounded-xl bg-zeno-forest px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-zeno-forest/20 hover:bg-[#075F44] focus:outline-none focus:ring-2 focus:ring-zeno-forest focus:ring-offset-2 transition">
                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        Novo Produto
                    </a>
                    <a href="{{ route('produtos.index') }}" class="inline-flex items-center gap-2 rounded-xl border border-zeno-forest bg-white px-4 py-2 text-sm font-semibold text-zeno-forest hover:bg-zeno-forest/5 transition dark:bg-gray-800 dark:border-zeno-forest/40 dark:text-zeno-copper">
                        Ver Produtos
                    </a>
                </div>
            </div>
        </div>

        @php
            $produtosAtivos = \App\Models\Produto::where('ativo', true)->count();
            $produtosBaixoEstoque = \App\Models\Produto::where('ativo', true)->whereColumn('estoque_atual', '<', 'estoque_minimo')->count();
            $totalEstoqueValor = \App\Models\Produto::where('ativo', true)->sum(\DB::raw('preco_venda * estoque_atual'));
            $totalCustoValor = null; // preco_custo não existe na tabela produtos do Supabase.
        @endphp

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
            <div class="group relative overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Produtos</p>
                        <p class="mt-1 text-3xl font-bold text-gray-900 dark:text-white">{{ $produtosAtivos }}</p>
                        <p class="mt-1 text-xs text-gray-400 dark:text-gray-500">{{ $totalEstoqueValor ? 'em estoque' : 'sem produtos' }}</p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-zeno-forest/10 group-hover:bg-zeno-forest/15 transition-colors">
                        <svg class="h-6 w-6 text-zeno-forest" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18M8 12h8M12 16h.01M3 7v12a2 2 0 002 2h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                </div>
                <div class="absolute inset-x-0 bottom-0 h-1 bg-zeno-forest/10"></div>
            </div>

            <div class="group relative overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Valor Estoque</p>
                        <p class="mt-1 text-3xl font-bold text-gray-900 dark:text-white">R$ {{ number_format($totalEstoqueValor, 2, ',', '.') }}</p>
                        <p class="mt-1 text-xs text-gray-400 dark:text-gray-500">valor de venda estimado</p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-zeno-copper/10 group-hover:bg-zeno-copper/15 transition-colors">
                        <svg class="h-6 w-6 text-zeno-copper" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 6v6l4 2" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 12h18" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                </div>
                <div class="absolute inset-x-0 bottom-0 h-1 bg-zeno-copper/10"></div>
            </div>

            <div class="group relative overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Baixo Estoque</p>
                        <p class="mt-1 text-3xl font-bold text-gray-900 dark:text-white">{{ $produtosBaixoEstoque }}</p>
                        <p class="mt-1 text-xs text-gray-400 dark:text-gray-500">itens críticos</p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-red-500/10 group-hover:bg-red-500/15 transition-colors">
                        <svg class="h-6 w-6 text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 9v2m.01 4h.01" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><rect x="3" y="8" width="18" height="4" rx="2" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                </div>
                <div class="absolute inset-x-0 bottom-0 h-1 bg-red-500/10"></div>
            </div>

            <div class="group relative overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Total Clientes</p>
                        <p class="mt-1 text-3xl font-bold text-gray-900 dark:text-white">{{ \App\Models\Cliente::count() }}</p>
                        <p class="mt-1 text-xs text-gray-400 dark:text-gray-500">cadastrados</p>
                    </div>
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-zeno-gold/10 group-hover:bg-zeno-gold/15 transition-colors">
                        <svg class="h-6 w-6 text-zeno-gold" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke-width="1.8"/></svg>
                    </div>
                </div>
                <div class="absolute inset-x-0 bottom-0 h-1 bg-zeno-gold/10"></div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm">
            <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Ações Rápidas</h2>
            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <a href="{{ route('produtos.index') }}" class="flex items-center gap-3 rounded-xl p-4 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-zeno-forest/5 hover:text-zeno-forest dark:hover:bg-zeno-forest/10 transition-colors border border-gray-100 dark:border-gray-700 hover:border-zeno-forest/20">
                    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-zeno-forest/10 text-zeno-forest">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke-width="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke-width="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke-width="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5" stroke-width="1.5"/></svg>
                    </div>
                    <span>Produtos</span>
                </a>
                <a href="{{ route('clientes.create') }}" class="flex items-center gap-3 rounded-xl p-4 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-zeno-copper/5 hover:text-zeno-copper dark:hover:bg-zeno-copper/10 transition-colors border border-gray-100 dark:border-gray-700 hover:border-zeno-copper/20">
                    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-zeno-copper/10 text-zeno-copper">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4"/><path d="M12 7v4l3 3"/></svg>
                    </div>
                    <span>Novo Cliente</span>
                </a>
                <a href="{{ route('fornecedores.index') }}" class="flex items-center gap-3 rounded-xl p-4 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-zeno-forest/5 hover:text-zeno-forest dark:hover:bg-zeno-forest/10 transition-colors border border-gray-100 dark:border-gray-700 hover:border-zeno-forest/20">
                    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-zeno-forest/10 text-zeno-forest">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 11H5M19 11V19a2 2 0 01-2 2H5a2 2 0 01-2-2V11m19 0v-7a2 2 0 00-2-2M5 11V4a2 2 0 012-2m0 0h6" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <span>Fornecedores</span>
                </a>
                <a href="{{ route('compras.index') }}" class="flex items-center gap-3 rounded-xl p-4 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-zeno-forest/5 hover:text-zeno-forest dark:hover:bg-zeno-forest/10 transition-colors border border-gray-100 dark:border-gray-700 hover:border-zeno-forest/20">
                    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-zeno-forest/10 text-zeno-forest">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 3h2l2.4 12.2a2 2 0 002 1.6h8.8a2 2 0 002-1.6L22 8H6M10 21h.01M18 21h.01" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <span>Compras</span>
                </a>
                <a href="javascript:;" class="flex items-center gap-3 rounded-xl p-4 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors border border-gray-100 dark:border-gray-700 cursor-not-allowed opacity-50">
                    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-zeno-gold/10 text-zeno-gold">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 3v18h18M9 12l2 2 4-4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <span>Vendas / PDV</span>
                </a>
                <a href="{{ route('estoque.baixo') }}" class="flex items-center gap-3 rounded-xl p-4 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-red-500/5 hover:text-red-600 transition-colors border border-gray-100 dark:border-gray-700">
                    <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-red-500/10 text-red-500">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 7h16M4 12h16M4 17h16" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <span>Estoque baixo</span>
                </a>
            </div>
        </div>
    </div>
</div>
@endsection