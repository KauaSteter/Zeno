@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-8">
    <div class="mb-6 flex items-center justify-between">
        <h1 class="text-3xl font-bold">Pedidos de Compra</h1>
        <a class="rounded bg-emerald-900 px-4 py-2 font-semibold text-white hover:bg-emerald-800" href="{{ route('compras.create') }}">Nova Compra</a>
    </div>

    @if(session('success'))
        <p class="mb-4 rounded bg-emerald-50 p-3 text-emerald-800">{{ session('success') }}</p>
    @endif

    <div class="overflow-x-auto rounded border bg-white shadow-sm">
        <table class="min-w-full">
            <thead>
                <tr class="bg-gray-50 text-left">
                    <th class="p-3">Número</th>
                    <th class="p-3">Fornecedor</th>
                    <th class="p-3">Data</th>
                    <th class="p-3">Total</th>
                    <th class="p-3">Status</th>
                    <th class="p-3 text-right">Ações</th>
                </tr>
            </thead>
            <tbody>
                @forelse($compras as $compra)
                <tr class="border-t">
                    <td class="p-3">
                        <a class="font-semibold text-emerald-800 underline" href="{{ route('compras.show', $compra) }}">{{ $compra->numero_compra }}</a>
                    </td>
                    <td class="p-3">{{ $compra->fornecedor?->nome ?? '—' }}</td>
                    <td class="p-3">{{ $compra->data_compra->format('d/m/Y') }}</td>
                    <td class="p-3 font-medium">R$ {{ number_format($compra->total, 2, ',', '.') }}</td>
                    <td class="p-3">
                        <span class="inline-block rounded-full px-3 py-1 text-xs font-semibold
                            @if($compra->status == 'pendente') bg-yellow-100 text-yellow-800 
                            @elseif($compra->status == 'recebido') bg-emerald-100 text-emerald-800 
                            @else bg-gray-100 text-gray-800 @endif">
                            {{ ucfirst(str_replace('_', ' ', $compra->status)) }}
                        </span>
                    </td>
                    <td class="p-3 text-right">
                        <a class="rounded bg-gray-100 px-3 py-1 text-sm font-medium text-gray-700 hover:bg-gray-200" href="{{ route('compras.show', $compra) }}">Ver / Receber</a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="p-8 text-center text-gray-500">Nenhuma compra registrada.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $compras->links() }}
    </div>
</div>
@endsection
