@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-5xl px-4 py-8">
    <div class="mb-5 flex flex-wrap justify-between gap-3">
        <div>
            <a class="text-emerald-800 underline" href="{{ route('compras.index') }}">← Compras</a>
            <h1 class="mt-2 text-3xl font-bold">{{ $compra->numero_compra }}</h1>
        </div>
        <span class="h-fit rounded-full px-4 py-2 font-semibold 
            @if($compra->status == 'pendente') bg-yellow-100 text-yellow-800 
            @elseif($compra->status == 'recebido') bg-emerald-100 text-emerald-800 
            @else bg-gray-100 text-gray-800 @endif">
            {{ ucfirst(str_replace('_',' ',$compra->status)) }}
        </span>
    </div>

    @if(session('success'))
        <p class="mb-4 rounded bg-emerald-50 p-3 text-emerald-800">{{ session('success') }}</p>
    @endif

    @if($errors->any())
        <p class="mb-4 rounded bg-red-50 p-3 text-red-800">{{ $errors->first() }}</p>
    @endif

    <div class="mb-5 rounded border bg-white p-5 shadow-sm">
        <p class="mb-2"><b>Fornecedor:</b> {{ $compra->fornecedor?->nome ?? '—' }}</p>
        <p class="mb-2"><b>Data da Compra:</b> {{ $compra->data_compra->format('d/m/Y') }} 
            @if($compra->data_entrega_real)
                <span class="text-gray-600">· Recebida em: {{ $compra->data_entrega_real->format('d/m/Y') }}</span>
            @endif
        </p>
        <p class="text-lg font-bold"><b>Total:</b> R$ {{ number_format($compra->total, 2, ',', '.') }}</p>
    </div>

    <div class="overflow-x-auto rounded border bg-white shadow-sm">
        <table class="min-w-full">
            <thead>
                <tr class="bg-gray-50 text-left">
                    <th class="p-3">Produto</th>
                    <th class="p-3 text-center">Pedido</th>
                    <th class="p-3 text-center">Recebido</th>
                    <th class="p-3 text-right">Custo unit.</th>
                    <th class="p-3 text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($compra->itens as $item)
                <tr class="border-t">
                    <td class="p-3">{{ $item->produto?->nome ?? '—' }}</td>
                    <td class="p-3 text-center">{{ $item->quantidade }}</td>
                    <td class="p-3 text-center">{{ $item->quantidade_recebida }}</td>
                    <td class="p-3 text-right">R$ {{ number_format($item->custo_unitario, 2, ',', '.') }}</td>
                    <td class="p-3 text-right">R$ {{ number_format($item->total, 2, ',', '.') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    @if(in_array($compra->status, ['pendente', 'recebido_parcial'], true))
    <div class="mt-6 rounded border bg-white p-5 shadow-sm">
        <h3 class="mb-3 text-lg font-bold">Recebimento de Mercadoria</h3>
        <p class="mb-4 text-sm text-gray-600">Confirme o recebimento para dar entrada automática dos produtos no estoque e atualizar o status do pedido.</p>
        <form method="POST" action="{{ route('compras.receive', $compra) }}" onsubmit="return confirm('Confirmar recebimento e entrada dos itens no estoque?')">
            @csrf
            <button class="rounded bg-emerald-900 px-6 py-3 font-semibold text-white hover:bg-emerald-800">
                Receber mercadoria e atualizar estoque
            </button>
        </form>
    </div>
    @endif
</div>
@endsection
