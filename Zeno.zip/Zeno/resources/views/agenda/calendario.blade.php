@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Calendário de Atividades</h1>
        <a href="{{ route('agenda.index') }}" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
            Voltar à Lista
        </a>
    </div>

    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
        <div class="px-6 py-4 border-b border-gray-200">
            <form method="GET" class="flex items-center gap-4">
                <div>
                    <label class="text-xs text-gray-500">Mês</label>
                    <select name="mes" onchange="this.form.submit()" class="border-gray-300 rounded-md shadow-sm">
                        @foreach($anos as $ano)
                            @foreach($meses as $num => $nome)
                                <option value="{{ $ano }}-{{ $num }}" {{ request('mes') == ($ano . '-' . $num) ? 'selected' : '' }}>
                                    {{ $nome }} / {{ $ano }}
                                </option>
                            @endforeach
                        @endforeach
                    </select>
                </div>
            </form>
        </div>

        <div class="p-6">
            <div class="grid grid-cols-7 gap-px bg-gray-200">
                @foreach(['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'] as $dia)
                    <div class="bg-gray-100 p-2 text-center font-semibold text-gray-700">{{ $dia }}</div>
                @endforeach
            </div>

            @php
                            $primeiroDia = (int) \Carbon\Carbon::parse($mes . '-01')->isoFormat('e');
                            $diasNoMes = \Carbon\Carbon::parse($mes . '-01')->daysInMonth;
                            $col = $primeiroDia - 1;
                        @endphp

            <div class="grid grid-cols-7 gap-px bg-gray-200">
                @for($i = 0; $i < $primeiroDia - 1; $i++)
                    <div class="bg-gray-50 p-2 text-center text-gray-400"> </div>
                @endfor

                @for($dia = 1; $dia <= $diasNoMes; $dia++)
                    @php
                        $data = \Carbon\Carbon::parse($mes . '-' . str_pad($dia, 2, '0', STR_PAD_LEFT));
                        $eventosDoDia = $eventos->filter(fn ($evento) => \Carbon\Carbon::parse($evento['start'])->isSameDay($data));
                    @endphp
                    <div class="bg-white p-2 min-h-[100px] relative border-r border-t border-gray-300">
                                            <span class="text-xs text-gray-500">{{ $dia }}</span>
                                            @if($eventosDoDia->isNotEmpty())
                                                <div class="mt-1 space-y-1">
                                                    @foreach($eventosDoDia as $evento)
                                                        <div class="text-xs p-1 rounded bg-gray-100">
                                                            <span class="block truncate">{{ $evento->title }}</span>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                @endfor
            </div>
        </div>
    </div>
</div>
@endsection