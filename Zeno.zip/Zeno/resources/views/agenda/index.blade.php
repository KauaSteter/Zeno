@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Agenda</h1>

    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
        <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex flex-col sm:flex-row justify-between items-start gap-4">
                <a href="{{ route('agenda.calendario') }}" class="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                    <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 8v11a2 2 0 002 2h8a2 2 0 002-2V8H5z" />
                    </svg>
                    Ver Calendário
                </a>

                <form method="GET" class="flex flex-wrap items-center gap-3">
                    <div>
                        <label for="categoria" class="text-xs text-gray-500">Categoria</label>
                        <select name="categoria" id="categoria" class="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">Todas</option>
                            <option value="crm" {{ request('categoria') == 'crm' ? 'selected' : '' }}>CRM</option>
                            <option value="compras" {{ request('categoria') == 'compras' ? 'selected' : '' }}>Compras</option>
                            <option value="financeiro" {{ request('categoria') == 'financeiro' ? 'selected' : '' }}>Financeiro</option>
                            <option value="estoque" {{ request('categoria') == 'estoque' ? 'selected' : '' }}>Estoque</option>
                        </select>
                    </div>

                    <div>
                        <label for="status" class="text-xs text-gray-500">Status</label>
                        <select name="status" id="status" class="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">Todos</option>
                            <option value="pendente" {{ request('status') == 'pendente' ? 'selected' : '' }}>Pendentes</option>
                            <option value="concluido" {{ request('status') == 'concluido' ? 'selected' : '' }}>Concluídos</option>
                        </select>
                    </div>

                    <div>
                        <label for="data_inicio" class="text-xs text-gray-500">De</label>
                        <input type="date" name="data_inicio" id="data_inicio" value="{{ request('data_inicio') }}" class="border-gray-300 rounded-md shadow-sm">
                    </div>

                    <div>
                        <label for="data_fim" class="text-xs text-gray-500">Até</label>
                        <input type="date" name="data_fim" id="data_fim" value="{{ request('data_fim') }}" class="border-gray-300 rounded-md shadow-sm">
                    </div>

                    <button type="submit" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                        Filtrar
                    </button>
                </form>
            </div>
        </div>

        @if($eventos->count())
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Título</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoria</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prioridade</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($eventos as $evento)
                        <tr class="@if($evento->isVencido()) bg-red-50 @elseif($evento->status === 'concluido') bg-green-50 @endif">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $evento->data_evento->format('d/m/Y') }}
                                @if($evento->hora)
                                    <br><span class="text-gray-500">{{ \Carbon\Carbon::parse($evento->hora)->format('H:i') }}</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {{ $evento->titulo }}
                                @if($evento->cliente_id)
                                    <br><span class="text-gray-500">Cliente: {{ $evento->cliente->nome ?? 'N/A' }}</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                @php
                                    $labels = [
                                        'crm' => 'CRM',
                                        'compras' => 'Compras',
                                        'financeiro' => 'Financeiro',
                                        'estoque' => 'Estoque',
                                        'outro' => 'Outro'
                                    ];
                                @endphp
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                    {{ $evento->categoria === 'financeiro' ? 'bg-purple-100 text-purple-800' : 
                                    ($evento->categoria === 'compras' ? 'bg-blue-100 text-blue-800' : 
                                    ($evento->categoria === 'crm' ? 'bg-green-100 text-green-800' : 
                                    ($evento->categoria === 'estoque' ? 'bg-orange-100 text-orange-800' : 
                                    'bg-gray-100 text-gray-800'))) }}">
                                    {{ $labels[$evento->categoria] ?? $evento->categoria }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                    {{ $evento->prioridade === 'alta' ? 'bg-red-100 text-red-800' : 
                                    ($evento->prioridade === 'normal' ? 'bg-yellow-100 text-yellow-800' : 
                                    'bg-gray-100 text-gray-800') }}">
                                    {{ ucfirst($evento->prioridade) }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div class="flex space-x-2">
                                    <a href="{{ route('agenda.show', $evento) }}" class="text-indigo-600 hover:text-indigo-900">Detalhes</a>
                                    @if($evento->status === 'pendente')
                                        <form action="{{ route('agenda.show', $evento) }}" method="GET">
                                            @csrf
                                            <button type="submit" class="text-green-600 hover:text-green-900">
                                                Marcar OK
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200">
                {{ $eventos->links() }}
            </div>
        @else
            <div class="text-center py-12">
                <p class="text-gray-500">Nenhum evento encontrado.</p>
                <a href="{{ route('agenda.create') }}" class="mt-4 inline-block text-blue-600 hover:text-blue-500">
                    Criar primeiro evento →
                </a>
            </div>
        @endif
    </div>
</div>
@endsection