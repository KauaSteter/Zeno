@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Novo Evento</h1>

    @if($errors->any())
        <div class="bg-red-100 border border-red-200 text-red-800 px-4 py-3 rounded mb-4">
            <strong class="font-bold">Ops! Há erros.</strong>
            <ul class="mt-1 list-disc list-inside text-sm">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('agenda.store') }}" method="POST">
        @csrf
        <div class="space-y-6 bg-white p-6 rounded-lg shadow">
            <div>
                <label for="titulo" class="block text-sm font-medium text-gray-700">Título *</label>
                <input type="text" name="titulo" id="titulo" value="{{ old('titulo') }}" required
                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            </div>

            <div>
                <label for="descricao" class="block text-sm font-medium text-gray-700">Descrição</label>
                <textarea name="descricao" id="descricao" rows="3"
                          class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">{{ old('descricao') }}</textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="data_evento" class="block text-sm font-medium text-gray-700">Data *</label>
                    <input type="date" name="data_evento" id="data_evento" value="{{ old('data_evento', now()->format('Y-m-d')) }}" required
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>

                <div>
                    <label for="hora" class="block text-sm font-medium text-gray-700">Hora</label>
                    <input type="time" name="hora" id="hora" value="{{ old('hora') }}"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="categoria" class="block text-sm font-medium text-gray-700">Categoria *</label>
                    <select name="categoria" id="categoria" required
                            onchange="var cDiv = document.getElementById('cliente_id').parentElement; if(cDiv) cDiv.style.display = this.value === 'crm' ? 'block' : 'none'; var fDiv = document.getElementById('fornecedor_id').parentElement; if(fDiv) fDiv.style.display = this.value === 'compras' ? 'block' : 'none'; var cmDiv = document.getElementById('compra_id').parentElement; if(cmDiv) cmDiv.style.display = this.value === 'compras' ? 'block' : 'none'">
                        <option value="">-- Selecionar --</option>
                        <option value="crm" {{ old('categoria') == 'crm' ? 'selected' : '' }}>CRM (Contato)</option>
                        <option value="compras" {{ old('categoria') == 'compras' ? 'selected' : '' }}>Compras</option>
                        <option value="financeiro" {{ old('categoria') == 'financeiro' ? 'selected' : '' }}>Financeiro</option>
                        <option value="estoque" {{ old('categoria') == 'estoque' ? 'selected' : '' }}>Estoque</option>
                        <option value="outro" {{ old('categoria') == 'outro' ? 'selected' : '' }}>Outro</option>
                    </select>
                </div>

                <div>
                    <label for="prioridade" class="block text-sm font-medium text-gray-700">Prioridade</label>
                    <select name="prioridade" id="prioridade" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        <option value="baixa" {{ old('prioridade') == 'baixa' ? 'selected' : '' }}>Baixa</option>
                        <option value="normal" {{ old('prioridade') == 'normal' ? 'selected' : '' }}>Normal</option>
                        <option value="alta" {{ old('prioridade') == 'alta' ? 'selected' : '' }}>Alta</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div style="margin-top: 1rem;">
                    <label for="cliente_id" class="block text-sm font-medium text-gray-700">Cliente (CRM)</label>
                    <select name="cliente_id" id="cliente_id" class="mt-1 block w-full">
                        <option value="">-- Nenhum --</option>
                        @foreach($clientes as $cliente)
                            <option value="{{ $cliente->id }}" {{ old('cliente_id') == $cliente->id ? 'selected' : '' }}>
                                {{ $cliente->nome }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label for="usuario_id" class="block text-sm font-medium text-gray-700">Responsável</label>
                    <select name="usuario_id" id="usuario_id" class="mt-1 block w-full">
                        <option value="">Nenhum (usuário atual)</option>
                        @foreach($usuarios as $usuario)
                            <option value="{{ $usuario->id }}" {{ old('usuario_id') == $usuario->id ? 'selected' : '' }}>
                                {{ $usuario->nome }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="mt-4">
                    <label for="fornecedor_id" class="block text-sm font-medium text-gray-700">Fornecedor (Compras)</label>
                    <select name="fornecedor_id" id="fornecedor_id" class="mt-1 block w-full">
                        <option value="">-- Nenhum --</option>
                        @foreach($fornecedores as $fornecedor)
                            <option value="{{ $fornecedor->id }}" {{ old('fornecedor_id') == $fornecedor->id ? 'selected' : '' }}>
                                {{ $fornecedor->razao_social }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mt-4">
                    <label for="compra_id" class="block text-sm font-medium text-gray-700">Compra relacionada</label>
                    <select name="compra_id" id="compra_id" class="mt-1 block w-full">
                        <option value="">-- Nenhuma --</option>
                        @foreach($compras as $compra)
                            <option value="{{ $compra->id }}" {{ old('compra_id') == $compra->id ? 'selected' : '' }}>
                                {{ $compra->numero }} - {{ $compra->fornecedor->razao_social ?? 'N/A' }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="recorrencia" class="block text-sm font-medium text-gray-700">Recorrência</label>
                    <select name="recorrencia" id="recorrencia" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        <option value="nunca" {{ old('recorrencia', 'nunca') == 'nunca' ? 'selected' : '' }}>Nunca</option>
                        <option value="diario" {{ old('recorrencia') == 'diario' ? 'selected' : '' }}>Diário</option>
                        <option value="semanal" {{ old('recorrencia') == 'semanal' ? 'selected' : '' }}>Semanal</option>
                        <option value="quinzenal" {{ old('recorrencia') == 'quinzenal' ? 'selected' : '' }}>Quinzenal</option>
                        <option value="mensal" {{ old('recorrencia') == 'mensal' ? 'selected' : '' }}>Mensal</option>
                    </select>
                </div>

                <div id="data_fim_recorrencia_wrapper">
                    <label for="data_fim_recorrencia" class="block text-sm font-medium text-gray-700">Data fim recorrência</label>
                    <input type="date" name="data_fim_recorrencia" id="data_fim_recorrencia" value="{{ old('data_fim_recorrencia') }}"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="{{ route('agenda.index') }}" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                    Cancelar
                </a>
                <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    Criar Evento
                </button>
            </div>
        </div>
    </form>
</div>

@push('scripts')
<script>
    // Inicializa visibilidade
    document.addEventListener('DOMContentLoaded', function() {
        var categoriaSelect = document.getElementById('categoria');
        aplicarVisibilidade(categoriaSelect.value);

        categoriaSelect.addEventListener('change', function() {
            aplicarVisibilidade(this.value);
        });
    });

    function aplicarVisibilidade(categoria) {
        var clienteDiv = document.getElementById('cliente_id').closest('.mt-4');
        if (clienteDiv) clienteDiv.style.display = categoria === 'crm' ? 'block' : 'none';
        
        var fornecedorDiv = document.getElementById('fornecedor_id').closest('.mt-4');
        if (fornecedorDiv) fornecedorDiv.style.display = categoria === 'compras' ? 'block' : 'none';
        
        var compraDiv = document.getElementById('compra_id').closest('.mt-4');
        if (compraDiv) compraDiv.style.display = categoria === 'compras' ? 'block' : 'none';
    }
</script>
@endpush
@endsection