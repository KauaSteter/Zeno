@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <p class="text-xs font-semibold uppercase tracking-wider text-zeno-forest">Vendas</p>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Histórico de Vendas</h1>
        </div>
        <a href="{{ route('vendas.create') }}" class="inline-flex items-center gap-2 rounded-xl bg-zeno-forest px-5 py-3 text-sm font-semibold text-white shadow-sm shadow-zeno-forest/20 hover:bg-[#075F44] focus:outline-none focus:ring-2 focus:ring-zeno-forest focus:ring-offset-2 transition">
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Novo PDV
        </a>
    </div>

    @if(session('success'))
        <div class="mb-4 rounded-xl bg-amber-100 px-4 py-3 text-sm text-amber-800 dark:bg-amber-900 dark:text-amber-200">
            {{ session('success') }}
        </div>
    @endif

    @if($vendas->count() > 0)
        <div class="grid gap-4">
            @foreach($vendas as $venda)
                <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow">
                    <div class="border-b border-gray-200 px-6 py-4 sm:flex sm:items-center sm:justify-between">
                        <div class="space-y-1">
                            <p class="text-sm font-semibold text-zeno-forest">{{ $venda->numero_venda }}</p>
                            <p class="text-sm text-gray-500 dark:text-gray-400">{{ $venda->data_venda->format('d/m/Y H:i') }}</p>
                            @if($venda->cliente)
                                <p class="text-sm text-gray-600 dark:text-gray-300"><strong>Cliente:</strong> {{ $venda->cliente->nome }}</p>
                            @endif
                        </div>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                            @if($venda->status_pagamento === 'pago') bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200
                            @elseif($venda->status_pagamento === 'pendente') bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200
                            @else bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 @endif">
                            {{ ucfirst($venda->status_pagamento) }}
                        </span>
                    </div>
                    <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="md:col-span-3">
                            <div class="flex flex-wrap gap-4 text-sm">
                                <span class="text-gray-600 dark:text-gray-300"><strong>Subtotal:</strong> R$ {{ number_format($venda->subtotal, 2, ',', '.') }}</span>
                                <span class="text-gray-600 dark:text-gray-300"><strong>Forma:</strong> {{ ucfirst($venda->forma_pagamento) }}</span>
                                <span class="text-gray-600 dark:text-gray-300"><strong>Pagamento:</strong> {{ ucfirst($venda->status_pagamento) }}</span>
                            </div>
                        </div>
                        <a href="{{ route('vendas.show', $venda) }}" class="inline-flex items-center gap-2 rounded-lg border border-zeno-forest bg-white dark:bg-gray-700 px-3 py-2 text-sm font-semibold text-zeno-forest hover:bg-zeno-forest/5 transition">
                            Ver detalhes
                        </a>
                    </div>
                </div>
            @endforeach)
        </div>
        
        <div class="mt-6">
            {{ $vendas->links() }}
        </div>
    @else
        <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800 p-8 text-center">
            <div class="mb-4 text-gray-400 dark:text-gray-500">
                <svg class="h-12 w-12 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4" />
                </svg>
            </div>
            <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">Nenhuma venda cadastrada</h3>
            <p class="text-gray-500 dark:text-gray-400 mb-4">Comece registrando sua primeira venda pelo PDV.</p>
            <a href="{{ route('vendas.create') }}" class="inline-flex items-center gap-2 rounded-xl bg-zeno-forest px-5 py-3 text-sm font-semibold text-white shadow-sm shadow-zeno-forest/20 hover:bg-[#075F44] focus:outline-none focus:ring-2 focus:ring-zeno-forest focus:ring-offset-2 transition">
                Abrir PDV
            </a>
        </div>
    @endif
</div>
@endsection