@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6">
        <p class="text-xs font-semibold uppercase tracking-wider text-zeno-forest">PDV</p>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Sistema de Venda</h1>
        <p class="text-sm text-gray-500 dark:text-gray-400">Venda rápida e eficiente</p>
    </div>

    <form id="venda-form" action="{{ route('vendas.store') }}" method="POST">
        @csrf
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Cliente (opcional)</label>
                    <select name="cliente_id" id="cliente_id" class="w-full rounded-xl border-gray-300 shadow-sm focus:border-zeno-forest focus:ring-zeno-forest dark:bg-gray-800 dark:border-gray-600">
                        <option value="">Cliente não informado</option>
                        @foreach($clientes as $cliente)
                            <option value="{{ $cliente->id }}">{{ $cliente->nome }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="space-y-4">
                <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4">
                                    <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-3">Produtos</h2>
                                                        <div id="produtos-list" class="mb-4">
                                                            @foreach($produtos as $produto)
                                                                <div class="flex items-center justify-between py-3 border-b border-gray-200 dark:border-gray-700 last:border-0">
                                                                    <div class="flex items-center">
                                                                        <span class="font-medium text-gray-700 dark:text-gray-300">{{ $produto->nome }}</span>
                                                                        <span class="text-sm text-gray-500 dark:text-gray-400 ml-2">R$ {{ $produto->preco_venda }}</span>
                                                                    </div>
                                                                    <button type="button" onclick="adicionarItem(@js($produto->id), @js($produto->nome), {{ (float) $produto->preco_venda }}, {{ (int) $produto->estoque_atual }})" class="text-green-600 hover:text-green-700 font-semibold">
                                                                        Adicionar
                                                                    </button>
                                                                </div>
                                                            @endforeach
                                                        </div>
                            </div>
                
                            <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4">
                                    <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-3">Carrinho</h2>
                        
                                    <div id="carrinho-vazio" class="text-center py-6 text-gray-400 dark:text-gray-500">
                                        <svg class="h-10 w-10 mx-auto mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4" />
                                        </svg>
                                        <p>Nenhum produto adicionado</p>
                                    </div>
                        
                                    <table class="w-full text-sm hidden" id="tabela-carrinho">
                                        <thead>
                                            <tr class="border-b border-gray-200 dark:border-gray-700">
                                                <th class="text-left pb-2 text-gray-600 dark:text-gray-400">Produto</th>
                                                <th class="text-right pb-2 text-gray-600 dark:text-gray-400">Qtd × Un</th>
                                                <th class="text-right pb-2 text-gray-600 dark:text-gray-400">Subtotal</th>
                                                <th class="w-6"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="itens-carrinho"></tbody>
                                    </table>
                            </div>
                
                <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4">
                    <div class="space-y-3">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Forma de Pagamento</label>
                            <select name="forma_pagamento" id="forma_pagamento" class="w-full rounded-xl border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600">
                                <option value="dinheiro">Dinheiro</option>
                                <option value="cartao">Cartão de Crédito</option>
                                <option value="pix">PIX</option>
                            </select>
                        </div>
                        
                        <div id="troco-container" class="hidden">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Troco</label>
                            <input type="number" step="0.01" min="0" name="troco" id="troco" class="w-full rounded-xl border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600" placeholder="Valor para troco">
                        </div>
                    </div>
                    
                    <div class="border-t border-gray-200 dark:border-gray-700 pt-3 mt-3">
                        <div class="flex justify-between items-center">
                            <span class="text-lg font-bold text-gray-800 dark:text-white">TOTAL</span>
                            <span id="total-venda-big" class="text-2xl font-bold text-zeno-forest">R$ 0,00</span>
                        </div>
                    </div>
                    
                    <div class="flex gap-2 mt-4">
                        <a href="{{ route('vendas.index') }}" class="flex-1 text-center px-4 py-2 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700">
                            Cancelar
                        </a>
                        <button type="submit" id="btn-finalizar" class="flex-1 bg-zeno-forest text-white px-4 py-2 rounded-xl hover:bg-[#075F44] transition-colors disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Finalizar Venda
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<div id="items-container"></div>

<script>
    let carrinho = [];
    let subtotalVenda = 0;
    
    function adicionarItem(id, nome, preco, estoque) {
        const existente = carrinho.find(item => item.id === id);
        if (existente) {
            if (existente.quantidade >= estoque) return;
            existente.quantidade++;
            existente.total = existente.quantidade * existente.preco;
        } else {
            if (estoque < 1) return;
            carrinho.push({id, nome, preco: Number(preco), quantidade: 1, estoque, total: Number(preco)});
        }
        subtotalVenda = carrinho.reduce((soma, item) => soma + item.total, 0);
        atualizarCarrinho();
    }
    
    function atualizarCarrinho() {
        const tabela = document.getElementById('tabela-carrinho');
        const vazio = document.getElementById('carrinho-vazio');
        const tbody = document.getElementById('itens-carrinho');
        const totalBig = document.getElementById('total-venda-big');
        const btnFinalizar = document.getElementById('btn-finalizar');
        
        if (carrinho.length === 0) {
            tabela.classList.add('hidden');
            vazio.classList.remove('hidden');
            btnFinalizar.disabled = true;
            return;
        }
        
        vazio.classList.add('hidden');
        tabela.classList.remove('hidden');
        
        tbody.innerHTML = '';
        carrinho.forEach((item, index) => {
            const tr = document.createElement('tr');
            tr.className = 'border-b border-gray-100 dark:border-gray-700';
            tr.innerHTML = 
                '<td class="py-2 text-sm font-medium text-gray-700 dark:text-gray-200">'+ item.nome +'</td>' +
                '<td class="text-right py-2 text-sm">'+ item.quantidade +' × R$ '+ item.preco.toFixed(2).replace('.', ',') +'</td>' +
                '<td class="text-right py-2 font-medium text-zeno-forest">R$ '+ item.total.toFixed(2).replace('.', ',') +'</td>' +
                '<td class="text-center py-2">'+
                '<button type="button" onclick="removerItem('+ index +')" class="text-red-500 hover:text-red-700">×</button>'+
                '</td>';
            tbody.appendChild(tr);
        });
        
        totalBig.textContent = 'R$ ' + subtotalVenda.toFixed(2).replace('.', ',');
        btnFinalizar.disabled = false;
    }
    
    function removerItem(index) {
        subtotalVenda -= carrinho[index].total;
        carrinho.splice(index, 1);
        atualizarCarrinho();
    }
    
    document.getElementById('forma_pagamento')?.addEventListener('change', function() {
        const trocoContainer = document.getElementById('troco-container');
        if (this.value === 'dinheiro') {
            trocoContainer.classList.remove('hidden');
        } else {
            trocoContainer.classList.add('hidden');
            document.getElementById('troco').value = '';
        }
    });
    
    document.getElementById('venda-form')?.addEventListener('submit', function(e) {
        const container = document.createElement('div');
        carrinho.forEach((item, index) => {
            const inputId = document.createElement('input');
            inputId.type = 'hidden';
            inputId.name = 'items['+ index +'][produto_id]';
            inputId.value = item.id;
            
            const inputQtd = document.createElement('input');
            inputQtd.type = 'hidden';
            inputQtd.name = 'items['+ index +'][quantidade]';
            inputQtd.value = item.quantidade;
            
            container.appendChild(inputId);
            container.appendChild(inputQtd);
        });
        
        document.getElementById('items-container').innerHTML = '';
        this.appendChild(container);
    });
</script>
@endsection