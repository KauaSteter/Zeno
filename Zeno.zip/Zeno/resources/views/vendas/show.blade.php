@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">{{ $venda->numero_venda }}</h1>
        <p class="text-sm text-gray-500 dark:text-gray-400">{{ $venda->data_venda->format('d/m/Y H:i') }}</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="space-y-4">
            <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-6">
                <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Informações</h2>
                <div class="space-y-3">
                    @if($venda->cliente)
                        <div class="bg-blue-50 dark:bg-blue-900 rounded-lg p-3">
                            <div class="text-xs text-blue-600 dark:text-blue-300 uppercase">Cliente</div>
                            <div class="font-medium text-blue-800 dark:text-blue-200">{{ $venda->cliente->nome }}</div>
                        </div>
                    @endif
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <div class="text-xs text-gray-500 dark:text-gray-400 uppercase">Origem</div>
                            <div class="font-medium text-gray-900 dark:text-white">{{ $venda->origem }}</div>
                        </div>
                        <div>
                            <div class="text-xs text-gray-500 dark:text-gray-400 uppercase">Forma</div>
                            <div class="font-medium text-gray-900 dark:text-white">{{ $venda->forma_pagamento ?: '—' }}</div>
                        </div>
                    </div>
                    <div class="mt-3">
                        <div class="text-xs text-gray-500 dark:text-gray-400 uppercase">Pagamento</div>
                        <div class="font-medium text-gray-900 dark:text-white">{{ ucfirst($venda->status_pagamento ?: 'pendente') }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Itens ({{ $venda->itens->count() }})</h2>
            <div class="divide-y divide-gray-200 dark:divide-gray-700">
                @foreach($venda->itens as $item)
                    <div class="py-3 flex justify-between items-start">
                        <div class="flex-1">
                            <div class="font-medium text-gray-900 dark:text-white">{{ $item->produto->nome }}</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">
                                {{ $item->quantidade }} × R$ {{ number_format($item->preco_unitario, 2, ',', '.') }}
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="font-medium text-gray-900 dark:text-white">R$ {{ number_format($item->total, 2, ',', '.') }}</div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div class="border-t border-gray-200 dark:border-gray-700 pt-6 mt-6">
        <div class="flex justify-end">
            <table class="w-64">
                <tbody class="space-y-2">
                    <tr>
                        <td class="text-right text-gray-600 dark:text-gray-400">Subtotal:</td>
                        <td class="text-right font-medium">R$ {{ number_format($venda->subtotal, 2, ',', '.') }}</td>
                    </tr>
                    @if($venda->desconto > 0)
                    <tr>
                        <td class="text-right text-gray-600 dark:text-gray-400">Desconto:</td>
                        <td class="text-right font-medium text-red-600">- R$ {{ number_format($venda->desconto, 2, ',', '.') }}</td>
                    </tr>
                    @endif
                    <tr class="border-t border-gray-200 dark:border-gray-700 pt-2">
                        <td class="text-right text-lg font-bold text-gray-900 dark:text-white">TOTAL:</td>
                        <td class="text-right text-2xl font-bold text-zeno-forest">R$ {{ number_format($venda->total, 2, ',', '.') }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="border-t border-gray-200 dark:border-gray-700 pt-4 flex justify-end gap-3 mt-4">
        @if($venda->status_pagamento === 'pendente')
            <form action="{{ route('vendas.cancelar', $venda) }}" method="POST">
                @csrf
                <button type="submit" class="px-4 py-2 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700">
                    Cancelar Venda
                </button>
            </form>
            <form action="{{ route('vendas.finalizar', $venda) }}" method="POST">
                @csrf
                <button type="submit" class="bg-zeno-forest text-white px-4 py-2 rounded-xl hover:bg-[#075F44] transition-colors">
                    Finalizar
                </button>
            </form>
        @else
            <a href="{{ route('vendas.index') }}" class="px-4 py-2 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700">
                Voltar às Vendas
            </a>
        @endif
        <a href="{{ route('vendas.create') }}" class="bg-zeno-copper text-white px-4 py-2 rounded-xl hover:bg-[#B79940] transition-colors">
            Nova Venda
        </a>
    </div>
</div>
@endsection