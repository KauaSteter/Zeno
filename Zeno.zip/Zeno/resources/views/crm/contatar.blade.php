@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Detalhes da Prospecção</h1>

    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-medium text-gray-900">{{ $cliente->nome }}</h2>
            <p class="text-sm text-gray-500">{{ $cliente->cpf_cnpj }}</p>
        </div>

        @if(session('success'))
            <div class="bg-green-100 border border-green-200 text-green-800 px-6 py-3 rounded">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="bg-red-100 border border-red-200 text-red-800 px-6 py-3 rounded">
                <strong class="font-bold">Ops! Há erros.</strong>
                <ul class="mt-1 list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('crm.prospeccao.update', $cliente->id) }}" method="POST" class="px-6 py-4">
            @method('PATCH')
            @csrf
            <div class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                        <select name="status" id="status" required class="mt-1 block w-full">
                            <option value="novo" {{ old('status', $prospeccaoExistente->status ?? 'novo') == 'novo' ? 'selected' : '' }}>Novo</option>
                            <option value="em_contato" {{ old('status', $prospeccaoExistente->status ?? '') == 'em_contato' ? 'selected' : '' }}>Em contato</option>
                            <option value="qualificado" {{ old('status', $prospeccaoExistente->status ?? '') == 'qualificado' ? 'selected' : '' }}>Qualificado</option>
                            <option value="fechado" {{ old('status', $prospeccaoExistente->status ?? '') == 'fechado' ? 'selected' : '' }}>Fechado</option>
                            <option value="recusado" {{ old('status', $prospeccaoExistente->status ?? '') == 'recusado' ? 'selected' : '' }}>Recusado</option>
                        </select>
                    </div>

                    <div>
                        <label for="canal_contato" class="block text-sm font-medium text-gray-700">Canal de Contato</label>
                        <select name="canal_contato" id="canal_contato" class="mt-1 block w-full">
                            <option value="">-- Não aplicável --</option>
                            <option value="email" {{ old('canal_contato', $prospeccaoExistente->canal_contato ?? '') == 'email' ? 'selected' : '' }}>E-mail</option>
                            <option value="telefone" {{ old('canal_contato', $prospeccaoExistente->canal_contato ?? '') == 'telefone' ? 'selected' : '' }}>Telefone</option>
                            <option value="whatsapp" {{ old('canal_contato', $prospeccaoExistente->canal_contato ?? '') == 'whatsapp' ? 'selected' : '' }}>WhatsApp</option>
                            <option value="visita" {{ old('canal_contato', $prospeccaoExistente->canal_contato ?? '') == 'visita' ? 'selected' : '' }}>Visita</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="proxima_acao" class="block text-sm font-medium text-gray-700">Próxima Ação</label>
                    <input type="text" name="proxima_acao" id="proxima_acao" value="{{ old('proxima_acao', $prospeccaoExistente->proxima_acao ?? '') }}"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label for="data_acao" class="block text-sm font-medium text-gray-700">Data da Próxima Ação</label>
                    <input type="date" name="data_acao" id="data_acao" value="{{ old('data_acao', optional($prospeccaoExistente)->data_acao ? $prospeccaoExistente->data_acao->format('Y-m-d') : '' }}"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label for="observacoes" class="block text-sm font-medium text-gray-700">Observações</label>
                    <textarea name="observacoes" id="observacoes" rows="3"
                              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">{{ old('observacoes', $prospeccaoExistente->observacoes ?? '') }}</textarea>
                </div>

                <div class="flex justify-end space-x-3 pt-4">
                    <a href="{{ route('crm.index') }}" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                        Voltar
                    </a>
                    <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Salvar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection