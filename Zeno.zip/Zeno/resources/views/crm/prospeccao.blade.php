@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Nova Prospecção</h1>

    @if($errors->any())
        <div class="bg-red-100 border border-red-200 text-red-800 px-4 py-3 rounded mb-4">
            <strong class="font-bold">Ops! Há erros.</strong>
            <ul class="mt-1 list-disc list-inside text-sm">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('crm.prospeccao.store') }}" method="POST">
        @csrf
        <div class="space-y-6 bg-white p-6 rounded-lg shadow">
            <div>
                <label for="cliente_id" class="block text-sm font-medium text-gray-700">Cliente *</label>
                <select name="cliente_id" id="cliente_id" required class="mt-1 block w-full">
                    <option value="">Selecione um cliente</option>
                    @foreach($clientes as $cliente)
                        <option value="{{ $cliente->id }}">{{ $cliente->nome }} ({{ $cliente->cpf_cnpj }})</option>
                    @endforeach
                </select>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">Status *</label>
                    <select name="status" id="status" required class="mt-1 block w-full">
                        <option value="novo">Novo</option>
                        <option value="em_contato">Em contato</option>
                        <option value="qualificado">Qualificado</option>
                        <option value="fechado">Fechado</option>
                        <option value="recusado">Recusado</option>
                    </select>
                </div>

                <div>
                    <label for="canal_contato" class="block text-sm font-medium text-gray-700">Canal de Contato</label>
                    <select name="canal_contato" id="canal_contato" class="mt-1 block w-full">
                        <option value="">-- Não aplicável --</option>
                        <option value="email">E-mail</option>
                        <option value="telefone">Telefone</option>
                        <option value="whatsapp">WhatsApp</option>
                        <option value="visita">Visita</option>
                    </select>
                </div>
            </div>

            <div>
                <label for="proxima_acao" class="block text-sm font-medium text-gray-700">Próxima Ação</label>
                <input type="text" name="proxima_acao" id="proxima_acao" maxlength="200"
                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
            </div>

            <div>
                <label for="data_acao" class="block text-sm font-medium text-gray-700">Data da Próxima Ação</label>
                <input type="date" name="data_acao" id="data_acao"
                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
            </div>

            <div>
                <label for="observacoes" class="block text-sm font-medium text-gray-700">Observações</label>
                <textarea name="observacoes" id="observacoes" rows="3"
                          class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="{{ route('crm.index') }}" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                    Cancelar
                </a>
                <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                    Salvar Prospecção
                </button>
            </div>
        </div>
    </form>
</div>
@endsection