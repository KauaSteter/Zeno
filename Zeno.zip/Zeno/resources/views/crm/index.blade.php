@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">CRM - Prospecção de Clientes</h1>

    @if(session('success'))
        <div class="bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
        <div class="flex justify-between items-center mb-4">
            <a href="{{ route('crm.prospeccao') }}" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                <svg class="-ml-1 mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Nova Prospecção
            </a>

            <div class="flex space-x-2">
                @foreach(['novo', 'em_contato', 'qualificado', 'fechado', 'recusado'] as $s)
                    <a href="{{ route('crm.index', ['status' => $s]) }}" class="text-sm text-gray-600 hover:text-gray-900">
                        {{ ucfirst(str_replace('_', ' ', $s)) }}
                    </a>
                @endforeach
            </div>
        </div>

        @if($prospeccoes->count())
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Canal</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Próxima Ação</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($prospeccoes as $p)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {{ $p->cliente_nome }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                {{ $p->status === 'novo' ? 'bg-blue-100 text-blue-800' : 
                                ($p->status === 'em_contato' ? 'bg-yellow-100 text-yellow-800' : 
                                ($p->status === 'qualificado' ? 'bg-green-100 text-green-800' : 
                                ($p->status === 'fechado' ? 'bg-gray-100 text-gray-800' : 
                                'bg-red-100 text-red-800'))) }}">
                                {{ ucfirst(str_replace('_', ' ', $p->status)) }}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {{ $p->canal_contato ?? '-' }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {{ $p->proxima_acao ?? '-' }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <a href="{{ route('crm.prospeccao.contatar', $p->cliente_id) }}" class="text-indigo-600 hover:text-indigo-900">
                                Detalhes
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

            <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200">
                {{ $prospeccoes->links() }}
            </div>
        @else
            <div class="text-center py-12">
                <p class="text-gray-500">Nenhuma prospecção encontrada.</p>
            </div>
        @endif
    </div>
</div>
@endsection