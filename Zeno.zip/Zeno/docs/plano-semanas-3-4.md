# Plano técnico — Semanas 3 e 4 do ZENO ERP

## Objetivo
Implementar fornecedores/compras, movimentação de estoque, PDV e margem de lucro sem alterar o Supabase até a revisão e aprovação do schema real. Trabalhar somente na branch `develop`.

## Estado e bloqueios locais confirmados
- O clone ativo está em `C:/Users/Manoel/Documents/Zeno`, branch `develop`, HEAD `6d1d3de`.
- `.env.localtest` contém APP_KEY e caminho SQLite absoluto de outra instalação Windows. Não ler `.env.supabase-backup`, não copiar segredos e não executar configurações de produção.
- O ambiente do agente (bash) não encontra `php`, `composer` ou `docker`; `where.exe` também não localizou esses executáveis. PHPUnit/Docker não podem ser executados por este ambiente neste momento.
- O Dockerfile existente é de produção (`composer install --no-dev`), não é ambiente de desenvolvimento/testes sem adaptações.
- `docs/01_schema_supabase.sql` é schema documentado, não prova do banco implantado.
- Documentação define produtos com `custo_compra`, `margem_lucro`, `preco_venda`; código/migration atual usa `preco_custo`. Produtos do schema documentado não têm `preco_custo`.
- Não existem migrations Laravel para fornecedores, compras, vendas, itens ou movimentações de estoque. A migration base é histórica; não alterá-la nem executá-la na base existente.
- Schema documenta `compras_itens` e `vendas_itens`; explicitar tabelas em models se estes nomes forem confirmados.
- IDs de usuários são UUID; chaves estrangeiras devem manter UUID, não bigint `foreignId()`.

## Ambiente local recomendado
Preparar Docker Compose de desenvolvimento isolado: PostgreSQL descartável (nunca Supabase), serviço PHP/Composer de desenvolvimento e aplicação Laravel. Neste perfil, Docker/PHP/Composer não estão acessíveis ao agente. Quando o usuário validar disponibilidade no terminal Windows, podemos subir os serviços. O Compose deve usar DB novo e descartável, sem montar `.env` real nem reutilizar volumes produtivos.

Testes automatizados: SQLite em memória via `php artisan test` com migrations de teste; teste adicional de integração PostgreSQL descartável após aprovar schema/fixtures. Nunca declarar teste aprovado sem executar.

## Sequência vertical
1. Comparar schema live de homologação em modo somente leitura, tabela `migrations`, `docs/01_schema_supabase.sql`, models e migrations; sem exibir credenciais.
2. Documentar diferenças campo a campo; decidir canônicos para `custo_compra` vs `preco_custo`, `unidade_medida` vs `unidade`, tabelas de itens/pagamentos, cancelamento/estorno e ledger de estoque.
3. Especificar migration aditiva e testes. Revisar manualmente antes de qualquer alteração no LXC/Supabase.
4. Implementar CRUD fornecedor com teste RED/GREEN.
5. Implementar compras: estoque entra ao receber, não ao criar pedido; recebimento parcial e repetido idempotente; movimento registra tipo, quantidade, saldo, origem, usuário; transação atômica.
6. Implementar PDV: busca SKU/nome, carrinho de interface; servidor recalcula preço e total, valida ativo/estoque; venda+itens+movimentos+baixa em transação, bloqueio para concorrência, número único; erro deve reverter tudo. Definir pagamento, cliente e cancelamento antes.
7. Margem: fórmula possível sobre custo = `(venda-custo)/custo*100`; margem sobre venda = `(venda-custo)/venda*100`. Confirmar qual é a regra de negócio e custo zero antes de persistir/exibir.
8. Executar PHPUnit em SQLite e integração em Postgres descartável; revisão migration; commit apenas em `develop`. Não migrar main nem fazer deploy LXC sem pedido explícito.

## Segurança
- Nunca ler `.env.supabase-backup` nem inserir credenciais em compose/testes/logs.
- Nunca conectar testes ao Supabase; nenhum `migrate` live durante descoberta.
- Não remover nem modificar migrations históricas para contornar testes.
- Se runtime indisponível, informar bloqueio e não alegar validação.
