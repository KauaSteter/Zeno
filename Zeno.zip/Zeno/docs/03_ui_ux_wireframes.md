
# UI/UX - SISTEMA ERP
# Design de Interface e Wireframes
# ===========================================

## 1. DESIGN SYSTEM

### Cores Principais
- Primária: #2563EB (Azul profissional)
- Secundária: #059669 (Verde financeiro)
- Neutro: #F9FAFB (Background)
- Neutro Escuro: #374151 (Texto)
- Perigo: #DC2626 (Vermelho alerta)
- Sucesso: #10B981 (Verde confirmação)
- Aviso: #F59E0B (Amarelo atenção)

### Tipografia
- Font Family: 'Inter', -apple-system, sans-serif
- Títulos: 24px/32px (600)
- Subtítulos: 18px/28px (600)
- Corpo: 14px/20px (400)
- Small: 12px/16px (400)

### Espaçamentos
- Base: 4px (unidade)
- Container: 24px padding
- Card: 16px padding
- Botão: 12px 20px
- Input: 10px 14px

### Componentes
- Botões: 8px border-radius, hover effects
- Cards: 12px border-radius, shadow-sm
- Inputs: 6px border-radius, focus ring
- Tabelas: zebra striping, hover highlight
- Alertas: ícone + texto, auto-hide

## 2. WIREFRAMES PRINCIPAIS

### 2.1 DASHBOARD (Primeira tela após login)
```
┌─────────────────────────────────────────────────────────────┐
│ ⚙️ Manoel Silva                 📊 Dashboard                │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Hoje        │ │ Mês         │ │ Pendentes   │ │ Estoque │ │
│ │ R$ 2.450,00 │ │ R$ 18.900,00│ │ 12 clientes │ │ 45 itens│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
│                                                              │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ 📈 Vendas dos últimos 7 dias                             │ │
│ │ ┌────────────────────────────────────────────────────┐   │ │
│ │ │ ████████████████████████████                       │   │ │
│ │ │ ████████████████████████████████████               │   │ │
│ │ │ ████████████████████████████████████████████       │   │ │
│ │ └────────────────────────────────────────────────────┘   │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                              │
│ ┌─────────────────────────┐ ┌─────────────────────────────┐ │
│ │ ⚡ Ações Rápidas         │ │ 📦 Produtos baixo estoque   │ │
│ │ • Nova Venda            │ │ • Produto A (2 unidades)    │ │
│ │ • Nova OS               │ │ • Produto B (5 unidades)    │ │
│ │ • Cadastrar Produto     │ │ • Produto C (3 unidades)    │ │
│ │ • Cadastrar Cliente     │ │ └───────────────────────────┘ │
│ └─────────────────────────┘ └─────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 PDV (VENDAS)
```
┌─────────────────────────────────────────────────────────────┐
│ 🛒 PDV - Nova Venda                   F4: Finalizar         │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────┐ ┌─────────────────────┐ │
│ │ Buscar Produto: ___________ 🔍  │ │ Cliente: __________ │ │
│ │                                 │ │ CPF: ______________ │ │
│ │ ┌─────────────────────────────┐ │ │ Forma Pagto: [▽]   │ │
│ │ │ █ Produto A    R$ 89,90     │ │ │ Desc: R$ ______    │ │
│ │ │ █ Produto B    R$ 129,00    │ │ │ Total: R$ 1.458,90 │ │
│ │ │ █ Produto C    R$ 34,50     │ │ │                     │ │
│ │ │                               │ │ │ [ FINALIZAR VENDA ]│ │
│ │ │ Quantidade: [1] [ + ] [ - ]  │ │ └─────────────────────┘ │
│ │ │ Total Item: R$ 89,90         │ │                         │
│ │ │ [ Adicionar ] [ Remover ]    │ │                         │
│ │ └─────────────────────────────┘ │ │                         │
│ └─────────────────────────────────┘ └─────────────────────┘ │
│                                                              │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ ITENS DA VENDA                                          │ │
│ │ ┌──────────────────────────────────────────────────────┐ │ │
│ │ │ Produto   Qtd   Unitário   Total                     │ │ │
│ │ │ Produto A   2    R$ 89,90   R$ 179,80                │ │ │
│ │ │ Produto B   1    R$129,00   R$ 129,00                │ │ │
│ │ │ Produto C   3    R$ 34,50   R$ 103,50                │ │ │
│ │ │ DESCONTO             -       R$ 50,00                │ │ │
│ │ │ TOTAL                        R$ 362,30               │ │ │
│ │ └──────────────────────────────────────────────────────┘ │ │
│ └──────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### 2.3 ORDEM DE SERVIÇO
```
┌─────────────────────────────────────────────────────────────┐
│ 🔧 Nova Ordem de Serviço              [ Calcular Total ]    │
├─────────────────────────────────────────────────────────────┤
│ Cliente: João Silva (11.111.111/0001-11)                    │
│ Título: Reparo Notebook Dell                               │
│ Descrição Problema: _______________________________________ │
│                                                              │
│ ┌─────────────────────────────────┐ ┌─────────────────────┐ │
│ │ SERVICOS                        │ │ PRODUTOS UTILIZADOS │ │
│ │ + Adicionar Serviço             │ │ + Adicionar Produto │ │
│ │ ┌─────────────────────────────┐ │ │ ┌─────────────────┐ │ │
│ │ │ █ Formatação Windows        │ │ │ │ █ Teclado USB   │ │ │
│ │ │   2h × R$ 80,00 = R$ 160,00 │ │ │ │   1 × R$ 89,90  │ │ │
│ │ │                               │ │ │ └─────────────────┘ │ │
│ │ │ █ Backup Dados               │ │ │                     │ │
│ │ │   1h × R$ 80,00 = R$ 80,00   │ │ │                     │ │
│ │ └─────────────────────────────┘ │ │ └─────────────────────┘ │
│ │ Total Serviços: R$ 240,00       │ │ Total Produtos: R$ 89,90│ │
│ └─────────────────────────────────┘ └─────────────────────┘ │
│                                                              │
│ Descrição Solução: _________________________________________ │
│ Desconto: R$ ______  Status: [Aberta]  Prioridade: [Normal] │
│                                                              │
│ RESUMO:                                                      │
│ Serviços: R$ 240,00  Produtos: R$ 89,90  Desconto: R$ 0,00  │
│ TOTAL: R$ 329,90                                             │
│                                                              │
│ [ Salvar Rascunho ] [ Emitir NFSe ] [ Finalizar OS ]        │
└─────────────────────────────────────────────────────────────┘
```

### 2.4 ESTOQUE / PRODUTOS
```
┌─────────────────────────────────────────────────────────────┐
│ 📦 Produtos                     [ + Novo ] [ Exportar CSV ] │
├─────────────────────────────────────────────────────────────┤
│ Filtros: [Todos] [Ativos] [Inativos] [Baixo Estoque] 🔍     │
│                                                              │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ SKU       Nome               Estoque   Custo   Venda    │ │
│ │ ──────────────────────────────────────────────────────── │ │
│ │ █ P001    Notebook Dell          12    R$ 2.800  R$ 3.490│ │
│ │   • Categoria: Eletrônicos                               │ │
│ │   • NCM: 8471.30.00                                      │ │
│ │   [ Editar ] [ Sinc. ML ] [ Ver Movimentações ]          │ │
│ │                                                           │ │
│ │ █ P002    Teclado USB            45    R$ 45,00  R$ 89,90│ │
│ │   • Categoria: Acessórios                                │ │
│ │   • Estoque mínimo: 10                                   │ │
│ │   [ Editar ] [ Sinc. ML ] [ Ver Movimentações ]          │ │
│ │                                                           │ │
│ │ █ P003    Mouse Gamer             5    R$ 60,00  R$ 119,0│ │
│ │   • Categoria: Acessórios  ⚠️ BAIXO ESTOQUE            │ │
│ │   [ Editar ] [ Sinc. ML ] [ Ajustar Estoque ]            │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                              │
│ Paginação: ◀ 1 2 3 4 5 ▶          Mostrando 1-10 de 156     │
└─────────────────────────────────────────────────────────────┘
```

### 2.5 MERCADO LIVRE
```
┌─────────────────────────────────────────────────────────────┐
│ 🛒 Integração Mercado Livre        [ Sincronizar Agora ]    │
├─────────────────────────────────────────────────────────────┤
│ Status: ✅ Conectado (Conta: João Tech)                    │
│ Última sincronização: Hoje 14:30                            │
│                                                              │
│ ┌─────────────────────────────────┐ ┌─────────────────────┐ │
│ │ CONFIGURAÇÃO                    │ │ ESTATÍSTICAS        │ │
│ │ [ ] Sincronizar estoque         │ │ • Produtos ativos: 45│ │
│ │ [x] Sincronizar preços          │ │ • Vendas hoje: 8    │ │
│ │ Markup adicional: [15] %        │ │ • Pedidos novos: 3  │ │
│ │                                 │ │ • Rating: 4.8 ★     │ │
│ │ Token expira em: 7 dias         │ │                     │ │
│ │ [ Renovar Token ]               │ │                     │ │
│ └─────────────────────────────────┘ └─────────────────────┘ │
│                                                              │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ PEDIDOS RECENTES                                        │ │
│ │ ┌──────────────────────────────────────────────────────┐ │ │
│ │ │ #123456 - Notebook Dell - R$ 3.490 - Status: Pago    │ │ │
│ │ │   Cliente: Maria Santos - [ Processar ] [ Detalhes ] │ │ │
│ │ │                                                      │ │ │
│ │ │ #123457 - Teclado USB - R$ 89,90 - Status: Enviado   │ │ │
│ │ │   Cliente: Carlos Silva - [ Rastrear ] [ Detalhes ]  │ │ │
│ │ └──────────────────────────────────────────────────────┘ │ │
│ └──────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### 2.6 NOTA FISCAL
```
┌─────────────────────────────────────────────────────────────┐
│ 🧾 Emissão de Nota Fiscal           [NF-e] [NFS-e]          │
├─────────────────────────────────────────────────────────────┤
│ Venda #1234 - João Silva - R$ 362,30 - 24/10/2026          │
│                                                              │
│ DADOS DO CLIENTE (pré-preenchido)                           │
│ • Nome: João Silva                                          │
│ • CPF: 123.456.789-00                                       │
│ • Endereço: Rua A, 123 - Centro                             │
│ • Cidade: São Paulo - SP                                    │
│                                                              │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ ITENS DA NOTA                                            │ │
│ │ ┌──────────────────────────────────────────────────────┐ │ │
│ │ │ Produto           Qtd   Unitário   Total   CFOP      │ │ │
│ │ │ Notebook Dell      1    R$ 3.490   R$ 3.490  5102    │ │ │
│ │ │ Teclado USB        1    R$ 89,90   R$ 89,90  5102    │ │ │
│ │ └──────────────────────────────────────────────────────┘ │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                              │
│ INFORMAÇÕES ADICIONAIS                                      │
│ • Natureza Operação: Venda de mercadoria                    │
│ • Forma Pagto: Dinheiro                                     │
│ • Ambiente: [ ] Homologação [x] Produção                    │
│                                                              │
│ [ Visualizar XML ] [ Testar Envio ] [ Emitir Nota ]        │
│                                                              │
│ HISTÓRICO:                                                  │
│ • 24/10 14:30 - XML gerado                                  │
│ • 24/10 14:31 - Enviado para SEFAZ                         │
│ • 24/10 14:32 - Autorizada (Protocolo: 123456789)          │
│ • 24/10 14:33 - PDF gerado [Download]                      │
└─────────────────────────────────────────────────────────────┘
```

## 3. COMPONENTES REUTILIZÁVEIS

### 3.1 CARD DE RESUMO
```html
<div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
  <div class="flex items-center justify-between mb-4">
    <h3 class="text-lg font-semibold text-gray-800">Vendas Hoje</h3>
    <span class="text-sm text-gray-500">24/10/2026</span>
  </div>
  <div class="text-3xl font-bold text-blue-600 mb-2">R$ 2.450,00</div>
  <div class="flex items-center text-sm">
    <span class="text-green-600 flex items-center">
      <svg>↑</svg> 12% em relação a ontem
    </span>
  </div>
</div>
```

### 3.2 BOTÃO COM AÇÃO
```html
<button class="bg-blue-600 hover:bg-blue-700 text-white font-medium 
               py-2 px-4 rounded-lg transition-colors duration-200 
               flex items-center gap-2">
  <svg>+</svg>
  Nova Venda
</button>
```

### 3.3 TABELA RESPONSIVA
```html
<div class="overflow-x-auto border border-gray-200 rounded-lg">
  <table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
      <tr>
        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estoque</th>
      </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
      <tr class="hover:bg-gray-50 transition-colors">
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">P001</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Notebook Dell</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm">
          <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">12</span>
        </td>
      </tr>
    </tbody>
  </table>
</div>
```

### 3.4 ALERTA DE ESTOQUE BAIXO
```html
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-4">
  <div class="flex">
    <div class="flex-shrink-0">
      <svg class="h-5 w-5 text-yellow-400">⚠️</svg>
    </div>
    <div class="ml-3">
      <p class="text-sm text-yellow-700">
        <strong>Atenção:</strong> Produto "Mouse Gamer" está com estoque baixo (5 unidades).
      </p>
    </div>
  </div>
</div>
```

## 4. RESPONSIVIDADE

### Mobile (Breakpoint < 768px)
- Sidebar vira menu hamburger
- Cards empilhados verticalmente
- Tabelas com scroll horizontal
- Botões com ícones apenas
- Formulários em coluna única

### Tablet (768px - 1024px)
- Sidebar colapsável
- Grid 2 colunas no dashboard
- Formulários em duas colunas quando possível
- Modais em tela cheia

## 5. FLUXOS DE USUÁRIO

### Fluxo 1: Nova Venda
1. Dashboard → Botão "Nova Venda"
2. PDV → Buscar produto → Adicionar ao carrinho
3. Selecionar cliente → Aplicar desconto (opcional)
4. Escolher forma de pagamento → Finalizar
5. Emitir NF-e (opcional) → Retornar ao dashboard

### Fluxo 2: Nova Ordem de Serviço
1. Serviços → "Nova OS"
2. Selecionar cliente → Descrever problema
3. Adicionar serviços (catálogo ou custom)
4. Adicionar produtos utilizados
5. Calcular total automático → Salvar
6. Emitir NFSe (quando concluído)

### Fluxo 3: Sincronização Mercado Livre
1. Mercado Livre → Configurar conexão
2. Produtos → Selecionar produtos para sincronizar
3. Configurar markup → Habilitar sincronização automática
4. Sistema sincroniza estoque e preços a cada 30min
5. Pedidos do ML aparecem automaticamente em "Vendas"

## 6. ACESSIBILIDADE

- Contrastes WCAG AA (4.5:1 mínimo)
- Navegação por teclado (Tab, Enter, Esc)
- Aria-labels para ícones
- Tamanho de fonte ajustável
- Foco visível em elementos interativos
- Texto alternativo para imagens
