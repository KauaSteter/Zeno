
-- ============================================
-- SCHEMA SUPABASE - SISTEMA ERP
-- Database: PostgreSQL 15+
-- ============================================

-- EXTENSÕES
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- TABELA: users (usuários do sistema)
-- ============================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    role VARCHAR(50) NOT NULL DEFAULT 'vendedor', -- admin, gerente, vendedor, financeiro
    ativo BOOLEAN DEFAULT true,
    ultimo_acesso TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ============================================
-- TABELA: clientes
-- ============================================
CREATE TABLE clientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo VARCHAR(20) NOT NULL, -- 'PF' ou 'PJ'
    nome VARCHAR(255) NOT NULL,
    razao_social VARCHAR(255), -- apenas PJ
    cpf_cnpj VARCHAR(18) UNIQUE NOT NULL,
    ie VARCHAR(20), -- inscrição estadual
    email VARCHAR(255),
    telefone VARCHAR(20),
    celular VARCHAR(20),
    
    -- Endereço
    cep VARCHAR(9),
    endereco VARCHAR(255),
    numero VARCHAR(10),
    complemento VARCHAR(100),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    
    -- Controle de crédito
    limite_credito DECIMAL(15,2) DEFAULT 0.00,
    credito_utilizado DECIMAL(15,2) DEFAULT 0.00,
    credito_disponivel DECIMAL(15,2) GENERATED ALWAYS AS (limite_credito - credito_utilizado) STORED,
    
    -- Dados adicionais
    observacoes TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_clientes_cpf_cnpj ON clientes(cpf_cnpj);
CREATE INDEX idx_clientes_nome ON clientes(nome);
CREATE INDEX idx_clientes_tipo ON clientes(tipo);

-- ============================================
-- TABELA: categorias_produto
-- ============================================
CREATE TABLE categorias_produto (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- TABELA: produtos
-- ============================================
CREATE TABLE produtos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    categoria_id UUID REFERENCES categorias_produto(id) ON DELETE SET NULL,
    
    -- Identificação
    sku VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    
    -- Estoque
    estoque_atual INTEGER DEFAULT 0,
    estoque_minimo INTEGER DEFAULT 0,
    estoque_maximo INTEGER,
    unidade_medida VARCHAR(10) DEFAULT 'UN', -- UN, KG, LT, MT, etc
    
    -- Precificação
    custo_compra DECIMAL(15,2) DEFAULT 0.00,
    margem_lucro DECIMAL(5,2) DEFAULT 0.00, -- percentual
    preco_venda DECIMAL(15,2) NOT NULL,
    preco_promocional DECIMAL(15,2),
    
    -- Fiscal
    ncm VARCHAR(8), -- Nomenclatura Comum do Mercosul
    cest VARCHAR(7),
    cfop VARCHAR(4) DEFAULT '5102',
    
    -- Integração Mercado Livre
    ml_id VARCHAR(50), -- ID do produto no ML
    ml_sincronizado BOOLEAN DEFAULT false,
    ml_ultima_sync TIMESTAMP,
    
    -- Imagens
    imagem_principal TEXT, -- URL da imagem
    imagens_adicionais JSONB, -- array de URLs
    
    -- Status
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_produtos_sku ON produtos(sku);
CREATE INDEX idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX idx_produtos_ml_id ON produtos(ml_id);

-- ============================================
-- TABELA: servicos
-- ============================================
CREATE TABLE servicos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    
    -- Precificação
    custo_hora DECIMAL(15,2) DEFAULT 0.00,
    margem_lucro DECIMAL(5,2) DEFAULT 0.00,
    preco_hora DECIMAL(15,2) NOT NULL,
    tempo_estimado_horas DECIMAL(5,2), -- tempo padrão em horas
    
    -- Fiscal
    codigo_servico VARCHAR(10), -- código do serviço municipal
    aliquota_iss DECIMAL(5,2) DEFAULT 0.00,
    
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_servicos_codigo ON servicos(codigo);

-- ============================================
-- TABELA: fornecedores
-- ============================================
CREATE TABLE fornecedores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo VARCHAR(20) NOT NULL, -- 'PF' ou 'PJ'
    nome VARCHAR(255) NOT NULL,
    razao_social VARCHAR(255),
    cpf_cnpj VARCHAR(18) UNIQUE NOT NULL,
    ie VARCHAR(20),
    email VARCHAR(255),
    telefone VARCHAR(20),
    
    -- Endereço
    cep VARCHAR(9),
    endereco VARCHAR(255),
    numero VARCHAR(10),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    
    observacoes TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_fornecedores_cpf_cnpj ON fornecedores(cpf_cnpj);

-- ============================================
-- TABELA: compras
-- ============================================
CREATE TABLE compras (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_compra VARCHAR(20) UNIQUE NOT NULL,
    fornecedor_id UUID REFERENCES fornecedores(id) ON DELETE RESTRICT,
    usuario_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    data_compra DATE NOT NULL,
    data_entrega_prevista DATE,
    data_entrega_real DATE,
    
    -- Valores
    subtotal DECIMAL(15,2) DEFAULT 0.00,
    desconto DECIMAL(15,2) DEFAULT 0.00,
    frete DECIMAL(15,2) DEFAULT 0.00,
    outras_despesas DECIMAL(15,2) DEFAULT 0.00,
    total DECIMAL(15,2) NOT NULL,
    
    -- Status
    status VARCHAR(50) DEFAULT 'pendente', -- pendente, recebido_parcial, recebido, cancelado
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_compras_fornecedor ON compras(fornecedor_id);
CREATE INDEX idx_compras_data ON compras(data_compra);
CREATE INDEX idx_compras_status ON compras(status);

-- ============================================
-- TABELA: compras_itens
-- ============================================
CREATE TABLE compras_itens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    compra_id UUID REFERENCES compras(id) ON DELETE CASCADE,
    produto_id UUID REFERENCES produtos(id) ON DELETE RESTRICT,
    
    quantidade INTEGER NOT NULL,
    quantidade_recebida INTEGER DEFAULT 0,
    custo_unitario DECIMAL(15,2) NOT NULL,
    desconto DECIMAL(15,2) DEFAULT 0.00,
    total DECIMAL(15,2) NOT NULL,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_compras_itens_compra ON compras_itens(compra_id);
CREATE INDEX idx_compras_itens_produto ON compras_itens(produto_id);

-- ============================================
-- TABELA: vendas
-- ============================================
CREATE TABLE vendas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_venda VARCHAR(20) UNIQUE NOT NULL,
    cliente_id UUID REFERENCES clientes(id) ON DELETE RESTRICT,
    usuario_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    data_venda TIMESTAMP NOT NULL DEFAULT NOW(),
    
    -- Valores
    subtotal DECIMAL(15,2) DEFAULT 0.00,
    desconto DECIMAL(15,2) DEFAULT 0.00,
    frete DECIMAL(15,2) DEFAULT 0.00,
    total DECIMAL(15,2) NOT NULL,
    
    -- Pagamento
    forma_pagamento VARCHAR(50), -- dinheiro, credito, debito, pix, boleto
    status_pagamento VARCHAR(50) DEFAULT 'pendente', -- pendente, pago, parcial, cancelado
    
    -- Nota Fiscal
    nfe_emitida BOOLEAN DEFAULT false,
    nfe_numero VARCHAR(20),
    nfe_chave VARCHAR(44),
    nfe_xml TEXT,
    
    -- Integração ML
    ml_order_id VARCHAR(50),
    origem VARCHAR(20) DEFAULT 'loja', -- loja, mercadolivre, site
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_vendas_cliente ON vendas(cliente_id);
CREATE INDEX idx_vendas_data ON vendas(data_venda);
CREATE INDEX idx_vendas_status ON vendas(status_pagamento);
CREATE INDEX idx_vendas_ml_order ON vendas(ml_order_id);

-- ============================================
-- TABELA: vendas_itens
-- ============================================
CREATE TABLE vendas_itens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    venda_id UUID REFERENCES vendas(id) ON DELETE CASCADE,
    produto_id UUID REFERENCES produtos(id) ON DELETE RESTRICT,
    
    quantidade INTEGER NOT NULL,
    preco_unitario DECIMAL(15,2) NOT NULL,
    desconto DECIMAL(15,2) DEFAULT 0.00,
    total DECIMAL(15,2) NOT NULL,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_vendas_itens_venda ON vendas_itens(venda_id);
CREATE INDEX idx_vendas_itens_produto ON vendas_itens(produto_id);

-- ============================================
-- TABELA: ordens_servico
-- ============================================
CREATE TABLE ordens_servico (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_os VARCHAR(20) UNIQUE NOT NULL,
    cliente_id UUID REFERENCES clientes(id) ON DELETE RESTRICT,
    usuario_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    data_abertura TIMESTAMP NOT NULL DEFAULT NOW(),
    data_previsao DATE,
    data_conclusao TIMESTAMP,
    
    -- Descrição
    titulo VARCHAR(255) NOT NULL,
    descricao_problema TEXT,
    descricao_solucao TEXT,
    
    -- Valores
    total_servicos DECIMAL(15,2) DEFAULT 0.00,
    total_produtos DECIMAL(15,2) DEFAULT 0.00,
    desconto DECIMAL(15,2) DEFAULT 0.00,
    total DECIMAL(15,2) NOT NULL,
    
    -- Status
    status VARCHAR(50) DEFAULT 'aberta', -- aberta, em_andamento, aguardando_aprovacao, concluida, cancelada
    prioridade VARCHAR(20) DEFAULT 'normal', -- baixa, normal, alta, urgente
    
    -- Nota Fiscal
    nfse_emitida BOOLEAN DEFAULT false,
    nfse_numero VARCHAR(20),
    nfse_codigo_verificacao VARCHAR(20),
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_os_cliente ON ordens_servico(cliente_id);
CREATE INDEX idx_os_status ON ordens_servico(status);
CREATE INDEX idx_os_data ON ordens_servico(data_abertura);

-- ============================================
-- TABELA: os_servicos (serviços da OS)
-- ============================================
CREATE TABLE os_servicos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    os_id UUID REFERENCES ordens_servico(id) ON DELETE CASCADE,
    servico_id UUID REFERENCES servicos(id) ON DELETE RESTRICT,
    
    descricao TEXT,
    quantidade_horas DECIMAL(5,2) NOT NULL,
    preco_hora DECIMAL(15,2) NOT NULL,
    total DECIMAL(15,2) NOT NULL,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_os_servicos_os ON os_servicos(os_id);

-- ============================================
-- TABELA: os_produtos (produtos usados na OS)
-- ============================================
CREATE TABLE os_produtos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    os_id UUID REFERENCES ordens_servico(id) ON DELETE CASCADE,
    produto_id UUID REFERENCES produtos(id) ON DELETE RESTRICT,
    
    quantidade INTEGER NOT NULL,
    preco_unitario DECIMAL(15,2) NOT NULL,
    total DECIMAL(15,2) NOT NULL,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_os_produtos_os ON os_produtos(os_id);

-- ============================================
-- TABELA: movimentacoes_estoque
-- ============================================
CREATE TABLE movimentacoes_estoque (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    produto_id UUID REFERENCES produtos(id) ON DELETE CASCADE,
    usuario_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    tipo VARCHAR(20) NOT NULL, -- entrada, saida, ajuste, devolucao
    quantidade INTEGER NOT NULL,
    estoque_anterior INTEGER NOT NULL,
    estoque_atual INTEGER NOT NULL,
    
    -- Referência
    referencia_tipo VARCHAR(50), -- compra, venda, os, ajuste_manual
    referencia_id UUID,
    
    observacao TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_mov_estoque_produto ON movimentacoes_estoque(produto_id);
CREATE INDEX idx_mov_estoque_tipo ON movimentacoes_estoque(tipo);
CREATE INDEX idx_mov_estoque_data ON movimentacoes_estoque(created_at);

-- ============================================
-- TABELA: contas_receber
-- ============================================
CREATE TABLE contas_receber (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cliente_id UUID REFERENCES clientes(id) ON DELETE RESTRICT,
    venda_id UUID REFERENCES vendas(id) ON DELETE SET NULL,
    os_id UUID REFERENCES ordens_servico(id) ON DELETE SET NULL,
    
    descricao VARCHAR(255) NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    valor_pago DECIMAL(15,2) DEFAULT 0.00,
    valor_pendente DECIMAL(15,2) GENERATED ALWAYS AS (valor - valor_pago) STORED,
    
    data_emissao DATE NOT NULL,
    data_vencimento DATE NOT NULL,
    data_pagamento DATE,
    
    status VARCHAR(50) DEFAULT 'pendente', -- pendente, pago, vencido, cancelado
    forma_pagamento VARCHAR(50),
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_contas_receber_cliente ON contas_receber(cliente_id);
CREATE INDEX idx_contas_receber_vencimento ON contas_receber(data_vencimento);
CREATE INDEX idx_contas_receber_status ON contas_receber(status);

-- ============================================
-- TABELA: contas_pagar
-- ============================================
CREATE TABLE contas_pagar (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fornecedor_id UUID REFERENCES fornecedores(id) ON DELETE RESTRICT,
    compra_id UUID REFERENCES compras(id) ON DELETE SET NULL,
    
    descricao VARCHAR(255) NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    valor_pago DECIMAL(15,2) DEFAULT 0.00,
    valor_pendente DECIMAL(15,2) GENERATED ALWAYS AS (valor - valor_pago) STORED,
    
    data_emissao DATE NOT NULL,
    data_vencimento DATE NOT NULL,
    data_pagamento DATE,
    
    status VARCHAR(50) DEFAULT 'pendente', -- pendente, pago, vencido, cancelado
    forma_pagamento VARCHAR(50),
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_contas_pagar_fornecedor ON contas_pagar(fornecedor_id);
CREATE INDEX idx_contas_pagar_vencimento ON contas_pagar(data_vencimento);
CREATE INDEX idx_contas_pagar_status ON contas_pagar(status);

-- ============================================
-- TABELA: ml_configuracao (Config Mercado Livre)
-- ============================================
CREATE TABLE ml_configuracao (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    app_id VARCHAR(50) NOT NULL,
    client_secret VARCHAR(100) NOT NULL,
    access_token TEXT,
    refresh_token TEXT,
    token_expira_em TIMESTAMP,
    
    sync_estoque BOOLEAN DEFAULT true,
    sync_precos BOOLEAN DEFAULT true,
    markup_ml DECIMAL(5,2) DEFAULT 0.00, -- markup adicional para ML
    
    ultima_sincronizacao TIMESTAMP,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- TABELA: ml_pedidos (Pedidos do Mercado Livre)
-- ============================================
CREATE TABLE ml_pedidos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ml_order_id VARCHAR(50) UNIQUE NOT NULL,
    venda_id UUID REFERENCES vendas(id) ON DELETE SET NULL,
    
    status VARCHAR(50), -- paid, cancelled, etc
    status_shipping VARCHAR(50),
    
    comprador_nome VARCHAR(255),
    comprador_email VARCHAR(255),
    comprador_telefone VARCHAR(20),
    
    dados_envio JSONB,
    dados_completos JSONB, -- JSON completo do pedido ML
    
    processado BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_ml_pedidos_order_id ON ml_pedidos(ml_order_id);
CREATE INDEX idx_ml_pedidos_processado ON ml_pedidos(processado);

-- ============================================
-- TABELA: logs_sistema
-- ============================================
CREATE TABLE logs_sistema (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    acao VARCHAR(100) NOT NULL,
    modulo VARCHAR(50) NOT NULL,
    descricao TEXT,
    
    ip_address VARCHAR(45),
    user_agent TEXT,
    
    dados_adicionais JSONB,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_logs_usuario ON logs_sistema(usuario_id);
CREATE INDEX idx_logs_modulo ON logs_sistema(modulo);
CREATE INDEX idx_logs_data ON logs_sistema(created_at);

-- ============================================
-- TRIGGERS PARA updated_at
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON clientes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_produtos_updated_at BEFORE UPDATE ON produtos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_servicos_updated_at BEFORE UPDATE ON servicos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_fornecedores_updated_at BEFORE UPDATE ON fornecedores FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_compras_updated_at BEFORE UPDATE ON compras FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vendas_updated_at BEFORE UPDATE ON vendas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ordens_servico_updated_at BEFORE UPDATE ON ordens_servico FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contas_receber_updated_at BEFORE UPDATE ON contas_receber FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contas_pagar_updated_at BEFORE UPDATE ON contas_pagar FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


-- ============================================
-- MÓDULO: FORMAS DE PAGAMENTO E PARCELAS
-- ============================================

CREATE TABLE formas_pagamento (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(100) NOT NULL, -- Dinheiro, Crédito, Débito, PIX, Boleto
    tipo VARCHAR(50), -- 'vista', 'prazo'
    taxa_percentual DECIMAL(5,2) DEFAULT 0.00, -- taxa da operadora (ex: 2.5% cartão)
    permite_parcelamento BOOLEAN DEFAULT false,
    max_parcelas INTEGER DEFAULT 1,
    dias_recebimento INTEGER DEFAULT 0, -- prazo para cair na conta
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE venda_pagamentos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    venda_id UUID REFERENCES vendas(id) ON DELETE CASCADE,
    forma_pagamento_id UUID REFERENCES formas_pagamento(id),
    
    valor DECIMAL(15,2) NOT NULL,
    parcelas INTEGER DEFAULT 1,
    valor_parcela DECIMAL(15,2),
    taxa_juros DECIMAL(5,2) DEFAULT 0.00,
    
    -- Referência externa (transação)
    nsu VARCHAR(50), -- Número Sequencial Único (cartão)
    autorizacao VARCHAR(50),
    tid VARCHAR(50), -- Transaction ID
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE parcelas_receber (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    venda_pagamento_id UUID REFERENCES venda_pagamentos(id) ON DELETE CASCADE,
    conta_receber_id UUID REFERENCES contas_receber(id),
    
    numero_parcela INTEGER NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    data_vencimento DATE NOT NULL,
    data_recebimento DATE,
    
    status VARCHAR(50) DEFAULT 'pendente', -- pendente, recebido, vencido
    
    created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- MÓDULO: CÁLCULO DE FRETE
-- ============================================

CREATE TABLE configuracao_frete (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo VARCHAR(20) NOT NULL, -- 'correios', 'melhor_envio', 'fixo', 'gratis', 'tabela'
    
    -- Dados de origem
    cep_origem VARCHAR(9),
    prazo_adicional INTEGER DEFAULT 0, -- dias extras handling
    
    -- Frete grátis condicional
    frete_gratis_acima DECIMAL(10,2),
    frete_gratis_regioes JSONB, -- ["SP", "RJ", "MG"]
    
    -- Melhor Envio
    me_token TEXT,
    me_servicos_habilitados JSONB, -- ["SEDEX", "PAC", ".Package"]
    
    -- Tabela fixa por região
    tabela_valores JSONB, -- [{"uf": "SP", "valor": 15.00, "prazo": 3}, ...]
    
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE fretes_calculados (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    venda_id UUID REFERENCES vendas(id) ON DELETE SET NULL,
    
    cep_origem VARCHAR(9) NOT NULL,
    cep_destino VARCHAR(9) NOT NULL,
    
    peso_total DECIMAL(8,3), -- kg
    valor_declarado DECIMAL(15,2),
    
    -- Cotação escolhida
    servico VARCHAR(50), -- 'PAC', 'SEDEX', etc
    transportadora VARCHAR(100),
    valor DECIMAL(10,2) NOT NULL,
    prazo_dias INTEGER,
    
    -- Rastreamento
    codigo_rastreio VARCHAR(50),
    etiqueta_url TEXT,
    status_entrega VARCHAR(50), -- 'pendente', 'postado', 'transito', 'entregue'
    data_postagem DATE,
    data_entrega DATE,
    
    -- JSON completo da cotação
    dados_completos JSONB,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_fretes_venda ON fretes_calculados(venda_id);
CREATE INDEX idx_fretes_rastreio ON fretes_calculados(codigo_rastreio);

-- ============================================
-- MÓDULO: TRIBUTAÇÃO E CONTABILIDADE FISCAL
-- ============================================

CREATE TABLE configuracao_fiscal (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Regime tributário
    regime VARCHAR(50) NOT NULL, -- 'simples_nacional', 'lucro_presumido', 'lucro_real', 'mei'
    
    -- Simples Nacional
    anexo VARCHAR(10), -- 'I', 'II', 'III', 'IV', 'V'
    faixa_receita_12meses DECIMAL(15,2),
    aliquota_efetiva DECIMAL(5,2), -- calculada automaticamente
    
    -- Dados da empresa
    cnpj VARCHAR(18) NOT NULL,
    razao_social VARCHAR(255) NOT NULL,
    nome_fantasia VARCHAR(255),
    ie VARCHAR(20), -- Inscrição Estadual
    im VARCHAR(20), -- Inscrição Municipal
    
    -- Endereço fiscal
    cep VARCHAR(9),
    endereco VARCHAR(255),
    numero VARCHAR(10),
    complemento VARCHAR(100),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    uf VARCHAR(2),
    codigo_municipio VARCHAR(7), -- código IBGE
    
    -- Certificado Digital
    certificado_path VARCHAR(255),
    certificado_senha_encrypted TEXT,
    certificado_validade DATE,
    certificado_tipo VARCHAR(10), -- A1 ou A3
    
    -- Configurações NF-e
    ambiente_nfe VARCHAR(20) DEFAULT 'homologacao', -- 'homologacao' ou 'producao'
    serie_nfe INTEGER DEFAULT 1,
    numero_ultima_nfe INTEGER DEFAULT 0,
    
    -- Configurações NFS-e
    ambiente_nfse VARCHAR(20) DEFAULT 'homologacao',
    serie_nfse INTEGER DEFAULT 1,
    numero_ultima_nfse INTEGER DEFAULT 0,
    provedor_nfse VARCHAR(50), -- provedor usado pelo município
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE regras_tributarias (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(255), -- nome descritivo da regra
    
    -- Origem
    uf_origem VARCHAR(2) NOT NULL,
    
    -- Destino
    uf_destino VARCHAR(2) NOT NULL,
    tipo_destinatario VARCHAR(20) NOT NULL, -- 'pf', 'pj', 'orgao_publico'
    contribuinte_icms BOOLEAN DEFAULT false,
    
    -- Tipo de operação
    tipo_operacao VARCHAR(20) NOT NULL, -- 'venda', 'devolucao', 'transferencia', 'remessa'
    finalidade VARCHAR(50) DEFAULT 'consumo_final', -- 'consumo_final', 'revenda', 'ativo'
    
    -- Códigos fiscais
    cfop VARCHAR(4) NOT NULL,
    cst_icms VARCHAR(3), -- Código Situação Tributária ICMS (000-999)
    cst_pis_cofins VARCHAR(2), -- 01-99
    
    -- Alíquotas
    aliquota_icms DECIMAL(5,2) DEFAULT 0.00,
    aliquota_pis DECIMAL(5,2) DEFAULT 0.00,
    aliquota_cofins DECIMAL(5,2) DEFAULT 0.00,
    aliquota_iss DECIMAL(5,2) DEFAULT 0.00, -- para serviços
    
    -- Redução de base de cálculo
    reducao_base_icms DECIMAL(5,2) DEFAULT 0.00, -- % de redução
    
    -- Substituição Tributária
    aplica_st BOOLEAN DEFAULT false,
    mva DECIMAL(5,2) DEFAULT 0.00, -- Margem Valor Agregado
    
    -- Observações
    mensagem_nota TEXT, -- mensagem que aparece na nota fiscal
    observacao_interna TEXT,
    
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_regras_origem_destino ON regras_tributarias(uf_origem, uf_destino);
CREATE INDEX idx_regras_cfop ON regras_tributarias(cfop);

CREATE TABLE ncm_tributacao (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ncm VARCHAR(8) UNIQUE NOT NULL,
    descricao TEXT NOT NULL,
    
    -- CEST (Código Especificador da Substituição Tributária)
    cest VARCHAR(7),
    
    -- Alíquotas federais
    aliquota_ipi DECIMAL(5,2) DEFAULT 0.00,
    
    -- Exceções estaduais (alguns produtos têm alíquota diferenciada)
    excecoes_estaduais JSONB, -- [{"uf": "SP", "aliquota_icms": 12.00}, ...]
    
    -- Categoria fiscal
    tipo VARCHAR(50), -- 'combustivel', 'medicamento', 'alimento', 'geral'
    
    ativo BOOLEAN DEFAULT true,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_ncm_codigo ON ncm_tributacao(ncm);

CREATE TABLE calculos_tributarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Referência
    venda_id UUID REFERENCES vendas(id) ON DELETE CASCADE,
    venda_item_id UUID,
    produto_id UUID REFERENCES produtos(id),
    
    regra_aplicada_id UUID REFERENCES regras_tributarias(id),
    ncm_aplicado_id UUID REFERENCES ncm_tributacao(id),
    
    -- Valores base
    valor_produto DECIMAL(15,2) NOT NULL,
    
    -- Bases de cálculo
    base_calculo_icms DECIMAL(15,2),
    base_calculo_icms_st DECIMAL(15,2),
    base_calculo_pis DECIMAL(15,2),
    base_calculo_cofins DECIMAL(15,2),
    
    -- Valores dos impostos
    valor_icms DECIMAL(15,2) DEFAULT 0.00,
    valor_icms_st DECIMAL(15,2) DEFAULT 0.00,
    valor_ipi DECIMAL(15,2) DEFAULT 0.00,
    valor_pis DECIMAL(15,2) DEFAULT 0.00,
    valor_cofins DECIMAL(15,2) DEFAULT 0.00,
    valor_iss DECIMAL(15,2) DEFAULT 0.00,
    
    total_impostos DECIMAL(15,2) GENERATED ALWAYS AS (
        valor_icms + valor_icms_st + valor_ipi + valor_pis + valor_cofins + valor_iss
    ) STORED,
    
    -- Detalhamento do cálculo (auditoria)
    detalhamento JSONB, -- passo-a-passo de como chegou nos valores
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_calc_trib_venda ON calculos_tributarios(venda_id);
CREATE INDEX idx_calc_trib_produto ON calculos_tributarios(produto_id);

-- ============================================
-- MÓDULO: DEVOLUÇÕES E TROCAS
-- ============================================

CREATE TABLE devolucoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_devolucao VARCHAR(20) UNIQUE NOT NULL,
    
    venda_id UUID REFERENCES vendas(id) ON DELETE RESTRICT,
    cliente_id UUID REFERENCES clientes(id),
    usuario_id UUID REFERENCES users(id),
    
    tipo VARCHAR(20) NOT NULL, -- 'devolucao', 'troca'
    motivo VARCHAR(50), -- 'defeito', 'arrependimento', 'erro_pedido', 'nao_corresponde'
    descricao_motivo TEXT,
    
    data_devolucao TIMESTAMP DEFAULT NOW(),
    
    -- Valores
    total_devolvido DECIMAL(15,2) NOT NULL,
    total_reembolsado DECIMAL(15,2) DEFAULT 0.00,
    
    -- Status
    status VARCHAR(50) DEFAULT 'solicitada', -- solicitada, aprovada, recusada, concluida
    
    -- NF-e de devolução
    nfe_devolucao_emitida BOOLEAN DEFAULT false,
    nfe_devolucao_chave VARCHAR(44),
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE devolucao_itens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    devolucao_id UUID REFERENCES devolucoes(id) ON DELETE CASCADE,
    venda_item_id UUID, -- referência ao item original da venda
    produto_id UUID REFERENCES produtos(id),
    
    quantidade INTEGER NOT NULL,
    valor_unitario DECIMAL(15,2) NOT NULL,
    total DECIMAL(15,2) NOT NULL,
    
    -- Troca
    produto_troca_id UUID REFERENCES produtos(id), -- se for troca, qual produto novo
    quantidade_troca INTEGER,
    diferenca_valor DECIMAL(15,2) DEFAULT 0.00, -- se produto de troca for mais caro
    
    -- Condição do produto
    condicao VARCHAR(50), -- 'novo', 'usado_bom', 'usado_ruim', 'danificado'
    retorna_estoque BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_devolucoes_venda ON devolucoes(venda_id);
CREATE INDEX idx_devolucoes_status ON devolucoes(status);

-- ============================================
-- MÓDULO: COMISSÕES DE VENDEDORES
-- ============================================

CREATE TABLE configuracao_comissoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    tipo VARCHAR(50) NOT NULL, -- 'percentual', 'valor_fixo', 'mista', 'por_produto'
    
    -- Comissão percentual
    percentual_padrao DECIMAL(5,2) DEFAULT 0.00,
    
    -- Comissão fixa por venda
    valor_fixo_venda DECIMAL(10,2) DEFAULT 0.00,
    
    -- Comissão por categoria de produto (JSONB)
    comissao_por_categoria JSONB, -- [{"categoria_id": "uuid", "percentual": 5.00}]
    
    -- Metas e bonificações
    meta_mensal DECIMAL(15,2),
    bonus_meta DECIMAL(5,2), -- % extra se bater a meta
    
    vigencia_inicio DATE NOT NULL,
    vigencia_fim DATE,
    
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE comissoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID REFERENCES users(id) ON DELETE RESTRICT,
    venda_id UUID REFERENCES vendas(id) ON DELETE RESTRICT,
    
    base_calculo DECIMAL(15,2) NOT NULL, -- valor da venda
    percentual_aplicado DECIMAL(5,2),
    valor_comissao DECIMAL(10,2) NOT NULL,
    
    data_referencia DATE NOT NULL, -- data da venda
    data_pagamento DATE,
    status VARCHAR(50) DEFAULT 'pendente', -- pendente, pago, cancelado
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_comissoes_usuario ON comissoes(usuario_id);
CREATE INDEX idx_comissoes_status ON comissoes(status);
CREATE INDEX idx_comissoes_referencia ON comissoes(data_referencia);

-- ============================================
-- MÓDULO: KITS E COMBOS
-- ============================================

CREATE TABLE kits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    sku VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    
    -- Precificação
    preco_venda DECIMAL(15,2) NOT NULL,
    preco_custo_total DECIMAL(15,2) DEFAULT 0.00,
    margem_lucro DECIMAL(5,2),
    
    imagem_principal TEXT,
    
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE kit_itens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    kit_id UUID REFERENCES kits(id) ON DELETE CASCADE,
    produto_id UUID REFERENCES produtos(id) ON DELETE RESTRICT,
    
    quantidade INTEGER NOT NULL,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_kit_itens_kit ON kit_itens(kit_id);

-- Trigger para recalcular custo_total do kit automaticamente ao alterar itens
CREATE OR REPLACE FUNCTION recalcular_custo_kit()
RETURNS TRIGGER AS $$
DECLARE
    target_kit_id UUID;
    novo_custo DECIMAL(15,2);
BEGIN
    target_kit_id := COALESCE(NEW.kit_id, OLD.kit_id);
    
    SELECT COALESCE(SUM(p.custo_compra * ki.quantidade), 0.00)
    INTO novo_custo
    FROM kit_itens ki
    JOIN produtos p ON p.id = ki.produto_id
    WHERE ki.kit_id = target_kit_id;

    UPDATE kits
    SET preco_custo_total = novo_custo,
        updated_at = NOW()
    WHERE id = target_kit_id;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_recalcular_custo_kit
AFTER INSERT OR UPDATE OR DELETE ON kit_itens
FOR EACH ROW EXECUTE FUNCTION recalcular_custo_kit();

-- ============================================
-- MÓDULO: SERIAL NUMBER / LOTE
-- ============================================

CREATE TABLE produtos_seriais (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    produto_id UUID REFERENCES produtos(id) ON DELETE CASCADE,
    
    numero_serie VARCHAR(100) UNIQUE NOT NULL,
    imei VARCHAR(20), -- para celulares
    lote VARCHAR(50),
    data_fabricacao DATE,
    data_validade DATE,
    
    -- Rastreamento
    status VARCHAR(50) DEFAULT 'estoque', -- estoque, vendido, defeito, devolucao
    
    venda_id UUID REFERENCES vendas(id),
    data_venda TIMESTAMP,
    
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_produtos_seriais_numero ON produtos_seriais(numero_serie);
CREATE INDEX idx_produtos_seriais_produto ON produtos_seriais(produto_id);
CREATE INDEX idx_produtos_seriais_status ON produtos_seriais(status);

-- ============================================
-- MÓDULO: SITE E MARKETING AUTOMATIZADO
-- ============================================

CREATE TABLE site_configuracao (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Dados do site
    nome_loja VARCHAR(255) NOT NULL,
    slogan VARCHAR(255),
    dominio VARCHAR(255), -- meusite.com.br ou subdominio.sistemaloja.com
    
    -- Identidade visual
    logo_url TEXT,
    favicon_url TEXT,
    cor_primaria VARCHAR(7), -- hex color
    cor_secundaria VARCHAR(7),
    
    -- SEO
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords TEXT,
    
    -- Redes sociais
    facebook_url VARCHAR(255),
    instagram_url VARCHAR(255),
    whatsapp VARCHAR(20),
    
    -- Integrações
    google_analytics VARCHAR(50),
    facebook_pixel VARCHAR(50),
    
    -- Configurações
    site_ativo BOOLEAN DEFAULT false,
    catalogo_publico BOOLEAN DEFAULT true, -- exibe produtos mesmo sem comprar online
    loja_online_ativa BOOLEAN DEFAULT false, -- permite comprar pelo site
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE site_paginas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    slug VARCHAR(100) UNIQUE NOT NULL, -- sobre-nos, contato, termos
    titulo VARCHAR(255) NOT NULL,
    conteudo TEXT,
    
    -- SEO
    meta_title VARCHAR(255),
    meta_description TEXT,
    
    ordem INTEGER DEFAULT 0,
    visivel_menu BOOLEAN DEFAULT true,
    ativa BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE site_banners (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    titulo VARCHAR(255),
    subtitulo VARCHAR(255),
    imagem_url TEXT NOT NULL,
    imagem_mobile_url TEXT,
    
    link_destino VARCHAR(255), -- URL ou produto_id
    botao_texto VARCHAR(50), -- "Ver mais", "Comprar agora"
    
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT true,
    
    data_inicio TIMESTAMP,
    data_fim TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE marketing_campanhas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    nome VARCHAR(255) NOT NULL,
    tipo VARCHAR(50), -- 'promocao', 'lancamento', 'sazonal'
    
    -- Configuração
    data_inicio TIMESTAMP NOT NULL,
    data_fim TIMESTAMP NOT NULL,
    
    -- Desconto
    tipo_desconto VARCHAR(20), -- 'percentual', 'valor_fixo'
    valor_desconto DECIMAL(10,2),
    
    -- Filtros de produtos
    produtos_ids JSONB, -- lista de UUIDs ou null = todos
    categorias_ids JSONB,
    
    -- Publicação automática
    publicar_site BOOLEAN DEFAULT true,
    publicar_instagram BOOLEAN DEFAULT false,
    publicar_facebook BOOLEAN DEFAULT false,
    
    -- Template da postagem
    texto_post TEXT,
    imagem_post_url TEXT,
    hashtags TEXT,
    
    -- Status
    status VARCHAR(50) DEFAULT 'rascunho', -- rascunho, agendada, ativa, finalizada
    
    -- Métricas
    visualizacoes INTEGER DEFAULT 0,
    cliques INTEGER DEFAULT 0,
    vendas_geradas INTEGER DEFAULT 0,
    receita_gerada DECIMAL(15,2) DEFAULT 0.00,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_campanhas_status ON marketing_campanhas(status);
CREATE INDEX idx_campanhas_periodo ON marketing_campanhas(data_inicio, data_fim);

CREATE TABLE marketing_posts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campanha_id UUID REFERENCES marketing_campanhas(id) ON DELETE SET NULL,
    
    plataforma VARCHAR(50) NOT NULL, -- 'instagram', 'facebook', 'site'
    
    tipo VARCHAR(50), -- 'feed', 'stories', 'reels', 'banner_site'
    
    conteudo TEXT NOT NULL,
    imagem_url TEXT,
    video_url TEXT,
    
    -- Agendamento
    data_publicacao TIMESTAMP NOT NULL,
    publicado BOOLEAN DEFAULT false,
    
    -- ID externo (após publicação)
    post_id_externo VARCHAR(100),
    url_publicacao TEXT,
    
    -- Métricas
    curtidas INTEGER DEFAULT 0,
    comentarios INTEGER DEFAULT 0,
    compartilhamentos INTEGER DEFAULT 0,
    alcance INTEGER DEFAULT 0,
    
    status VARCHAR(50) DEFAULT 'agendado', -- agendado, publicado, erro, cancelado
    erro_mensagem TEXT,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_posts_plataforma ON marketing_posts(plataforma);
CREATE INDEX idx_posts_data_pub ON marketing_posts(data_publicacao);
CREATE INDEX idx_posts_status ON marketing_posts(status);

CREATE TABLE integracao_redes_sociais (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    plataforma VARCHAR(50) UNIQUE NOT NULL, -- instagram, facebook
    
    -- Tokens de acesso
    access_token TEXT,
    refresh_token TEXT,
    token_expira_em TIMESTAMP,
    
    -- IDs das contas
    account_id VARCHAR(100),
    page_id VARCHAR(100), -- Facebook Page ID
    instagram_business_id VARCHAR(100),
    
    -- Configurações
    auto_publicar BOOLEAN DEFAULT false,
    auto_responder BOOLEAN DEFAULT false,
    mensagem_auto_resposta TEXT,
    
    ativa BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);


-- ============================================
-- DADOS INICIAIS
-- ============================================

-- Usuário admin padrão (senha: admin123 - TROCAR EM PRODUÇÃO)
INSERT INTO users (nome, email, password, cpf, role) VALUES 
('Administrador', 'admin@sistema.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '000.000.000-00', 'admin');

-- Categorias padrão
INSERT INTO categorias_produto (nome, descricao) VALUES 
('Geral', 'Categoria padrão para produtos'),
('Eletrônicos', 'Produtos eletrônicos'),
('Peças', 'Peças e componentes'),
('Serviços', 'Itens de serviço');

