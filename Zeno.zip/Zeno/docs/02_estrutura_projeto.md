
# ESTRUTURA DO PROJETO - SISTEMA ERP LARAVEL
# ===========================================

## 1. ESTRUTURA DE DIRETÓRIOS

sistema-erp/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php
│   │   │   ├── DashboardController.php
│   │   │   ├── ProdutoController.php
│   │   │   ├── CategoriaController.php
│   │   │   ├── ClienteController.php
│   │   │   ├── FornecedorController.php
│   │   │   ├── CompraController.php
│   │   │   ├── VendaController.php
│   │   │   ├── ServicoController.php
│   │   │   ├── OrdemServicoController.php
│   │   │   ├── EstoqueController.php
│   │   │   ├── FinanceiroController.php
│   │   │   ├── NFeController.php
│   │   │   ├── NFSeController.php
│   │   │   ├── MercadoLivreController.php
│   │   │   ├── RelatorioController.php
│   │   │   └── UsuarioController.php
│   │   │
│   │   ├── Middleware/
│   │   │   ├── CheckRole.php
│   │   │   └── LogActivity.php
│   │   │
│   │   └── Requests/
│   │       ├── ProdutoRequest.php
│   │       ├── VendaRequest.php
│   │       └── OrdemServicoRequest.php
│   │
│   ├── Models/
│   │   ├── User.php
│   │   ├── Cliente.php
│   │   ├── Fornecedor.php
│   │   ├── CategoriaProduto.php
│   │   ├── Produto.php
│   │   ├── Servico.php
│   │   ├── Compra.php
│   │   ├── CompraItem.php
│   │   ├── Venda.php
│   │   ├── VendaItem.php
│   │   ├── OrdemServico.php
│   │   ├── OsServico.php
│   │   ├── OsProduto.php
│   │   ├── MovimentacaoEstoque.php
│   │   ├── ContaReceber.php
│   │   ├── ContaPagar.php
│   │   ├── MlConfiguracao.php
│   │   ├── MlPedido.php
│   │   └── LogSistema.php
│   │
│   ├── Services/
│   │   ├── EstoqueService.php
│   │   ├── FinanceiroService.php
│   │   ├── NFeService.php
│   │   ├── NFSeService.php
│   │   ├── MercadoLivreService.php
│   │   ├── CalculoService.php
│   │   └── RelatorioService.php
│   │
│   ├── Helpers/
│   │   ├── FormatHelper.php
│   │   └── ValidationHelper.php
│   │
│   └── Jobs/
│       ├── SincronizarMercadoLivre.php
│       ├── ProcessarNFe.php
│       └── EnviarEmailCobranca.php
│
├── database/
│   ├── migrations/
│   │   └── (arquivos de migração conforme schema)
│   │
│   └── seeders/
│       ├── DatabaseSeeder.php
│       ├── UserSeeder.php
│       └── CategoriaSeeder.php
│
├── resources/
│   ├── views/
│   │   ├── layouts/
│   │   │   ├── app.blade.php
│   │   │   ├── sidebar.blade.php
│   │   │   └── navbar.blade.php
│   │   │
│   │   ├── auth/
│   │   │   ├── login.blade.php
│   │   │   └── register.blade.php
│   │   │
│   │   ├── dashboard/
│   │   │   └── index.blade.php
│   │   │
│   │   ├── produtos/
│   │   │   ├── index.blade.php
│   │   │   ├── create.blade.php
│   │   │   ├── edit.blade.php
│   │   │   └── show.blade.php
│   │   │
│   │   ├── clientes/
│   │   │   ├── index.blade.php
│   │   │   ├── create.blade.php
│   │   │   └── edit.blade.php
│   │   │
│   │   ├── vendas/
│   │   │   ├── index.blade.php
│   │   │   ├── create.blade.php (PDV)
│   │   │   └── show.blade.php
│   │   │
│   │   ├── servicos/
│   │   │   ├── index.blade.php
│   │   │   └── ordens/
│   │   │       ├── index.blade.php
│   │   │       ├── create.blade.php
│   │   │       └── show.blade.php
│   │   │
│   │   ├── compras/
│   │   │   ├── index.blade.php
│   │   │   └── create.blade.php
│   │   │
│   │   ├── estoque/
│   │   │   ├── index.blade.php
│   │   │   └── movimentacoes.blade.php
│   │   │
│   │   ├── financeiro/
│   │   │   ├── receber.blade.php
│   │   │   ├── pagar.blade.php
│   │   │   └── fluxo-caixa.blade.php
│   │   │
│   │   ├── nfe/
│   │   │   ├── emitir.blade.php
│   │   │   └── historico.blade.php
│   │   │
│   │   ├── mercadolivre/
│   │   │   ├── config.blade.php
│   │   │   ├── produtos.blade.php
│   │   │   └── pedidos.blade.php
│   │   │
│   │   └── relatorios/
│   │       ├── vendas.blade.php
│   │       ├── estoque.blade.php
│   │       └── financeiro.blade.php
│   │
│   └── css/
│       └── app.css (Tailwind compilado)
│
├── routes/
│   ├── web.php
│   └── api.php
│
├── public/
│   ├── css/
│   ├── js/
│   │   ├── app.js
│   │   ├── produtos.js
│   │   ├── vendas.js
│   │   └── alpine-components.js
│   └── images/
│
├── config/
│   ├── database.php (Supabase connection)
│   ├── nfe.php
│   ├── mercadolivre.php
│   └── services.php
│
├── .env
├── composer.json
├── package.json
└── README.md


## 2. DEPENDÊNCIAS PRINCIPAIS

### Composer (PHP)
{
  "require": {
    "php": "^8.2",
    "laravel/framework": "^11.0",
    "guzzlehttp/guzzle": "^7.8",
    "nfephp-org/sped-nfe": "^6.0",
    "nfephp-org/sped-nfse": "^2.0",
    "intervention/image": "^3.0",
    "barryvdh/laravel-dompdf": "^2.0",
    "maatwebsite/excel": "^3.1",
    "pusher/pusher-php-server": "^7.2"
  },
  "require-dev": {
    "fakerphp/faker": "^1.23",
    "laravel/pint": "^1.13",
    "phpunit/phpunit": "^10.5"
  }
}

### NPM (Frontend)
{
  "devDependencies": {
    "alpinejs": "^3.13",
    "tailwindcss": "^3.4",
    "axios": "^1.6",
    "chart.js": "^4.4",
    "@tailwindcss/forms": "^0.5",
    "vite": "^5.0",
    "laravel-vite-plugin": "^1.0"
  }
}


## 3. CONFIGURAÇÃO SUPABASE

### .env
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_KEY=sua_anon_key
SUPABASE_SERVICE_KEY=sua_service_key

DB_CONNECTION=pgsql
DB_HOST=db.seu-projeto.supabase.co
DB_PORT=5432
DB_DATABASE=postgres
DB_USERNAME=postgres
DB_PASSWORD=sua_senha


## 4. ROTAS PRINCIPAIS (web.php)

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

Route::middleware(['auth'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    
    // Produtos
    Route::resource('produtos', ProdutoController::class);
    Route::post('produtos/{id}/sync-ml', [ProdutoController::class, 'syncMercadoLivre']);
    
    // Clientes
    Route::resource('clientes', ClienteController::class);
    
    // Vendas (PDV)
    Route::resource('vendas', VendaController::class);
    Route::post('vendas/{id}/emitir-nfe', [VendaController::class, 'emitirNFe']);
    
    // Ordem de Serviço
    Route::resource('ordens-servico', OrdemServicoController::class);
    Route::post('ordens-servico/{id}/calcular', [OrdemServicoController::class, 'calcularTotal']);
    Route::post('ordens-servico/{id}/emitir-nfse', [OrdemServicoController::class, 'emitirNFSe']);
    
    // Compras
    Route::resource('compras', CompraController::class);
    Route::post('compras/{id}/receber', [CompraController::class, 'receberMercadoria']);
    
    // Estoque
    Route::get('estoque', [EstoqueController::class, 'index'])->name('estoque.index');
    Route::get('estoque/movimentacoes', [EstoqueController::class, 'movimentacoes']);
    
    // Financeiro
    Route::get('financeiro/receber', [FinanceiroController::class, 'receber']);
    Route::get('financeiro/pagar', [FinanceiroController::class, 'pagar']);
    Route::post('financeiro/receber/{id}/baixar', [FinanceiroController::class, 'baixarReceber']);
    
    // Mercado Livre
    Route::get('mercadolivre/config', [MercadoLivreController::class, 'config']);
    Route::post('mercadolivre/auth', [MercadoLivreController::class, 'authenticate']);
    Route::post('mercadolivre/sincronizar', [MercadoLivreController::class, 'sincronizar']);
    
    // Relatórios
    Route::get('relatorios/vendas', [RelatorioController::class, 'vendas']);
    Route::get('relatorios/estoque', [RelatorioController::class, 'estoque']);
    
    // Admin
    Route::middleware(['role:admin'])->group(function () {
        Route::resource('usuarios', UsuarioController::class);
    });
});


## 5. MODELS PRINCIPAIS (Exemplos)

### Produto.php
class Produto extends Model
{
    protected $fillable = [
        'categoria_id', 'sku', 'nome', 'descricao',
        'estoque_atual', 'estoque_minimo', 'estoque_maximo',
        'custo_compra', 'margem_lucro', 'preco_venda', 'preco_promocional',
        'ncm', 'cfop', 'ml_id', 'imagem_principal', 'ativo'
    ];

    protected $casts = [
        'imagens_adicionais' => 'array',
        'ml_sincronizado' => 'boolean',
        'ativo' => 'boolean',
    ];

    public function categoria() {
        return $this->belongsTo(CategoriaProduto::class, 'categoria_id');
    }

    public function movimentacoes() {
        return $this->hasMany(MovimentacaoEstoque::class);
    }

    // Calcula preço de venda com base no custo e margem
    public function calcularPrecoVenda() {
        return $this->custo_compra * (1 + ($this->margem_lucro / 100));
    }
}

### Venda.php
class Venda extends Model
{
    protected $fillable = [
        'numero_venda', 'cliente_id', 'usuario_id',
        'data_venda', 'subtotal', 'desconto', 'frete', 'total',
        'forma_pagamento', 'status_pagamento', 'origem', 'observacoes'
    ];

    protected $casts = [
        'data_venda' => 'datetime',
        'nfe_emitida' => 'boolean',
    ];

    public function cliente() {
        return $this->belongsTo(Cliente::class);
    }

    public function itens() {
        return $this->hasMany(VendaItem::class);
    }

    public function usuario() {
        return $this->belongsTo(User::class);
    }
}

### OrdemServico.php
class OrdemServico extends Model
{
    protected $table = 'ordens_servico';
    
    protected $fillable = [
        'numero_os', 'cliente_id', 'usuario_id',
        'data_abertura', 'data_previsao', 'data_conclusao',
        'titulo', 'descricao_problema', 'descricao_solucao',
        'total_servicos', 'total_produtos', 'desconto', 'total',
        'status', 'prioridade', 'observacoes'
    ];

    protected $casts = [
        'data_abertura' => 'datetime',
        'data_previsao' => 'date',
        'data_conclusao' => 'datetime',
        'nfse_emitida' => 'boolean',
    ];

    public function servicos() {
        return $this->hasMany(OsServico::class, 'os_id');
    }

    public function produtos() {
        return $this->hasMany(OsProduto::class, 'os_id');
    }

    public function calcularTotal() {
        $this->total_servicos = $this->servicos->sum('total');
        $this->total_produtos = $this->produtos->sum('total');
        $this->total = ($this->total_servicos + $this->total_produtos) - $this->desconto;
        $this->save();
    }
}


## 6. SERVICES (Lógica de Negócio)

### EstoqueService.php
- movimentar($produto_id, $tipo, $quantidade, $referencia)
- verificarEstoqueMinimo()
- ajustarEstoque($produto_id, $novo_estoque)
- calcularValorEstoque()

### MercadoLivreService.php
- authenticate($code)
- refreshToken()
- listarProdutos()
- publicarProduto($produto)
- sincronizarEstoque($produto_id)
- buscarPedidos()
- atualizarStatusPedido($order_id, $status)

### NFeService.php
- emitir($venda_id)
- gerarXML($dados)
- assinarXML($xml)
- transmitir($xml)
- consultarStatus($chave)
- cancelar($chave, $justificativa)
- downloadPDF($chave)

### CalculoService.php
- calcularMargemLucro($custo, $preco_venda)
- calcularPrecoVenda($custo, $margem)
- calcularMaoObra($horas, $valor_hora)
- aplicarDesconto($valor, $desconto)


## 7. JOBS (Tarefas Assíncronas)

### SincronizarMercadoLivre.php
- Sincroniza produtos a cada 30 minutos
- Atualiza estoque bidirecional
- Busca novos pedidos

### ProcessarNFe.php
- Emite NF-e em background
- Retry automático em caso de falha
- Notifica usuário quando concluído


## 8. MIGRATIONS EXEMPLO

### create_produtos_table.php
Schema::create('produtos', function (Blueprint $table) {
    $table->uuid('id')->primary();
    $table->uuid('categoria_id')->nullable();
    $table->string('sku', 50)->unique();
    $table->string('nome', 255);
    $table->text('descricao')->nullable();
    $table->integer('estoque_atual')->default(0);
    $table->integer('estoque_minimo')->default(0);
    $table->decimal('custo_compra', 15, 2)->default(0);
    $table->decimal('margem_lucro', 5, 2)->default(0);
    $table->decimal('preco_venda', 15, 2);
    $table->string('ncm', 8)->nullable();
    $table->string('ml_id', 50)->nullable();
    $table->boolean('ativo')->default(true);
    $table->timestamps();
    
    $table->foreign('categoria_id')
          ->references('id')
          ->on('categorias_produto')
          ->onDelete('set null');
});


## 9. INSTALAÇÃO E DEPLOY

### Instalação Local
1. git clone repositorio
2. composer install
3. npm install
4. cp .env.example .env
5. Configurar credenciais Supabase no .env
6. php artisan key:generate
7. Executar SQL do schema no Supabase
8. npm run dev
9. php artisan serve

### Deploy Render
1. Criar Web Service no Render
2. Build Command: composer install --no-dev && npm run build
3. Start Command: php artisan serve --host=0.0.0.0 --port=$PORT
4. Variáveis de ambiente no painel Render
5. Auto-deploy no push para branch main

