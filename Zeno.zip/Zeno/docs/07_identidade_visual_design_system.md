# ZENO - IDENTIDADE VISUAL FINAL
## Verde Floresta + Cobre #C68346 + Dourado Warm
### Aprovado em Outubro 2026

---

## PALETA OFICIAL

### LIGHT MODE
```css
:root {
  /* Brand Colors */
  --brand-primary:     #064E3B;   /* Verde Floresta - Primary */
  --brand-primary-h:   #065F46;
  --brand-primary-p:   #047857;
  
  --brand-secondary:   #C68346;   /* Cobre - Secondary */
  --brand-secondary-h: #E39650;
  --brand-secondary-p: #8A5B31;
  
  --brand-accent:      #C9962E;   /* Dourado Warm - CTA/Accent */
  --brand-accent-h:    #D4A017;
  --brand-accent-p:    #B8860B;
  
  /* Backgrounds */
  --bg-app:      #F0FDF4;   /* Green 50 */
  --bg-card:     #FFFFFF;
  --bg-hover:    #DCFCE7;   /* Green 100 */
  --bg-input:    #FFFFFF;
  
  /* Borders */
  --border-default: #BBF7D0;  /* Green 200 */
  --border-strong:  #86EFAC;  /* Green 300 */
  
  /* Text */
  --text-primary:   #022C22;  /* Green 950 */
  --text-secondary: #052E16;  /* Green 900 */
  --text-tertiary:  #166534;  /* Green 700 */
  --text-on-primary:   #FFFFFF;
  --text-on-secondary: #FFFFFF;
  --text-on-accent:    #000000;
  
  /* Effects */
  --focus-ring: rgba(6, 78, 59, 0.25);
  --shadow-sm: 0 1px 2px rgba(6, 78, 59, 0.08);
  --shadow-md: 0 4px 12px rgba(6, 78, 59, 0.12);
  --shadow-lg: 0 8px 24px rgba(6, 78, 59, 0.16);
}
```

### DARK MODE
```css
[data-theme="dark"] {
  --brand-primary:     #34D399;  /* Emerald 400 */
  --brand-primary-h:   #6EE7B7;
  --brand-primary-p:   #10B981;
  
  --brand-secondary:   #E39650;  /* Cobre Light */
  --brand-secondary-h: #F5B87A;
  --brand-secondary-p: #C68346;
  
  --brand-accent:      #FBBF24;  /* Amber 400 */
  --brand-accent-h:    #FCD34D;
  --brand-accent-p:    #F59E0B;
  
  --bg-app:      #022C22;  /* Green 950 - ÚNICO NO MERCADO */
  --bg-card:     #052E16;  /* Green 900 */
  --bg-elevated: #064E3B;  /* Green 800 */
  --bg-hover:    #065F46;
  --bg-input:    #064E3B;
  
  --border-default: #064E3B;
  --border-strong:  #065F46;
  
  --text-primary:   #ECFDF5;  /* Green 50 */
  --text-secondary: #D1FAE5;  /* Green 100 */
  --text-tertiary:  #A7F3D0;  /* Green 200 */
  --text-on-primary:   #000000;
  --text-on-secondary: #000000;
  --text-on-accent:    #000000;
  
  --focus-ring: rgba(52, 211, 153, 0.35);
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.4);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.5);
  --shadow-lg: 0 8px 24px rgba(0,0,0,0.6);
}
```

---

## REGRAS DE USO

| Cor | Papel | Light | Dark | Onde Usar |
|-----|-------|-------|------|-----------|
| **Verde Floresta** | Primary | #064E3B | #34D399 | Botão principal, links, títulos, foco, navegação ativa |
| **Cobre #C68346** | Secondary | #C68346 | #E39650 | Botão secundário, badges "Pendente", tags, acentos visuais |
| **Dourado Warm #C9962E** | Accent/CTA | #C9962E | #FBBF24 | **Botão ação principal** (Finalizar Venda, Emitir NF-e), badges "Promoção/Destaque", alertas sucesso |

### ⚠️ ACESSIBILIDADE (WCAG AA)
- **Verde Primary**: 12.6:1 no branco / 9.8:1 no verde 950 ✅ Texto QUALQUER tamanho
- **Cobre**: 3.1:1 no branco → **SÓ em texto ≥18px ou ≥14px bold** (botões, badges)
- **Dourado**: 2.7-3.7:1 → **SÓ em texto grande/bold** (botões CTA, badges destaque)
- **NUNCA** use cobre/dourado em corpo de texto, parágrafos, labels pequenos

---

## TIPOGRAFIA

```css
/* Fonte principal: Inter (Google Fonts) */
--font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;

/* Escala */
--text-xs:   0.75rem;  /* 12px */
--text-sm:   0.875rem; /* 14px */
--text-base: 1rem;     /* 16px */
--text-lg:   1.125rem; /* 18px */
--text-xl:   1.25rem;  /* 20px */
--text-2xl:  1.5rem;   /* 24px */
--text-3xl:  1.875rem; /* 30px */
--text-4xl:  2.25rem;  /* 36px */

/* Pesos */
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;
```

---

## ESPAÇAMENTO & RAIO

```css
/* Base: 4px */
--space-1: 0.25rem;  /* 4px */
--space-2: 0.5rem;   /* 8px */
--space-3: 0.75rem;  /* 12px */
--space-4: 1rem;     /* 16px */
--space-5: 1.25rem;  /* 20px */
--space-6: 1.5rem;   /* 24px */
--space-8: 2rem;     /* 32px */
--space-10: 2.5rem;  /* 40px */
--space-12: 3rem;    /* 48px */
--space-16: 4rem;    /* 64px */

/* Border Radius */
--radius-sm:  4px;
--radius-md:  8px;
--radius-lg:  12px;
--radius-xl:  16px;
--radius-full: 9999px;
```

---

## TAILWIND CONFIG

```js
// tailwind.config.js
module.exports = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          primary: '#064E3B',
          'primary-hover': '#065F46',
          'primary-pressed': '#047857',
          secondary: '#C68346',
          'secondary-hover': '#E39650',
          'secondary-pressed': '#8A5B31',
          accent: '#C9962E',
          'accent-hover': '#D4A017',
          'accent-pressed': '#B8860B',
        },
        // Dark mode via [data-theme="dark"] no <html>
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'brand-sm': '0 1px 2px rgba(6, 78, 59, 0.08)',
        'brand-md': '0 4px 12px rgba(6, 78, 59, 0.12)',
        'brand-lg': '0 8px 24px rgba(6, 78, 59, 0.16)',
      },
    },
  },
}
```

---

## ALPINE.JS TOGGLE TEMA

```html
<html x-data="{ 
  darkMode: localStorage.getItem('theme') === 'dark' || 
           (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)
}"
x-init="
  darkMode = localStorage.getItem('theme') === 'dark';
  document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
  watch(darkMode, v => { 
    localStorage.setItem('theme', v ? 'dark' : 'light'); 
    document.documentElement.setAttribute('data-theme', v ? 'dark' : 'light'); 
  })
"
:class="{ 'dark': darkMode }">
```

---

## DIFERENCIAIS DESTA IDENTIDADE

1. **Dark Mode Verde Escuro** (#022C22) — Nenhum ERP brasileiro usa; cria reconhecimento instantâneo
2. **Verde = Brasil, Nota Fiscal, Crescimento, Dinheiro** — Significado alinhado ao produto
3. **Cobre + Dourado = Valor, Resultado, Conquista** — O que o lojista busca
4. **Sistema de 3 cores com papéis claros** — Primary (navegação), Secondary (apoio), Accent (conversão)
5. **Acessível por design** — Contraste testado, regras claras de uso
