#!/bin/sh
set -e

# Detectar diretório da aplicação Laravel
APP_DIR="/var/www/html"
if [ -d "/var/www/zeno-erp-develop" ]; then
    APP_DIR="/var/www/zeno-erp-develop"
fi

# Render injeta a variável PORT dinamicamente (padrão 10000 se não estiver definida)
export PORT="${PORT:-80}"

echo "Configurando Nginx para escutar na porta ${PORT}..."
sed -i "s/\${PORT}/${PORT}/g" /etc/nginx/nginx.conf

# Criar diretórios necessários (sem brace expansion dentro de aspas)
mkdir -p "$APP_DIR/storage/framework/cache" \
         "$APP_DIR/storage/framework/sessions" \
         "$APP_DIR/storage/framework/views" \
         "$APP_DIR/bootstrap/cache" \
         /var/log/supervisor

# PHP-FPM atende como www-data; diretórios precisam ser graváveis por esse usuário
chown -R www-data:www-data "$APP_DIR/storage" "$APP_DIR/bootstrap/cache"
chmod -R 775 "$APP_DIR/storage" "$APP_DIR/bootstrap/cache"

# Enviar erros Laravel para os logs do container/Render
export LOG_CHANNEL=stderr

# Gerar APP_KEY se não existir (para ambientes sem .env)
if [ -z "$APP_KEY" ]; then
    echo "Definindo APP_KEY temporaria..."
    export APP_KEY="base64:$(head -c 32 /dev/urandom | base64)"
fi

# Se o .env existir, fazer cache das configurações
if [ -f "$APP_DIR/.env" ]; then
    echo "Cacheando configuracoes em $APP_DIR..."
    cd "$APP_DIR"
    php artisan config:cache 2>/dev/null || true
    php artisan route:cache 2>/dev/null || true
    php artisan view:cache 2>/dev/null || true
    # Tentar migration se comando disponivel
    if php artisan migrate:status 2>/dev/null; then
        php artisan migrate --force 2>/dev/null || true
    fi
fi

echo "Iniciando Nginx e PHP-FPM via Supervisord..."
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
