

<?php $__env->startSection('title', 'Estoque Baixo - ZENO ERP'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-8">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Estoque Baixo</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Produtos que precisam reposição imediata
                </p>
            </div>
            <a href="<?php echo e(route('produtos.index')); ?>" class="inline-flex items-center gap-2 rounded-lg border border-zeno-copper/30 bg-white dark:bg-gray-800 px-5 py-3 text-sm font-semibold text-zeno-copper hover:bg-zeno-copper/5 transition dark:border-zeno-copper/40">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 19l-7-7 7-7"/></svg>
                Voltar
            </a>
        </div>
    </div>

    <div class="mb-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400">
                    <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"/></svg>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Em Risco</p>
                    <p class="text-2xl font-bold text-amber-600 dark:text-amber-400"><?php echo e($totalBaixo); ?></p>
                </div>
            </div>
        </div>
        <div class="rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6 shadow-sm">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-zeno-forest/10 text-zeno-forest">
                    <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6M9 8h6M5 20h14a2 2 0 002-2V6a2 2 0 00-2 2v12a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Ativos</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($totalAtivo); ?></p>
                </div>
            </div>
        </div>
    </div>

    <?php if($produtos->isEmpty()): ?>
        <div class="rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-8 text-center">
            <div class="flex flex-col items-center gap-4">
                <div class="flex h-16 w-16 items-center justify-center rounded-2xl bg-zeno-forest/10 text-zeno-forest">
                    <svg class="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 13l4 4L19 7"/></svg>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Excelente!<br> Nenhum produto em estoque baixo</h3>
                    <p class="mt-1 text-gray-500 dark:text-gray-400">
                        Todos os produtos ativos estão com estoque acima do mínimo.
                    </p>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-5 shadow-sm hover:shadow-md transition-all duration-200">
                    <div class="flex items-center gap-4">
                        <div class="flex-shrink-0">
                            <?php if($produto->imagem_url && !str_contains($produto->imagem_url, 'placeholder')): ?>
                                <img src="<?php echo e($produto->imagem_url); ?>" alt="<?php echo e($produto->nome); ?>" class="h-16 w-16 rounded-xl object-cover">
                            <?php else: ?>
                                <div class="flex h-16 w-16 items-center justify-center rounded-xl bg-zeno-forest/10 text-zeno-forest">
                                    <svg class="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6m14 4l-2 2-2-4H6"/></svg>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="flex-1 min-w-0">
                            <h3 class="font-semibold text-gray-900 dark:text-white"><?php echo e($produto->nome); ?></h3>
                            <p class="text-sm text-gray-500 dark:text-gray-400">
                                SKU: <span class="font-mono bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded"><?php echo e($produto->sku); ?></span>
                            </p>
                            <div class="mt-2 flex items-center gap-4 text-sm">
                                <span class="text-gray-600 dark:text-gray-400">
                                    Atual: <span class="font-semibold text-amber-600 dark:text-amber-400"><?php echo e($produto->estoque_atual); ?></span>
                                </span>
                                <span class="text-gray-400">/</span>
                                <span class="text-gray-600 dark:text-gray-400">
                                    Mínimo: <span class="font-semibold text-gray-700 dark:text-gray-300"><?php echo e($produto->estoque_minimo); ?></span>
                                </span>
                            </div>
                        </div>

                        <div class="flex-shrink-0">
                            <span class="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400">
                                <svg class="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 9v2m0 4h.01"/></svg>
                                Urgente
                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-6">
            <?php echo e($produtos->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ARIEL\Documents\Projetos\Zeno\resources\views/produtos/estoque-baixo.blade.php ENDPATH**/ ?>