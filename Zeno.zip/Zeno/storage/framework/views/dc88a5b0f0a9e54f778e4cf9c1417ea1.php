<!DOCTYPE html>
<html lang="pt-BR" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'ZENO ERP')); ?> - <?php echo e($title ?? 'Login'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        zeno: {
                            forest: '#064E3B',
                            copper: '#C68346',
                            gold: '#C9962E',
                            'dark-bg': '#022C22',
                            'dark-card': '#064E3B',
                        }
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="min-h-screen bg-gray-50 text-slate-800 transition-colors duration-300 dark:bg-zeno-dark-bg">
    <?php
        $isAuthenticated = auth()->check();
        $isDashboard = request()->routeIs('dashboard');
        $isClientes = request()->routeIs('clientes.*');
        $isProdutos = request()->routeIs('produtos.*');
        $isFornecedores = request()->routeIs('fornecedores.*');
        $isCompras = request()->routeIs('compras.*');
        $isVendas = request()->routeIs('vendas.*');
        $isOS = request()->routeIs('ordens-servico.*');
        $isContasReceber = request()->routeIs('contas-receber.*');
        $isContasPagar = request()->routeIs('contas-pagar.*');
        $isCrm = request()->routeIs('crm.*') || request()->routeIs('admin.usuarios.*');
        $isAgenda = request()->routeIs('agenda.*');
        $user = auth()->user();
        $isAdmin = $user && $user->hasRole('admin');
        $isGerente = $user && $user->hasRole('gerente');
        $isVendedor = $user && $user->hasRole('vendedor');
        $isFinanceiro = $user && $user->hasRole('financeiro');
        $isTecnico = $user && $user->hasRole('tecnico');
    ?>
    <?php if($isAuthenticated): ?>
        <header class="sticky top-0 z-40 border-b border-emerald-950/10 bg-[#064E3B] text-white shadow-lg shadow-emerald-950/10">
            <div class="mx-auto flex min-h-[76px] max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
                <a href="<?php echo e(route('dashboard')); ?>" class="flex shrink-0 items-center gap-3" aria-label="ZENO ERP — início">
                    <span class="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-lg font-extrabold text-[#E2B15E] shadow-inner">Z</span>
                    <span class="leading-tight"><span class="block text-base font-extrabold tracking-[.12em]">ZENO</span><span class="block text-[10px] font-medium tracking-[.22em] text-emerald-100/75">GESTÃO EM EQUILÍBRIO</span></span>
                </a>
                <nav aria-label="Navegação principal" class="flex items-center gap-1 rounded-2xl border border-white/10 bg-[#022C22]/35 p-1.5 flex-wrap">
                    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isDashboard, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isDashboard]); ?>" <?php if($isDashboard): ?> aria-current="page" <?php endif; ?>>
                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke-width="1.8"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke-width="1.8"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke-width="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.5" stroke-width="1.8"/></svg>
                        <span>Painel</span>
                    </a>

                    <?php if($user->hasRole(['admin', 'gerente', 'vendedor', 'financeiro'])): ?>
                        <a href="<?php echo e(route('clientes.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isClientes, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isClientes]); ?>" <?php if($isClientes): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="9" cy="8" r="3.2" stroke-width="1.8"/><path d="M3.5 19c.5-3.2 2.3-4.8 5.5-4.8s5 1.6 5.5 4.8M16 5.2a3.2 3.2 0 010 6.1M17 14.5c2.1.6 3.3 2 3.6 4.5" stroke-width="1.8" stroke-linecap="round"/></svg>
                            <span>Clientes</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente', 'vendedor', 'financeiro'])): ?>
                        <a href="<?php echo e(route('agenda.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isAgenda, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isAgenda]); ?>" <?php if($isAgenda): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke-width="1.8"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke-width="1.8"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke-width="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.5" stroke-width="1.8"/></svg>
                            <span>Agenda</span>
                        </a>
                    <?php endif; ?>

                    <?php if($isAdmin): ?>
                        <a href="<?php echo e(route('admin.usuarios.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => request()->routeIs('admin.usuarios.*'), 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !request()->routeIs('admin.usuarios.*')]); ?>" <?php if(request()->routeIs('admin.usuarios.*')): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M12 4v16m8-8H4" stroke-width="1.8"/><path d="M20 16v4a2 2 0 01-2 2H6a2 2 0 01-2-2v-4M12 14a7 7 0 10-7-7 7 7 0 007 7z"/></svg>
                            <span>Usuários</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente'])): ?>
                        <a href="<?php echo e(route('fornecedores.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isFornecedores, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isFornecedores]); ?>" <?php if($isFornecedores): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 20h18M5 20V7l7-4 7 4v13M9 10h.01M15 10h.01M9 14h.01M15 14h.01M10 20v-3h4v3" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Fornecedores</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente', 'financeiro'])): ?>
                        <a href="<?php echo e(route('compras.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isCompras, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isCompras]); ?>" <?php if($isCompras): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3h2l2.4 12.2a2 2 0 002 1.6h8.8a2 2 0 002-1.6L22 8H6M10 21h.01M18 21h.01" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Compras</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente', 'vendedor', 'financeiro'])): ?>
                        <a href="<?php echo e(route('vendas.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isVendas, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isVendas]); ?>" <?php if($isVendas): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M3 3v18h18M3 9h18M9 9v18M15 9v18M7 13v6M11 13v6M13 13v6"/></svg>
                            <span>Vendas</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente', 'tecnico'])): ?>
                        <a href="<?php echo e(route('ordens-servico.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isOS, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isOS]); ?>" <?php if($isOS): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3h18v18H3z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Ordens Serv.</span>
                        </a>
                    <?php endif; ?>

                    <?php if($isFinanceiro): ?>
                        <a href="<?php echo e(route('contas-receber.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isContasReceber, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isContasReceber]); ?>" <?php if($isContasReceber): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M24 16c0 1.105-.895 2-2 2H2c-1.105 0-2-.895-2-2v-8c0-1.105.895-2 2-2h12c1.105 0 2 .895 2 2z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Contas Rec.</span>
                        </a>
                        <a href="<?php echo e(route('contas-pagar.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isContasPagar, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isContasPagar]); ?>" <?php if($isContasPagar): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3h18v18H3z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Contas Pagar</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente', 'vendedor'])): ?>
                        <a href="<?php echo e(route('produtos.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isProdutos, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isProdutos]); ?>" <?php if($isProdutos): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="m4 7 8-4 8 4-8 4-8-4Zm0 0v10l8 4 8-4V7M12 11v10" stroke-width="1.8" stroke-linejoin="round"/></svg>
                            <span>Produtos</span>
                        </a>
                    <?php endif; ?>

                    <?php if($user->hasRole(['admin', 'gerente', 'vendedor'])): ?>
                        <a href="<?php echo e(route('crm.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition sm:px-4', 'bg-white text-[#064E3B] shadow-sm' => $isCrm, 'text-emerald-50/80 hover:bg-white/10 hover:text-white' => !$isCrm]); ?>" <?php if($isCrm): ?> aria-current="page" <?php endif; ?>>
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M12 4.5v15m7.5-7.5h-15" stroke-width="1.5" stroke-linecap="round"/></svg>
                            <span>CRM</span>
                        </a>
                    <?php endif; ?>
                </nav>
                <div class="flex shrink-0 items-center gap-3">
                    <div class="hidden text-right sm:block"><div class="max-w-36 truncate text-sm font-semibold"><?php echo e(auth()->user()->nome ?? auth()->user()->name); ?></div><div class="text-[11px] text-emerald-100/75"><?php echo e(auth()->user()->role ?? 'Usuário'); ?></div></div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-[#C68346] text-sm font-bold text-white" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr(auth()->user()->nome ?? auth()->user()->name ?? 'U', 0, 1))); ?></div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="rounded-xl border border-white/15 px-3 py-2 text-xs font-semibold text-emerald-50 transition hover:border-white/30 hover:bg-white/10 sm:text-sm">Sair</button></form>
                </div>
            </div>
        </header>
    <?php endif; ?>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\ARIEL\Documents\Projetos\Zeno\resources\views/layouts/app.blade.php ENDPATH**/ ?>