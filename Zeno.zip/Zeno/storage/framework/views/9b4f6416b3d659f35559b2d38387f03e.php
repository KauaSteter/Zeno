

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-slate-100 rounded-lg shadow-sm max-w-3xl mx-auto">
    <div class="mb-4">
        <h1 class="text-2xl font-bold text-emerald-700">Nova Ordem de Serviço</h1>
        <p class="text-sm text-slate-600">Abertura de OS para prestação de serviços, transporte e reparos</p>
    </div>

    <form action="<?php echo e(route('ordens-servico.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
            <div class="mb-4 rounded border border-red-300 bg-red-50 p-3 text-red-800 text-sm">
                <ul class="list-disc pl-4"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
        <?php endif; ?>

    
    <div class="bg-white p-4 rounded-lg border border-gray-200 mb-4 shadow-sm">
        <h2 class="text-base font-semibold text-slate-800 mb-3">📋 Identificação do Atendimento</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Título / Assunto da OS</label>
                <input type="text" name="titulo" placeholder="Ex: Manutenção Elétrica / Revisão"
                       class="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-emerald-500">
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Cliente *</label>
                <select name="cliente_id" required class="w-full px-3 py-2 border border-gray-300 rounded text-sm">
                    <option value="">— Selecione o Cliente —</option>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nome); ?> (<?php echo e($cliente->tipo === 'pj' ? 'PJ' : 'PF'); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>

    
    <div class="bg-white p-4 rounded-lg border border-gray-200 mb-4 shadow-sm">
        <div class="flex items-center justify-between mb-2">
            <h2 class="text-base font-semibold text-slate-800">🚗 Transporte / Veículo (Opcional)</h2>
            <span class="text-xs text-slate-500">Preencha caso o atendimento envolva veículo ou transporte</span>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-sm">
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Marca</label>
                <input type="text" name="veiculo_marca" placeholder="Ex: Toyota" class="w-full px-3 py-2 border border-gray-300 rounded text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Modelo</label>
                <input type="text" name="veiculo_modelo" placeholder="Ex: Corolla" class="w-full px-3 py-2 border border-gray-300 rounded text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Placa</label>
                <input type="text" name="veiculo_placa" placeholder="ABC-1234" class="w-full px-3 py-2 border border-gray-300 rounded text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Ano</label>
                <input type="number" name="veiculo_ano" placeholder="2022" class="w-full px-3 py-2 border border-gray-300 rounded text-sm">
            </div>
        </div>

        <div class="mt-3">
            <label class="block text-xs font-semibold mb-1 text-slate-700">Quilometragem de Entrada (km)</label>
            <input type="number" name="quilometragem_entrada" placeholder="Ex: 45000" class="w-full sm:w-1/2 px-3 py-2 border border-gray-300 rounded text-sm">
        </div>
    </div>

    
    <div class="bg-white p-4 rounded-lg border border-gray-200 mb-4 shadow-sm">
        <h2 class="text-base font-semibold text-slate-800 mb-2">📝 Problema Relatado / Observações</h2>
        <div class="space-y-3">
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Problema Relatado / Sintoma</label>
                <textarea name="descricao_problema" rows="2" placeholder="Descreva o problema apresentado..." class="w-full px-3 py-2 border border-gray-300 rounded text-sm"></textarea>
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1 text-slate-700">Observações Internas</label>
                <textarea name="observacoes" rows="2" placeholder="Informações adicionais para a equipe..." class="w-full px-3 py-2 border border-gray-300 rounded text-sm"></textarea>
            </div>
        </div>
    </div>

    <div class="bg-gray-50 p-4 rounded-lg border border-gray-300 mb-4">
        <div class="flex justify-between items-center mb-2">
            <h2 class="text-lg font-semibold">🔧 Itens do Serviço</h2>
            <button type="button" onclick="adicionarItem()"
                    class="px-3 py-1 bg-emerald-600 text-white text-sm rounded hover:bg-emerald-700">
                + Adicionar Item
            </button>
        </div>
        <div id="itens-container" class="space-y-2">
            <div class="item-row bg-white p-3 rounded border border-gray-200">
                <div class="grid grid-cols-12 gap-2 items-center">
                    <div class="col-span-2">
                        <select name="itens[0][tipo]" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                            <option value="servico">Serviço</option>
                            <option value="peca">Peça</option>
                        </select>
                    </div>
                    <div class="col-span-3">
                        <input type="text" name="itens[0][nome]" placeholder="Nome"
                               class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                    </div>
                    <div class="col-span-1">
                        <input type="number" name="itens[0][quantidade]" value="1"
                               class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                    </div>
                    <div class="col-span-2">
                        <input type="number" step="0.01" name="itens[0][valor_unitario]" value="0"
                               class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                    </div>
                    <div class="col-span-3">
                        <div class="flex items-center gap-2">
                            <button type="button" onclick="removerItem(this)" class="text-red-600 hover:text-red-800">🗑</button>
                            <button type="button" onclick="calcularItem(this)" class="text-emerald-600 hover:text-emerald-800">✓</button>
                        </div>
                    </div>
                </div>
                <div class="mt-2 text-xs text-gray-600 total-item">Total: R$ 0,00</div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h2 class="text-lg font-semibold mb-2">💰 Cálculos</h2>
            <div class="space-y-2">
                <div>
                    <label class="block text-sm font-medium mb-1">Mão de Obra (R$)</label>
                    <input type="number" name="mão_obra" id="mao-obra-input" placeholder="R$ 0,00"
                           class="w-full px-3 py-2 border border-gray-300 rounded focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Total Desconto</label>
                    <input type="number" step="0.01" name="total_desconto" placeholder="R$ 0,00"
                           class="w-full px-3 py-2 border border-gray-300 rounded">
                </div>
                <div class="bg-slate-100 p-3 rounded border border-slate-300 mt-3">
                    <div class="text-sm font-semibold mb-1">TOTAL DA ORDEM:</div>
                    <div id="total-geral" class="text-xl font-bold text-emerald-700">R$ 0,00</div>
                </div>
            </div>
        </div>

        <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h2 class="text-lg font-semibold mb-2">📊 Status e Tecnico</h2>
            <div class="space-y-2">
                <div>
                    <label class="block text-sm font-medium mb-1">Status</label>
                    <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded">
                        <option value="aberta">Aberta</option>
                        <option value="em_andamento">Em Andamento</option>
                        <option value="aguardando_aprovacao">Aguardando Aprovação</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Prioridade</label>
                    <select name="prioridade" class="w-full px-3 py-2 border border-gray-300 rounded">
                        <option value="normal">Normal</option>
                        <option value="urgente">Urgente</option>
                        <option value="emergencia">Emergência</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Técnico Responsável</label>
                    <select name="tecnico_id" class="w-full px-3 py-2 border border-gray-300 rounded">
                        <option value="">— Sem técnico —</option>
                        <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tecnico->id); ?>"><?php echo e($tecnico->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
        <h2 class="text-lg font-semibold mb-2">📋 Observações</h2>
        <textarea name="observacoes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded text-sm"></textarea>
        <div class="text-xs text-gray-600 mt-1">Sintoma, problema relatado, etc.</div>
    </div>

    <div class="flex gap-4 mt-6">
        <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded font-semibold">
            ✨ Criar OS
        </button>
        <a href="<?php echo e(route('ordens-servico.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded">
            Cancelar
        </a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<script>
function adicionarItem() {
    const container = document.getElementById('itens-container');
    const index = container.querySelectorAll('.item-row').length;
    const html = `
        <div class="item-row bg-white p-3 rounded border border-gray-200">
            <div class="grid grid-cols-12 gap-2 items-center">
                <div class="col-span-2">
                    <select name="itens[${index}][tipo]" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                        <option value="servico">Serviço</option>
                        <option value="peca">Peça</option>
                    </select>
                </div>
                <div class="col-span-3">
                    <input type="text" name="itens[${index}][nome]" placeholder="Nome" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                </div>
                <div class="col-span-1">
                    <input type="number" name="itens[${index}][quantidade]" value="1" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                </div>
                <div class="col-span-2">
                    <input type="number" step="0.01" name="itens[${index}][valor_unitario]" value="0"
                           class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                </div>
                <div class="col-span-3">
                    <div class="flex items-center gap-2">
                        <button type="button" onclick="removerItem(this)" class="text-red-600 hover:text-red-800">🗑</button>
                        <button type="button" onclick="calcularItem(this)" class="text-emerald-600 hover:text-emerald-800">✓</button>
                    </div>
                </div>
            </div>
            <div class="mt-2 text-xs text-gray-600 total-item">Total: R$ 0,00</div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
}

function removerItem(btn) {
    const row = btn.closest('.item-row');
    row.remove();
}

function calcularItem(btn) {
    const row = btn.closest('.item-row');
    const tipo = row.querySelector('select[name*="[tipo]"]').value;
    const quantidade = parseFloat(row.querySelector('input[name*="[quantidade]"]').value) || 0;
    const valorUnitario = parseFloat(row.querySelector('input[name*="[valor_unitario]"]').value) || 0;
    const total = quantidade * valorUnitario;
    const totalElement = row.querySelector('.total-item');
    totalElement.textContent = `Total: R$ ${total.toFixed(2).replace('.', ',')}`;
    atualizarTotalGeral();
}

function atualizarTotalGeral() {
    let totalPecas = 0;
    const itens = document.querySelectorAll('.item-row');
    itens.forEach(row => {
        const tipo = row.querySelector('select[name*="[tipo]"]').value;
        const quantidade = parseFloat(row.querySelector('input[name*="[quantidade]"]').value) || 0;
        const valorUnitario = parseFloat(row.querySelector('input[name*="[valor_unitario]"]').value) || 0;
        if (tipo === 'peca') totalPecas += quantidade * valorUnitario;
    });
    constmao_obra = parseFloat(document.querySelector('input[name="mão_obra"]').value) || 0;
    const desconto = parseFloat(document.querySelector('input[name="total_desconto"]').value) || 0;
    const totalGeral = totalPecas + mão_obra - desconto;
    document.getElementById('total-geral').textContent = `R$ ${totalGeral.toFixed(2).replace('.', ',')}`;
}

document.addEventListener('input', function(e) {
    if (e.target.name === 'mão_obra' || e.target.name === 'total_desconto') {
        atualizarTotalGeral();
    }
});

window.addEventListener('load', function() {
    atualizarTotalGeral();
});
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ARIEL\Documents\Projetos\Zeno\resources\views/ordens-servico/create.blade.php ENDPATH**/ ?>